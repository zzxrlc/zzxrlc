import { NextResponse } from "next/server";
import { db } from "@/db";
import { accounts } from "@/db/schema";
import { getActiveAccount } from "@/lib/account";
import { verifyMediaUserToken } from "@/lib/apple";
import { maskToken, parseCookies } from "@/lib/cookies";
import { encryptSecret } from "@/lib/secret";

export const runtime = "nodejs";

function publicAccount(a: Awaited<ReturnType<typeof getActiveAccount>>) {
  if (!a) return null;
  return {
    id: a.id,
    label: a.label,
    storefront: a.storefront,
    cookieCount: a.cookieCount,
    verified: a.verified,
    verifyMessage: a.verifyMessage,
    verifiedAt: a.verifiedAt,
    createdAt: a.createdAt,
    tokenPreview: maskToken(a.mediaUserToken),
  };
}

export async function GET() {
  const account = await getActiveAccount();
  return NextResponse.json({ account: publicAccount(account) });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { cookies?: string; label?: string };
  const raw = body.cookies ?? "";
  const parsed = parseCookies(raw);

  if (!parsed.mediaUserToken) {
    return NextResponse.json(
      {
        error:
          parsed.count === 0
            ? "无法识别 cookies 格式。请粘贴 Netscape 格式 cookies.txt（gamdl 同款）或浏览器 Cookie 字符串。"
            : `解析到 ${parsed.count} 条 cookie，但缺少 media-user-token。请确认已在 music.apple.com 登录后再导出。`,
        format: parsed.format,
        count: parsed.count,
      },
      { status: 400 },
    );
  }

  const verify = await verifyMediaUserToken(parsed.mediaUserToken, parsed.storefront);

  // Keep a single active account: replace previous imports.
  await db.delete(accounts);
  const [row] = await db
    .insert(accounts)
    .values({
      label: body.label?.trim() || "Apple Music",
      mediaUserToken: parsed.mediaUserToken,
      encryptedCookies: encryptSecret(raw),
      storefront: verify.storefront,
      cookieCount: parsed.count,
      verified: verify.ok,
      verifyMessage: verify.message,
      verifiedAt: new Date(),
    })
    .returning();

  return NextResponse.json({ account: publicAccount(row), format: parsed.format });
}

export async function DELETE() {
  await db.delete(accounts);
  return NextResponse.json({ ok: true });
}
