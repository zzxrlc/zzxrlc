import { NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";
import os from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { getActiveCookies } from "@/lib/account";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const execFileAsync = promisify(execFile);

function safeName(s: string) {
  return s.replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 120) || "Apple-Music";
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as { url?: string } | null;
  const url = (body?.url ?? "").trim();
  if (!/^https:\/\/music\.apple\.com\//i.test(url)) {
    return NextResponse.json({ error: "只接受 Apple Music 官方链接" }, { status: 400 });
  }

  const cookies = await getActiveCookies();
  if (!cookies) {
    return NextResponse.json({ error: "请先在「登录」中导入你自己的 Apple Music cookies.txt" }, { status: 401 });
  }

  const job = await fs.mkdtemp(path.join(os.tmpdir(), "gamdl-"));
  const cookiePath = path.join(job, "cookies.txt");
  const outputPath = path.join(job, "out");
  await fs.mkdir(outputPath);
  await fs.writeFile(cookiePath, cookies, { mode: 0o600 });

  try {
    // aac-web is the least demanding web codec and does not require the optional wrapper.
    const gamdlBin = process.env.GAMDL_BIN || "gamdl";
    await execFileAsync(
      gamdlBin,
      [
        "--cookies-path", cookiePath,
        "--output-path", outputPath,
        "--song-codec-priority", "aac-web",
        "--no-synced-lyrics",
        "--log-level", "WARNING",
        url,
      ],
      {
        cwd: job,
        timeout: 15 * 60 * 1000,
        maxBuffer: 2 * 1024 * 1024,
        env: { ...process.env, PYTHONUNBUFFERED: "1" },
      },
    );

    const files: string[] = [];
    async function walk(dir: string) {
      for (const ent of await fs.readdir(dir, { withFileTypes: true })) {
        const full = path.join(dir, ent.name);
        if (ent.isDirectory()) await walk(full);
        else if (/\.(m4a|mp4|m4v|aac)$/i.test(ent.name)) files.push(full);
      }
    }
    await walk(outputPath);

    if (!files.length) {
      return NextResponse.json({ error: "gamdl 未生成媒体文件，请检查订阅、cookies 或 Apple Music 链接" }, { status: 502 });
    }

    if (files.length === 1) {
      const file = files[0];
      const data = await fs.readFile(file);
      const filename = safeName(path.basename(file));
      return new Response(data, {
        headers: {
          "Content-Type": "audio/mp4",
          "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`,
          "Cache-Control": "no-store",
        },
      });
    }

    // For albums/playlists, return a zip so mobile browsers get one file.
    const archive = path.join(job, "Apple-Music.zip");
    const { stdout, stderr } = await execFileAsync(
      "python3",
      ["-c", [
        "import sys, zipfile, os",
        "root, out = sys.argv[1], sys.argv[2]",
        "files=[]",
        "for dp,_,ns in os.walk(root):",
        "  for n in ns:",
        "    if n.lower().endswith(('.m4a','.mp4','.m4v','.aac')): files.append(os.path.join(dp,n))",
        "with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:",
        "  for f in files: z.write(f, os.path.relpath(f,root))",
      ].join("\n"), outputPath, archive],
      { timeout: 60_000, maxBuffer: 1024 * 1024 },
    );
    void stdout; void stderr;
    const data = await fs.readFile(archive);
    return new Response(data, {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent("Apple-Music.zip")}`,
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    const e = err as { stderr?: string; message?: string };
    const detail = (e.stderr || e.message || "gamdl 执行失败").slice(-3000);
    return NextResponse.json({ error: detail }, { status: 502 });
  } finally {
    await fs.rm(job, { recursive: true, force: true }).catch(() => {});
  }
}
