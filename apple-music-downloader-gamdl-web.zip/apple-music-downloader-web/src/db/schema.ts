import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

// Apple Music account imported from a gamdl-style cookies.txt file.
export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  label: text("label").notNull().default("Apple Music"),
  mediaUserToken: text("media_user_token").notNull(),
  encryptedCookies: text("encrypted_cookies").notNull(),
  storefront: varchar("storefront", { length: 8 }).notNull().default("us"),
  cookieCount: integer("cookie_count").notNull().default(0),
  verified: boolean("verified").notNull().default(false),
  verifyMessage: text("verify_message"),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// Download / export history.
export const downloads = pgTable("downloads", {
  id: serial("id").primaryKey(),
  appleTrackId: text("apple_track_id"),
  trackName: text("track_name").notNull(),
  artistName: text("artist_name").notNull().default(""),
  albumName: text("album_name").notNull().default(""),
  appleUrl: text("apple_url"),
  previewUrl: text("preview_url"),
  artworkUrl: text("artwork_url"),
  source: text("source").notNull().default("apple"),
  status: text("status").notNull().default("done"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// Search log (used for "recent searches").
export const searchLogs = pgTable("search_logs", {
  id: serial("id").primaryKey(),
  query: text("query").notNull(),
  kind: text("kind").notNull().default("song"),
  resultCount: integer("result_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Account = typeof accounts.$inferSelect;
export type Download = typeof downloads.$inferSelect;
