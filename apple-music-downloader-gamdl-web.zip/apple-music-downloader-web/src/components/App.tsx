"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import SongRow from "./SongRow";
import {
  downloadHref,
  sourceLabel,
  type AccountInfo,
  type Album,
  type AlbumResponse,
  type DownloadRow,
  type Song,
} from "./types";

type Tab = "search" | "album" | "downloads" | "login";
type Kind = "song" | "album";

export default function App() {
  const [tab, setTab] = useState<Tab>("search");
  const [account, setAccount] = useState<AccountInfo | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  // search state
  const [q, setQ] = useState("");
  const [kind, setKind] = useState<Kind>("song");
  const [songs, setSongs] = useState<Song[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // album state
  const [albumData, setAlbumData] = useState<AlbumResponse | null>(null);
  const [albumLoading, setAlbumLoading] = useState(false);
  const [albumError, setAlbumError] = useState<string | null>(null);
  const [albumRef, setAlbumRef] = useState<{ id: string; name: string; artist: string } | null>(null);

  // downloads
  const [history, setHistory] = useState<DownloadRow[]>([]);
  const [batchProgress, setBatchProgress] = useState<string | null>(null);

  // login
  const [cookieText, setCookieText] = useState("");
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginMsg, setLoginMsg] = useState<string | null>(null);

  // player
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [nowPlaying, setNowPlaying] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 2200);
  }, []);

  const loadAccount = useCallback(async () => {
    const res = await fetch("/api/auth", { cache: "no-store" });
    const data = (await res.json()) as { account: AccountInfo | null };
    setAccount(data.account);
  }, []);

  const loadHistory = useCallback(async () => {
    const res = await fetch("/api/downloads", { cache: "no-store" });
    const data = (await res.json()) as { downloads: DownloadRow[] };
    setHistory(data.downloads);
  }, []);

  useEffect(() => {
    void loadAccount();
    void loadHistory();
  }, [loadAccount, loadHistory]);

  /* ------------------------------ search ------------------------------ */

  const runSearch = useCallback(
    async (term: string, k: Kind) => {
      if (!term.trim()) return;
      setSearching(true);
      setSearchError(null);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(term)}&kind=${k}`);
        const data = (await res.json()) as { songs?: Song[]; albums?: Album[]; error?: string };
        if (!res.ok) throw new Error(data.error ?? "搜索失败");
        if (k === "song") {
          setSongs(data.songs ?? []);
          setAlbums([]);
        } else {
          setAlbums(data.albums ?? []);
          setSongs([]);
        }
      } catch (err) {
        setSearchError(err instanceof Error ? err.message : "搜索失败");
      } finally {
        setSearching(false);
      }
    },
    [],
  );

  /* ------------------------------ album ------------------------------- */

  const openAlbum = useCallback(
    async (id: string, name: string, artist: string, forceFallback = false) => {
      setTab("album");
      setAlbumRef({ id, name, artist });
      setAlbumLoading(true);
      setAlbumError(null);
      if (!forceFallback) setAlbumData(null);
      try {
        const params = new URLSearchParams({ name, artist });
        if (forceFallback) params.set("fallback", "1");
        const res = await fetch(`/api/album/${encodeURIComponent(id)}?${params}`);
        const data = (await res.json()) as AlbumResponse;
        if (!res.ok) {
          setAlbumData(data.album ? data : null);
          throw new Error(data.error ?? "专辑加载失败");
        }
        setAlbumData(data);
      } catch (err) {
        setAlbumError(err instanceof Error ? err.message : "专辑加载失败");
      } finally {
        setAlbumLoading(false);
      }
    },
    [],
  );

  /* ------------------------------ player ------------------------------ */

  const play = useCallback(
    (song: Song) => {
      const audio = audioRef.current;
      if (!audio || !song.previewUrl) return;
      if (nowPlaying?.id === song.id) {
        if (audio.paused) void audio.play();
        else audio.pause();
        return;
      }
      audio.src = song.previewUrl;
      setNowPlaying(song);
      void audio.play();
    },
    [nowPlaying],
  );

  /* ----------------------------- downloads ---------------------------- */

  const recordDownloads = useCallback(
    async (items: Song[]) => {
      await fetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((s) => ({
            id: s.id,
            name: s.name,
            artist: s.artist,
            album: s.album,
            url: s.url,
            previewUrl: s.previewUrl,
            artworkUrl: s.artworkUrl,
            source: s.source,
          })),
        }),
      });
      void loadHistory();
    },
    [loadHistory],
  );

  const triggerDownload = useCallback((href: string) => {
    const a = document.createElement("a");
    a.href = href;
    a.rel = "noopener";
    a.download = "";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }, []);

  const downloadOne = useCallback(
    async (song: Song) => {
      if (!song.url) return showToast("该曲目没有 Apple Music 链接");
      showToast(`正在用 gamdl 下载：${song.name}`);
      try {
        const res = await fetch("/api/gamdl", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: song.url }),
        });
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error ?? `HTTP ${res.status}`);
        }
        const blob = await res.blob();
        const href = URL.createObjectURL(blob);
        triggerDownload(href);
        setTimeout(() => URL.revokeObjectURL(href), 30_000);
        await recordDownloads([song]);
        showToast(`下载完成：${song.name}`);
      } catch (err) {
        showToast(err instanceof Error ? err.message.slice(0, 80) : "下载失败");
      }
    },
    [recordDownloads, showToast, triggerDownload],
  );

  const downloadAll = useCallback(
    async (list: Song[], albumUrl?: string) => {
      const items = list.filter((s) => s.url);
      if (items.length === 0) return showToast("没有可下载的曲目");
      setBatchProgress("正在生成专辑文件…");
      try {
        const first = items[0];
        const res = await fetch("/api/gamdl", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: albumUrl || first.url }),
        });
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error ?? `HTTP ${res.status}`);
        }
        const blob = await res.blob();
        const href = URL.createObjectURL(blob);
        triggerDownload(href);
        setTimeout(() => URL.revokeObjectURL(href), 30_000);
        await recordDownloads(items);
        showToast("专辑下载完成");
      } catch (err) {
        showToast(err instanceof Error ? err.message.slice(0, 100) : "下载失败");
      } finally {
        setBatchProgress(null);
      }
    },
    [recordDownloads, showToast, triggerDownload],
  );

  const copy = useCallback(
    async (text: string) => {
      try {
        await navigator.clipboard.writeText(text);
        showToast("已复制");
      } catch {
        window.prompt("复制链接：", text);
      }
    },
    [showToast],
  );

  const exportList = useCallback(
    async (list: Song[], title: string) => {
      const lines = list
        .filter((s) => s.url)
        .map((s) => `${s.artist} - ${s.name}\t${s.url}`)
        .join("\n");
      await copy(`# ${title}\n${lines}`);
      await recordDownloads(list.filter((s) => s.url));
    },
    [copy, recordDownloads],
  );

  /* ------------------------------- login ------------------------------ */

  const importCookies = useCallback(async () => {
    if (!cookieText.trim()) return setLoginMsg("请先粘贴 cookies 内容或选择 cookies.txt");
    setLoginBusy(true);
    setLoginMsg(null);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cookies: cookieText }),
      });
      const data = (await res.json()) as { account?: AccountInfo; error?: string };
      if (!res.ok) throw new Error(data.error ?? "导入失败");
      setAccount(data.account ?? null);
      setCookieText("");
      setLoginMsg(data.account?.verifyMessage ?? "导入成功");
      showToast("cookies 已导入");
    } catch (err) {
      setLoginMsg(err instanceof Error ? err.message : "导入失败");
    } finally {
      setLoginBusy(false);
    }
  }, [cookieText, showToast]);

  const logout = useCallback(async () => {
    await fetch("/api/auth", { method: "DELETE" });
    setAccount(null);
    showToast("已退出登录");
  }, [showToast]);

  const onFile = useCallback(async (file: File | null) => {
    if (!file) return;
    setCookieText(await file.text());
  }, []);

  /* -------------------------------- UI -------------------------------- */

  return (
    <div className="mx-auto flex min-h-dvh max-w-3xl flex-col">
      {/* header */}
      <header className="safe-top sticky top-0 z-20 border-b border-white/5 bg-[#0b0b0f]/80 px-4 pb-3 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <h1 className="text-[22px] font-bold tracking-tight">
            <span className="text-[#fa2d48]"></span> AM Downloader
          </h1>
          <button
            type="button"
            onClick={() => setTab("login")}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs ${
              account
                ? account.verified
                  ? "bg-emerald-500/15 text-emerald-300"
                  : "bg-amber-500/15 text-amber-300"
                : "bg-white/10 text-zinc-300"
            }`}
          >
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                account ? (account.verified ? "bg-emerald-400" : "bg-amber-400") : "bg-zinc-500"
              }`}
            />
            {account ? `${account.storefront.toUpperCase()} · 已登录` : "未登录"}
          </button>
        </div>

        {tab === "search" && (
          <form
            className="mt-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              void runSearch(q, kind);
            }}
          >
            <div className="flex flex-1 items-center gap-2 rounded-xl bg-white/[0.08] px-3">
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-zinc-400" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="7" />
                <path d="m20 20-3.5-3.5" />
              </svg>
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={kind === "song" ? "搜索歌曲、歌手…" : "搜索专辑…"}
                className="h-10 w-full bg-transparent text-[16px] outline-none placeholder:text-zinc-500"
                enterKeyHint="search"
                autoCorrect="off"
                autoCapitalize="off"
              />
              {q && (
                <button type="button" onClick={() => setQ("")} className="text-zinc-500">
                  ✕
                </button>
              )}
            </div>
            <div className="flex rounded-xl bg-white/[0.08] p-1 text-xs">
              {(["song", "album"] as Kind[]).map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => {
                    setKind(k);
                    if (q.trim()) void runSearch(q, k);
                  }}
                  className={`rounded-lg px-3 ${kind === k ? "bg-[#fa2d48] text-white" : "text-zinc-300"}`}
                >
                  {k === "song" ? "单曲" : "专辑"}
                </button>
              ))}
            </div>
          </form>
        )}
      </header>

      {/* content */}
      <main className="flex-1 pb-36">
        {tab === "search" && (
          <SearchPanel
            kind={kind}
            songs={songs}
            albums={albums}
            searching={searching}
            error={searchError}
            nowPlaying={nowPlaying}
            isPlaying={isPlaying}
            onPlay={play}
            onDownload={downloadOne}
            onOpenAlbum={(id, n, a) => void openAlbum(id, n, a)}
            onCopy={copy}
            onQuick={(term) => {
              setQ(term);
              void runSearch(term, kind);
            }}
          />
        )}

        {tab === "album" && (
          <AlbumPanel
            data={albumData}
            loading={albumLoading}
            error={albumError}
            batchProgress={batchProgress}
            nowPlaying={nowPlaying}
            isPlaying={isPlaying}
            onPlay={play}
            onDownload={downloadOne}
            onDownloadAll={downloadAll}
            onExport={exportList}
            onCopy={copy}
            onRetryFallback={() => albumRef && void openAlbum(albumRef.id, albumRef.name, albumRef.artist, true)}
            onRetryApple={() => albumRef && void openAlbum(albumRef.id, albumRef.name, albumRef.artist, false)}
            onBack={() => setTab("search")}
          />
        )}

        {tab === "downloads" && (
          <DownloadsPanel
            rows={history}
            onClear={async () => {
              await fetch("/api/downloads", { method: "DELETE" });
              void loadHistory();
            }}
            onCopy={copy}
          />
        )}

        {tab === "login" && (
          <LoginPanel
            account={account}
            cookieText={cookieText}
            setCookieText={setCookieText}
            onFile={onFile}
            busy={loginBusy}
            msg={loginMsg}
            onImport={importCookies}
            onLogout={logout}
          />
        )}
      </main>

      {/* mini player */}
      {nowPlaying && (
        <div className="fixed inset-x-0 bottom-[calc(64px+env(safe-area-inset-bottom))] z-20 mx-auto max-w-3xl px-3">
          <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-[#1c1c22]/95 p-2 shadow-2xl backdrop-blur-xl">
            {nowPlaying.artworkUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={nowPlaying.artworkUrl} alt="" className="h-11 w-11 rounded-lg object-cover" />
            ) : (
              <div className="h-11 w-11 rounded-lg bg-zinc-700" />
            )}
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm">{nowPlaying.name}</div>
              <div className="truncate text-xs text-zinc-400">{nowPlaying.artist} · 30s 预览</div>
            </div>
            <button
              type="button"
              onClick={() => play(nowPlaying)}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-black"
              aria-label={isPlaying ? "暂停" : "播放"}
            >
              {isPlaying ? (
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor">
                  <rect x="6" y="5" width="4" height="14" rx="1" />
                  <rect x="14" y="5" width="4" height="14" rx="1" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor">
                  <path d="M8 5v14l11-7z" />
                </svg>
              )}
            </button>
            <button
              type="button"
              onClick={() => {
                audioRef.current?.pause();
                setNowPlaying(null);
              }}
              className="px-2 text-zinc-400"
              aria-label="关闭"
            >
              ✕
            </button>
          </div>
        </div>
      )}
      <audio
        ref={audioRef}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={() => setIsPlaying(false)}
        playsInline
      />

      {/* tab bar */}
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-20 border-t border-white/5 bg-[#0b0b0f]/90 backdrop-blur-xl">
        <div className="mx-auto grid max-w-3xl grid-cols-4 pt-1.5">
          {(
            [
              ["search", "搜索", "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm9 16-3.5-3.5"],
              ["album", "专辑", "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 6.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z"],
              ["downloads", "下载", "M12 4v11m0 0 4-4m-4 4-4-4M5 19h14"],
              ["login", "登录", "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 8a7 7 0 0 1 14 0"],
            ] as [Tab, string, string][]
          ).map(([t, label, d]) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={`flex flex-col items-center gap-0.5 py-1 text-[10px] ${
                tab === t ? "text-[#fa2d48]" : "text-zinc-500"
              }`}
            >
              <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d={d} />
              </svg>
              {label}
              {t === "downloads" && history.length > 0 && (
                <span className="sr-only">{history.length}</span>
              )}
            </button>
          ))}
        </div>
      </nav>

      {toast && (
        <div className="pointer-events-none fixed inset-x-0 top-[calc(env(safe-area-inset-top)+72px)] z-50 flex justify-center px-4">
          <div className="rounded-full bg-white px-4 py-2 text-sm font-medium text-black shadow-xl">{toast}</div>
        </div>
      )}
    </div>
  );
}

/* ====================================================================== */
/* Panels                                                                  */
/* ====================================================================== */

function SearchPanel(props: {
  kind: Kind;
  songs: Song[];
  albums: Album[];
  searching: boolean;
  error: string | null;
  nowPlaying: Song | null;
  isPlaying: boolean;
  onPlay: (s: Song) => void;
  onDownload: (s: Song) => void;
  onOpenAlbum: (id: string, name: string, artist: string) => void;
  onCopy: (t: string) => void;
  onQuick: (term: string) => void;
}) {
  const { kind, songs, albums, searching, error } = props;

  if (searching) {
    return (
      <ul className="divide-y divide-white/5">
        {Array.from({ length: 8 }).map((_, i) => (
          <li key={i} className="flex items-center gap-3 px-3 py-2.5">
            <div className="skeleton h-12 w-12 rounded-md" />
            <div className="flex-1 space-y-2">
              <div className="skeleton h-3.5 w-2/3 rounded" />
              <div className="skeleton h-3 w-1/2 rounded" />
            </div>
          </li>
        ))}
      </ul>
    );
  }

  if (error) {
    return <Empty title="搜索失败" desc={error} />;
  }

  if (kind === "song" && songs.length === 0) {
    return (
      <Empty title="搜索 Apple Music" desc="结果只保留音乐单曲（已过滤 MV、播客、有声书等）。">
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          {["周杰伦", "Taylor Swift", "五月天", "Billie Eilish", "坂本龍一"].map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => props.onQuick(t)}
              className="rounded-full bg-white/10 px-3 py-1.5 text-sm text-zinc-200"
            >
              {t}
            </button>
          ))}
        </div>
      </Empty>
    );
  }

  if (kind === "album") {
    if (albums.length === 0) return <Empty title="搜索专辑" desc="只显示音乐专辑，点击进入专辑查看曲目。" />;
    return (
      <ul className="grid grid-cols-2 gap-3 p-3 sm:grid-cols-3">
        {albums.map((a) => (
          <li key={a.id}>
            <button
              type="button"
              onClick={() => props.onOpenAlbum(a.id, a.name, a.artist)}
              className="w-full text-left active:opacity-70"
            >
              {a.artworkUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={a.artworkUrl} alt="" className="aspect-square w-full rounded-xl bg-zinc-800 object-cover" loading="lazy" />
              ) : (
                <div className="aspect-square w-full rounded-xl bg-zinc-800" />
              )}
              <div className="mt-1.5 truncate text-[14px]">{a.name}</div>
              <div className="truncate text-[12px] text-zinc-400">
                {a.artist}
                {a.releaseDate ? ` · ${a.releaseDate.slice(0, 4)}` : ""}
                {a.trackCount ? ` · ${a.trackCount} 首` : ""}
              </div>
            </button>
          </li>
        ))}
      </ul>
    );
  }

  return (
    <>
      <div className="px-4 pt-3 text-xs text-zinc-500">{songs.length} 首单曲</div>
      <ul className="divide-y divide-white/5">
        {songs.map((s, i) => (
          <SongRow
            key={s.id}
            song={s}
            index={i + 1}
            playing={props.nowPlaying?.id === s.id && props.isPlaying}
            onPlay={props.onPlay}
            onDownload={props.onDownload}
            onOpenAlbum={props.onOpenAlbum}
            onCopy={props.onCopy}
          />
        ))}
      </ul>
    </>
  );
}

function AlbumPanel(props: {
  data: AlbumResponse | null;
  loading: boolean;
  error: string | null;
  batchProgress: string | null;
  nowPlaying: Song | null;
  isPlaying: boolean;
  onPlay: (s: Song) => void;
  onDownload: (s: Song) => void;
  onDownloadAll: (list: Song[], albumUrl?: string) => void;
  onExport: (list: Song[], title: string) => void;
  onCopy: (t: string) => void;
  onRetryFallback: () => void;
  onRetryApple: () => void;
  onBack: () => void;
}) {
  const { data, loading, error } = props;

  if (loading) {
    return (
      <div className="p-4">
        <div className="flex gap-4">
          <div className="skeleton h-36 w-36 rounded-xl" />
          <div className="flex-1 space-y-3 pt-2">
            <div className="skeleton h-5 w-3/4 rounded" />
            <div className="skeleton h-4 w-1/2 rounded" />
            <div className="skeleton h-3 w-1/3 rounded" />
          </div>
        </div>
        <p className="mt-6 text-center text-xs text-zinc-500">
          正在向 Apple 查询曲目；若失败将自动使用 Deezer / MusicBrainz 兜底并逐首匹配…
        </p>
      </div>
    );
  }

  if (!data && !error) {
    return (
      <Empty title="专辑查看" desc="在搜索结果里点击专辑封面或单曲旁的 ◎ 进入专辑。">
        <button type="button" onClick={props.onBack} className="mt-4 rounded-full bg-white/10 px-4 py-1.5 text-sm">
          去搜索
        </button>
      </Empty>
    );
  }

  const album = data?.album ?? null;
  const tracks = data?.tracks ?? [];
  const downloadable = tracks.filter((t) => t.url).length;

  return (
    <div>
      <div className="flex gap-4 p-4">
        {album?.artworkUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={album.artworkUrl} alt="" className="h-36 w-36 shrink-0 rounded-xl bg-zinc-800 object-cover shadow-2xl" />
        ) : (
          <div className="h-36 w-36 shrink-0 rounded-xl bg-zinc-800" />
        )}
        <div className="min-w-0 flex-1">
          <h2 className="line-clamp-2 text-lg font-semibold leading-tight">{album?.name ?? "未知专辑"}</h2>
          <p className="mt-1 truncate text-[15px] text-[#fa2d48]">{album?.artist}</p>
          <p className="mt-1 text-xs text-zinc-400">
            {[album?.genre, album?.releaseDate?.slice(0, 4), tracks.length ? `${tracks.length} 首` : null]
              .filter(Boolean)
              .join(" · ")}
          </p>
          {data && (
            <span
              className={`mt-2 inline-block rounded-full px-2 py-0.5 text-[11px] ${
                data.source === "apple" ? "bg-white/10 text-zinc-300" : "bg-amber-500/15 text-amber-300"
              }`}
            >
              来源：{sourceLabel(data.source)}
              {data.fallback ? ` · 匹配 ${data.fallback.matched}/${data.fallback.total}` : ""}
            </span>
          )}
        </div>
      </div>

      {error && (
        <div className="mx-4 mb-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-200">
          {error}
        </div>
      )}

      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-3">
        <Pill onClick={() => props.onDownloadAll(tracks, album?.url)} disabled={downloadable === 0 || !!props.batchProgress} primary>
          {props.batchProgress ? `下载中 ${props.batchProgress}` : `下载全部预览 (${downloadable})`}
        </Pill>
        <Pill onClick={() => props.onExport(tracks, `${album?.artist} - ${album?.name}`)} disabled={tracks.length === 0}>
          复制歌名+URL 清单
        </Pill>
        {album?.url && <Pill onClick={() => props.onCopy(album.url)}>复制专辑链接</Pill>}
        <Pill onClick={props.onRetryFallback}>第三方兜底重新获取</Pill>
        {data?.source !== "apple" && <Pill onClick={props.onRetryApple}>重试 Apple</Pill>}
      </div>

      {data?.fallback && (
        <p className="px-4 pb-2 text-xs text-zinc-500">
          Apple 未能输出该专辑曲目，已从 {sourceLabel(data.fallback.provider)}（{data.fallback.artist} -{" "}
          {data.fallback.name}）获取歌单，并用 Apple 单曲搜索逐首匹配歌名与链接。标记“未匹配”的曲目为第三方原始名称。
        </p>
      )}

      {tracks.length === 0 && !error && <Empty title="没有曲目" desc="Apple 与第三方均未返回该专辑的曲目。" />}

      <ul className="divide-y divide-white/5">
        {tracks.map((t, i) => (
          <SongRow
            key={`${t.id}-${i}`}
            song={t}
            index={i + 1}
            compact
            playing={props.nowPlaying?.id === t.id && props.isPlaying}
            onPlay={props.onPlay}
            onDownload={props.onDownload}
            onCopy={props.onCopy}
          />
        ))}
      </ul>

      {album?.copyright && <p className="px-4 py-4 text-[11px] text-zinc-600">{album.copyright}</p>}
    </div>
  );
}

function DownloadsPanel(props: { rows: DownloadRow[]; onClear: () => void; onCopy: (t: string) => void }) {
  const { rows } = props;
  return (
    <div>
      <div className="flex items-center justify-between px-4 pt-4">
        <h2 className="text-lg font-semibold">下载 / 导出记录</h2>
        <span className="text-xs text-zinc-500">{rows.length} 条</span>
      </div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 py-3">
        <a href="/api/downloads?format=txt" className="shrink-0 rounded-full bg-white/10 px-3 py-1.5 text-xs">
          导出 TXT（歌名 + URL）
        </a>
        <a href="/api/downloads?format=json" className="shrink-0 rounded-full bg-white/10 px-3 py-1.5 text-xs">
          导出 JSON
        </a>
        <Pill onClick={props.onClear} disabled={rows.length === 0}>
          清空
        </Pill>
      </div>
      {rows.length === 0 ? (
        <Empty title="暂无记录" desc="下载预览或复制清单后会记录在这里（保存在 PostgreSQL）。" />
      ) : (
        <ul className="divide-y divide-white/5">
          {rows.map((r) => (
            <li key={r.id} className="flex items-center gap-3 px-3 py-2.5">
              {r.artworkUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={r.artworkUrl} alt="" className="h-11 w-11 rounded-md bg-zinc-800 object-cover" loading="lazy" />
              ) : (
                <div className="h-11 w-11 rounded-md bg-zinc-800" />
              )}
              <div className="min-w-0 flex-1">
                <div className="truncate text-[15px]">{r.trackName}</div>
                <div className="truncate text-[12px] text-zinc-400">
                  {r.artistName}
                  {r.albumName ? ` · ${r.albumName}` : ""} · {sourceLabel(r.source)}
                </div>
              </div>
              <div className="flex shrink-0 gap-1">
                {r.appleUrl && (
                  <button type="button" onClick={() => props.onCopy(r.appleUrl!)} className="rounded-full px-2 py-1 text-xs text-zinc-300 active:bg-white/10">
                    复制
                  </button>
                )}
                {r.previewUrl && (
                  <a
                    href={`/api/download?url=${encodeURIComponent(r.previewUrl)}&filename=${encodeURIComponent(`${r.artistName} - ${r.trackName}`)}`}
                    className="rounded-full px-2 py-1 text-xs text-[#fa2d48] active:bg-[#fa2d48]/20"
                  >
                    再下
                  </a>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function LoginPanel(props: {
  account: AccountInfo | null;
  cookieText: string;
  setCookieText: (v: string) => void;
  onFile: (f: File | null) => void;
  busy: boolean;
  msg: string | null;
  onImport: () => void;
  onLogout: () => void;
}) {
  const { account } = props;
  return (
    <div className="space-y-4 p-4">
      <h2 className="text-lg font-semibold">导入 cookies 登录</h2>

      {account ? (
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">{account.label}</div>
              <div className="text-xs text-zinc-400">
                店面 {account.storefront.toUpperCase()} · {account.cookieCount} 条 cookie · token {account.tokenPreview}
              </div>
            </div>
            <span
              className={`rounded-full px-2 py-0.5 text-[11px] ${
                account.verified ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-300"
              }`}
            >
              {account.verified ? "已验证" : "未验证"}
            </span>
          </div>
          {account.verifyMessage && <p className="mt-2 text-xs text-zinc-400">{account.verifyMessage}</p>}
          <button type="button" onClick={props.onLogout} className="mt-3 rounded-full bg-white/10 px-4 py-1.5 text-sm">
            退出登录
          </button>
        </div>
      ) : (
        <p className="text-sm text-zinc-400">
          与 gamdl 一致：在电脑浏览器登录 music.apple.com，用「Get cookies.txt LOCALLY」等扩展导出 Netscape 格式
          cookies.txt，粘贴或选择文件即可。系统会提取 <code className="text-zinc-200">media-user-token</code> 与{" "}
          <code className="text-zinc-200">itua</code>（店面）并通过 amp-api 验证。
        </p>
      )}

      <label className="block">
        <span className="text-xs text-zinc-400">cookies.txt / Cookie 字符串 / JSON</span>
        <textarea
          value={props.cookieText}
          onChange={(e) => props.setCookieText(e.target.value)}
          rows={7}
          placeholder={"# Netscape HTTP Cookie File\n.apple.com\tTRUE\t/\tTRUE\t0\tmedia-user-token\t...\n.apple.com\tTRUE\t/\tTRUE\t0\titua\tCN"}
          className="mt-1 w-full rounded-xl border border-white/10 bg-white/[0.05] p-3 font-mono text-[12px] outline-none focus:border-[#fa2d48]/60"
          spellCheck={false}
        />
      </label>

      <div className="flex flex-wrap items-center gap-2">
        <label className="cursor-pointer rounded-full bg-white/10 px-4 py-2 text-sm">
          选择 cookies.txt
          <input type="file" accept=".txt,.json,text/plain,application/json" className="hidden" onChange={(e) => props.onFile(e.target.files?.[0] ?? null)} />
        </label>
        <button
          type="button"
          onClick={props.onImport}
          disabled={props.busy}
          className="rounded-full bg-[#fa2d48] px-5 py-2 text-sm font-medium text-white disabled:opacity-50"
        >
          {props.busy ? "验证中…" : account ? "重新导入" : "导入并登录"}
        </button>
      </div>

      {props.msg && <p className="rounded-xl bg-white/[0.05] p-3 text-sm text-zinc-200">{props.msg}</p>}

      <div className="rounded-2xl border border-white/10 p-4 text-xs leading-relaxed text-zinc-400">
        <div className="mb-1 font-medium text-zinc-200">iOS 18 安装方式（无需签名 IPA）</div>
        Safari 打开本站 → 分享 → 「添加到主屏幕」，即以全屏 PWA 运行。登录状态与下载记录保存在服务端数据库。
        <div className="mt-2 font-medium text-zinc-200">说明</div>
        本工具不做 DRM 解密；「下载」提供 Apple 官方预览片段 (m4a) 与歌名 + Apple Music URL 清单，完整曲目请在 Apple Music 中播放。
      </div>
    </div>
  );
}

/* ------------------------------ atoms --------------------------------- */

function Pill({
  children,
  onClick,
  disabled,
  primary,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  primary?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`shrink-0 rounded-full px-3 py-1.5 text-xs disabled:opacity-40 ${
        primary ? "bg-[#fa2d48] font-medium text-white" : "bg-white/10 text-zinc-200"
      }`}
    >
      {children}
    </button>
  );
}

function Empty({ title, desc, children }: { title: string; desc: string; children?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center px-8 py-16 text-center">
      <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#fa2d48] to-[#a3143c] text-2xl shadow-lg">
        ♫
      </div>
      <h3 className="text-base font-semibold">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-zinc-400">{desc}</p>
      {children}
    </div>
  );
}
