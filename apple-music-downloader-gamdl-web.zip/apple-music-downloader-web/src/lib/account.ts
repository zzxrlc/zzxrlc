import { desc } from "drizzle-orm";
import { db } from "@/db";
import { accounts, type Account } from "@/db/schema";
import { decryptSecret } from "@/lib/secret";

export async function getActiveAccount(): Promise<Account | null> {
  const rows = await db.select().from(accounts).orderBy(desc(accounts.id)).limit(1);
  return rows[0] ?? null;
}

export async function getStorefront(): Promise<string> {
  const account = await getActiveAccount();
  return account?.storefront ?? "us";
}

export async function getActiveCookies(): Promise<string | null> {
  const account = await getActiveAccount();
  if (!account) return null;
  return decryptSecret(account.encryptedCookies);
}
