# 公网部署（自用/家庭服务器）

这个版本把原来的「Apple 官方 30 秒预览下载」改为服务端调用 `gamdl`。
它适合部署成你自己的私有网站：手机浏览器访问网站，服务器负责运行 gamdl。
请只下载你有权使用的内容，并遵守 Apple Music、版权方及所在地法律/服务条款。

## 1. 环境

- Linux x86_64
- Node.js 22+
- Python 3.10+
- PostgreSQL 14+
- FFmpeg
- `gamdl` 3.8.5（本仓库可从 `vendor/gamdl` 安装）

## 2. 安装

```bash
npm install
python3 -m venv .venv
. .venv/bin/activate
pip install ./vendor/gamdl
```

如果本机没有 Rust/Cargo，gamdl 3.8.5 的本地扩展可能需要先安装 Rust 工具链。

## 3. 数据库

```bash
npx drizzle-kit push
```

## 4. 环境变量

复制 `.env.example` 为 `.env`，填写 PostgreSQL 和 32 字节 base64 加密密钥。

```bash
openssl rand -base64 32
```

## 5. 启动

```bash
npm run build
npm start
```

建议用 Nginx/Caddy 反代到 `127.0.0.1:3000` 并启用 HTTPS。

## 6. 使用

1. 手机打开网站。
2. 进入「登录」。
3. 导入自己 Apple Music 登录会话导出的 Netscape `cookies.txt`。
4. 搜索歌曲/专辑。
5. 下载按钮会调用 `/api/gamdl`，由服务器执行 gamdl。
6. 单曲返回媒体文件，专辑/多文件返回 ZIP。

### 安全建议

这是一个“自托管”方案，不建议开放给陌生人使用。cookies 是登录凭据的一部分，数据库中使用 AES-256-GCM 加密保存，但服务器管理员/运行环境仍然可以访问运行时明文。请使用强随机 `APP_ENCRYPTION_KEY`、HTTPS、防火墙，并设置 `SITE_USER` / `SITE_PASSWORD` 保护整个网站；定期清理账户。

不要把 cookies 提交给第三方网站，也不要把 `APP_ENCRYPTION_KEY` 提交到 Git。
