#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "==> 安装依赖"
npm install

echo "==> 创建数据目录"
mkdir -p data/logs data/media/out data/media/in

echo "==> 构建生产版本"
npm run build

echo "==> 安装完成。使用 ./start.sh 启动服务"
