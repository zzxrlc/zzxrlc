/**
 * Next.js instrumentation hook — runs once when the Node.js server boots.
 *
 * We use it to (1) start the media housekeeping loop and (2) restore a saved
 * QQ Bot connection (credentials are persisted, so a server restart reconnects
 * automatically without the browser being open).
 */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  const { startHousekeeping } = await import("@/server/housekeeping");
  startHousekeeping();

  const { ensureStarted } = await import("@/server/runtime");
  void ensureStarted().catch(() => {
    /* failure is already logged inside ensureStarted */
  });
}
