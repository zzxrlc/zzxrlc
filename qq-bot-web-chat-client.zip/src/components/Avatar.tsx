"use client";

import { initials } from "@/lib/format";

const PALETTE = [
  "bg-rose-500",
  "bg-orange-500",
  "bg-amber-500",
  "bg-emerald-500",
  "bg-teal-500",
  "bg-sky-500",
  "bg-indigo-500",
  "bg-violet-500",
  "bg-fuchsia-500",
];

function hash(name: string): number {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export default function Avatar({
  name,
  url,
  size = 40,
}: {
  name?: string | null;
  url?: string | null;
  size?: number;
}) {
  if (url) {
    return (
      <img
        src={url}
        alt={name || ""}
        width={size}
        height={size}
        className="rounded-full object-cover ring-1 ring-black/5 dark:ring-white/10"
        style={{ width: size, height: size }}
      />
    );
  }
  const color = PALETTE[hash(name || "bot") % PALETTE.length];
  return (
    <div
      className={`flex shrink-0 items-center justify-center rounded-full font-medium text-white ${color}`}
      style={{ width: size, height: size, fontSize: Math.max(11, size * 0.38) }}
      aria-hidden
    >
      {initials(name)}
    </div>
  );
}
