"use client";

import { useMemo, useState } from "react";
import { api, type AttachmentMeta, type Message, type QQErrorDetail } from "@/lib/api";
import { formatBytes, formatDuration, formatFullTime } from "@/lib/format";
import Avatar from "./Avatar";
import Lightbox from "./Lightbox";

function attachmentSrc(message: Message, attach: AttachmentMeta): string | null {
  if (attach.localId) return api.mediaOut(attach.localId);
  if (attach.localIdx !== undefined) return api.mediaIn(message.id, attach.localIdx);
  return attach.url || null;
}

function parseError(raw: string | null): QQErrorDetail | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as QQErrorDetail;
  } catch {
    return null;
  }
}

function MediaImage({ src, alt }: { src: string; alt?: string }) {
  const [state, setState] = useState<"loading" | "ok" | "error">("loading");
  return (
    <div className="relative">
      {state === "loading" && (
        <div className="flex h-40 w-56 items-center justify-center rounded-lg bg-black/10 dark:bg-white/10">
          <span className="h-5 w-5 animate-spin-slow rounded-full border-2 border-current border-t-transparent opacity-50" />
        </div>
      )}
      {state === "error" && (
        <div className="flex h-40 w-56 flex-col items-center justify-center gap-1 rounded-lg bg-black/10 text-xs text-slate-500 dark:bg-white/10">
          <span>图片加载失败</span>
        </div>
      )}
      <img
        src={src}
        alt={alt || ""}
        loading="lazy"
        onLoad={() => setState("ok")}
        onError={() => setState("error")}
        className={`max-h-72 max-w-[260px] cursor-zoom-in rounded-lg object-contain ${state === "ok" ? "block" : "hidden"}`}
      />
    </div>
  );
}

function VoiceMessage({ src, asrText }: { src: string; asrText?: string }) {
  const [duration, setDuration] = useState<number | null>(null);
  return (
    <div className="flex items-center gap-3">
      <audio
        controls
        preload="metadata"
        src={src}
        onLoadedMetadata={(e) => {
          const d = (e.target as HTMLAudioElement).duration;
          if (Number.isFinite(d)) setDuration(d);
        }}
        className="h-10 max-w-[240px]"
      />
      <span className="text-xs opacity-70">{formatDuration(duration ?? undefined)}</span>
      {asrText && <span className="max-w-[220px] text-xs italic opacity-60 line-clamp-2">{asrText}</span>}
    </div>
  );
}

function FileMessage({ src, attach }: { src: string; attach: AttachmentMeta }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-black/10 text-lg dark:bg-white/10">📄</div>
      <div className="min-w-0">
        <div className="truncate text-sm font-medium">{attach.filename || "文件"}</div>
        <div className="text-xs opacity-60">{formatBytes(attach.size)}</div>
      </div>
      <a
        href={src}
        download={attach.filename || "file"}
        className="ml-2 shrink-0 rounded-md bg-black/10 px-2.5 py-1 text-xs font-medium hover:bg-black/20 dark:bg-white/10 dark:hover:bg-white/20"
      >
        下载
      </a>
    </div>
  );
}

export default function MessageBubble({
  message,
  showSender,
  uploadProgress,
}: {
  message: Message;
  showSender: boolean;
  uploadProgress?: { uploaded: number; total: number };
}) {
  const isOut = message.direction === "out";
  const error = useMemo(() => parseError(message.error), [message.error]);
  const [lightbox, setLightbox] = useState<string | null>(null);

  return (
    <div className={`flex w-full gap-2 px-3 sm:px-4 ${isOut ? "flex-row-reverse" : ""}`}>
      <Avatar name={isOut ? "Bot" : message.senderName} size={34} />
      <div className={`flex max-w-[78%] flex-col gap-0.5 sm:max-w-[70%] ${isOut ? "items-end" : "items-start"}`}>
        {(showSender || isOut) && (
          <span className="px-1 text-xs text-slate-500 dark:text-slate-400">
            {isOut ? "我" : message.senderName || "用户"} · {formatFullTime(message.createdAt)}
          </span>
        )}

        <div
          className={`rounded-2xl px-3 py-2 text-[15px] leading-relaxed ${
            isOut ? "bg-blue-500 text-white" : "bg-white text-slate-900 shadow-sm dark:bg-slate-800 dark:text-slate-100"
          }`}
        >
          {message.msgType === "text" && <span className="whitespace-pre-wrap break-words">{message.text}</span>}

          {message.msgType === "image" && message.attachments[0] && (
            <button onClick={() => setLightbox(attachmentSrc(message, message.attachments[0]))} className="block">
              <MediaImage src={attachmentSrc(message, message.attachments[0])!} alt={message.attachments[0].filename} />
            </button>
          )}

          {message.msgType === "video" && message.attachments[0] && (
            <video
              controls
              preload="metadata"
              src={attachmentSrc(message, message.attachments[0])!}
              className="max-h-72 max-w-[320px] rounded-lg bg-black"
            />
          )}

          {message.msgType === "voice" && message.attachments[0] && (
            <VoiceMessage src={attachmentSrc(message, message.attachments[0])!} asrText={message.attachments[0].asrText} />
          )}

          {message.msgType === "file" && message.attachments[0] && (
            <FileMessage src={attachmentSrc(message, message.attachments[0])!} attach={message.attachments[0]} />
          )}
        </div>

        {message.status === "sending" && !error && (
          <span className="px-1 text-[11px] text-slate-400">
            {uploadProgress && uploadProgress.total > 0
              ? `上传中 ${Math.min(99, Math.floor((uploadProgress.uploaded / uploadProgress.total) * 100))}%`
              : "发送中…"}
          </span>
        )}
        {error && (
          <span className="max-w-full px-1 text-[11px] text-red-500" title={`错误码: ${error.code}${error.raw ? `\n${error.raw}` : ""}`}>
            发送失败：{error.message}
            {error.suggestion ? `（${error.suggestion}）` : ""}
          </span>
        )}

        {lightbox && <Lightbox src={lightbox} onClose={() => setLightbox(null)} />}
      </div>
    </div>
  );
}
