"use client";

import { useState } from "react";

export default function ConnectScreen({
  onConnect,
  error,
  connecting,
  dark,
  onToggleDark,
}: {
  onConnect: (appId: string, appSecret: string) => void;
  error: string | null;
  connecting: boolean;
  dark: boolean;
  onToggleDark: () => void;
}) {
  const [appId, setAppId] = useState("");
  const [appSecret, setAppSecret] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    onConnect(appId, appSecret);
  };

  return (
    <div className="flex min-h-full items-center justify-center p-4">
      <button
        onClick={onToggleDark}
        className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full text-xl hover:bg-slate-200 dark:hover:bg-slate-800"
        aria-label="切换主题"
      >
        {dark ? "☀️" : "🌙"}
      </button>

      <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-[0_24px_60px_rgba(16,24,40,0.12)] dark:bg-slate-900 dark:ring-1 dark:ring-white/10">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 text-3xl shadow-lg">
            🤖
          </div>
          <h1 className="text-2xl font-semibold">QQ Bot Web</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            输入机器人凭证，自动完成鉴权并建立实时连接
          </p>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div>
            <label htmlFor="appid" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
              AppID
            </label>
            <input
              id="appid"
              value={appId}
              onChange={(e) => setAppId(e.target.value)}
              placeholder="在 QQ 开放平台获得的 AppID"
              autoComplete="off"
              required
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-[15px] outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-800 dark:focus:ring-blue-900/40"
            />
          </div>

          <div>
            <label htmlFor="appsecret" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
              AppSecret
            </label>
            <input
              id="appsecret"
              type="password"
              value={appSecret}
              onChange={(e) => setAppSecret(e.target.value)}
              placeholder="在 QQ 开放平台获得的 AppSecret"
              autoComplete="new-password"
              required
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-[15px] outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-800 dark:focus:ring-blue-900/40"
            />
          </div>

          {error && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-600 dark:border-red-900/40 dark:bg-red-950/40 dark:text-red-400">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={connecting}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-500 py-2.5 text-[15px] font-medium text-white transition hover:bg-blue-600 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {connecting ? (
              <>
                <span className="h-4 w-4 animate-spin-slow rounded-full border-2 border-white border-t-transparent" />
                正在鉴权并连接…
              </>
            ) : (
              "连接 QQ Bot"
            )}
          </button>
        </form>

        <p className="mt-5 text-center text-xs leading-relaxed text-slate-400">
          AppSecret 仅保存在服务器本地（AES 加密），不会写入日志或发送到浏览器之外。
        </p>
      </div>
    </div>
  );
}
