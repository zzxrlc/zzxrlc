"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError, uploadMedia, type Conversation, type Message } from "@/lib/api";
import { clientBus } from "@/lib/events";
import Avatar from "./Avatar";
import Composer, { type SendKind } from "./Composer";
import MessageBubble from "./MessageBubble";

function upsertMsg(list: Message[], msg: Message): Message[] {
  const idx = list.findIndex((m) => m.id === msg.id);
  if (idx === -1) {
    const next = [...list, msg];
    next.sort((a, b) => a.seq - b.seq);
    return next;
  }
  const next = [...list];
  next[idx] = msg;
  return next;
}

function errText(e: unknown): string {
  if (e instanceof ApiError) {
    return `${e.detail.message}${e.detail.suggestion ? `（${e.detail.suggestion}）` : ""}`;
  }
  return "发送失败，请稍后重试";
}

export default function ChatPane({
  conversation,
  connected,
  onBack,
}: {
  conversation: Conversation;
  connected: boolean;
  onBack?: () => void;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [progress, setProgress] = useState<Record<string, { uploaded: number; total: number }>>({});

  const scrollRef = useRef<HTMLDivElement>(null);
  const nearBottomRef = useRef(true);
  const messagesRef = useRef<Message[]>([]);
  const hasMoreRef = useRef(false);
  const loadingMoreRef = useRef(false);
  const convIdRef = useRef(conversation.id);

  messagesRef.current = messages;
  hasMoreRef.current = hasMore;
  convIdRef.current = conversation.id;

  // Initial load + reset on conversation switch.
  useEffect(() => {
    let alive = true;
    setMessages([]);
    setHasMore(false);
    setSendError(null);
    setProgress({});
    setLoading(true);
    api
      .messages(conversation.id, 50)
      .then((res) => {
        if (!alive) return;
        setMessages(res.messages);
        setHasMore(res.hasMore);
        setLoading(false);
        nearBottomRef.current = true;
        requestAnimationFrame(() => {
          const el = scrollRef.current;
          if (el) el.scrollTop = el.scrollHeight;
        });
      })
      .catch(() => {
        if (alive) setLoading(false);
      });
    void api.markRead(conversation.id);
    return () => {
      alive = false;
    };
  }, [conversation.id]);

  // Realtime updates via SSE.
  useEffect(() => {
    return clientBus.subscribe(({ type, data }) => {
      if (type === "message") {
        const { message } = data as { message: Message };
        if (message.conversationId === convIdRef.current) {
          setMessages((prev) => upsertMsg(prev, message));
          void api.markRead(convIdRef.current);
        }
      } else if (type === "upload_progress") {
        const p = data as { messageId: string; uploaded: number; total: number };
        setProgress((prev) => ({ ...prev, [p.messageId]: p }));
      }
    });
  }, []);

  const loadMore = useCallback(async () => {
    if (loadingMoreRef.current || !hasMoreRef.current) return;
    const first = messagesRef.current[0];
    if (!first) return;
    loadingMoreRef.current = true;
    setLoadingMore(true);
    try {
      const res = await api.messages(convIdRef.current, 50, first.seq);
      setMessages((prev) => {
        const seen = new Set(prev.map((m) => m.id));
        const extra = res.messages.filter((m) => !seen.has(m.id));
        return [...extra, ...prev].sort((a, b) => a.seq - b.seq);
      });
      setHasMore(res.hasMore);
    } finally {
      loadingMoreRef.current = false;
      setLoadingMore(false);
    }
  }, []);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    nearBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    if (el.scrollTop < 60) void loadMore();
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (!el || !nearBottomRef.current) return;
    el.scrollTop = el.scrollHeight;
  }, [messages]);

  const handleSendText = async (text: string) => {
    try {
      await api.sendText(conversation.id, text);
    } catch (e) {
      setSendError(errText(e));
    }
  };

  const handleSendFile = (file: File, kind: SendKind) => {
    setBusy("正在上传…");
    setSendError(null);
    uploadMedia(conversation.id, file, kind, () => {})
      .catch((e) => setSendError(errText(e)))
      .finally(() => setBusy(null));
  };

  return (
    <div className="flex h-full min-w-0 flex-1 flex-col">
      {/* header */}
      <header className="flex items-center gap-2 border-b border-slate-200 bg-white/80 px-3 py-2.5 backdrop-blur dark:border-slate-800 dark:bg-slate-900/80">
        {onBack && (
          <button
            onClick={onBack}
            className="mr-1 flex h-8 w-8 items-center justify-center rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden"
            aria-label="返回"
          >
            ←
          </button>
        )}
        <Avatar name={conversation.title} url={conversation.avatar} size={36} />
        <div className="min-w-0">
          <div className="truncate font-medium leading-tight">{conversation.title}</div>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span className={`h-1.5 w-1.5 rounded-full ${connected ? "bg-emerald-500" : "bg-red-500"}`} />
            {connected ? (conversation.scope === "c2c" ? "私聊" : "群聊") : "已断开"}
          </div>
        </div>
      </header>

      {/* messages */}
      <div ref={scrollRef} onScroll={onScroll} className="flex-1 space-y-3 overflow-y-auto py-4">
        {loadingMore && (
          <div className="flex justify-center py-2 text-xs text-slate-400">正在加载历史消息…</div>
        )}
        {loading ? (
          <div className="flex h-full items-center justify-center text-sm text-slate-400">加载中…</div>
        ) : messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-slate-400">
            <div className="text-4xl">💬</div>
            <div className="text-sm">还没有消息</div>
            <div className="text-xs">在 QQ 里给机器人发消息，或从下方开始发送</div>
          </div>
        ) : (
          messages.map((m, i) => {
            const prev = messages[i - 1];
            const showSender = !prev || prev.senderId !== m.senderId || prev.msgType !== m.msgType;
            return <MessageBubble key={m.id} message={m} showSender={showSender} uploadProgress={progress[m.id]} />;
          })
        )}
      </div>

      {sendError && (
        <div className="flex items-center justify-between gap-2 border-t border-red-200 bg-red-50 px-3 py-2 text-xs text-red-600 dark:border-red-900/40 dark:bg-red-950/40 dark:text-red-400">
          <span className="line-clamp-2">{sendError}</span>
          <button onClick={() => setSendError(null)} className="shrink-0 rounded px-2 py-0.5 hover:bg-red-100 dark:hover:bg-red-900/40">
            关闭
          </button>
        </div>
      )}

      <Composer onSendText={handleSendText} onSendFile={handleSendFile} disabled={!connected} busy={busy ?? undefined} />
    </div>
  );
}
