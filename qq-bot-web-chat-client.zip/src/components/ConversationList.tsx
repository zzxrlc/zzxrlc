"use client";

import type { Conversation } from "@/lib/api";
import { formatTime } from "@/lib/format";
import Avatar from "./Avatar";

export default function ConversationList({
  conversations,
  activeId,
  onSelect,
}: {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
}) {
  const c2c = conversations.filter((c) => c.scope === "c2c");
  const groups = conversations.filter((c) => c.scope === "group");

  if (conversations.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 text-center text-sm text-slate-400">
        <div className="text-3xl">📭</div>
        <p>暂无会话</p>
        <p className="text-xs">在 QQ 中私聊或 @ 机器人后，会话会出现在这里</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto py-1">
      <Section title="私聊" items={c2c} activeId={activeId} onSelect={onSelect} />
      <Section title="群聊" items={groups} activeId={activeId} onSelect={onSelect} />
    </div>
  );
}

function Section({
  title,
  items,
  activeId,
  onSelect,
}: {
  title: string;
  items: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
}) {
  if (items.length === 0) return null;
  return (
    <div className="mb-1">
      <div className="px-4 pb-1 pt-2 text-xs font-medium uppercase tracking-wider text-slate-400">{title}</div>
      {items.map((c) => (
        <button
          key={c.id}
          onClick={() => onSelect(c.id)}
          className={`flex w-full items-center gap-3 px-3 py-2.5 text-left transition ${
            activeId === c.id ? "bg-blue-50 dark:bg-slate-800" : "hover:bg-slate-100 dark:hover:bg-slate-900"
          }`}
        >
          <Avatar name={c.title} url={c.avatar} size={42} />
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <span className="truncate text-sm font-medium">{c.title}</span>
              <span className="shrink-0 text-[11px] text-slate-400">{formatTime(c.lastMessageAt)}</span>
            </div>
            <div className="mt-0.5 flex items-center justify-between gap-2">
              <span className="truncate text-xs text-slate-500 dark:text-slate-400">{c.lastPreview || " "}</span>
              {c.unread > 0 && (
                <span className="flex h-[18px] min-w-[18px] shrink-0 items-center justify-center rounded-full bg-red-500 px-1 text-[11px] font-semibold text-white">
                  {c.unread > 99 ? "99+" : c.unread}
                </span>
              )}
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}
