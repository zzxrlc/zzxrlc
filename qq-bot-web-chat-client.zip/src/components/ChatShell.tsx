"use client";

import type { BotStatus, Conversation, FriendEvent, GroupRobotEvent, JoinRequest } from "@/lib/api";
import Avatar from "./Avatar";
import ChatPane from "./ChatPane";
import ConversationList from "./ConversationList";
import RequestPanel from "./RequestPanel";

function statusMeta(status: BotStatus["status"]) {
  switch (status) {
    case "connected":
      return { label: "已连接", dot: "bg-emerald-500", color: "text-emerald-600 dark:text-emerald-400" };
    case "connecting":
      return { label: "连接中…", dot: "bg-amber-500 animate-pulse-dot", color: "text-amber-600 dark:text-amber-400" };
    case "error":
      return { label: "连接错误", dot: "bg-red-500", color: "text-red-600 dark:text-red-400" };
    default:
      return { label: "已断开", dot: "bg-slate-400", color: "text-slate-500 dark:text-slate-400" };
  }
}

export default function ChatShell({
  status,
  conversations,
  activeId,
  onSelect,
  onBack,
  onDisconnect,
  onReconnect,
  onChangeCreds,
  dark,
  onToggleDark,
  showRequests,
  onToggleRequests,
  requests,
  pendingCount,
  processingId,
  requestError,
  onApproveJoin,
  onDeclineJoin,
  onOpenChat,
}: {
  status: BotStatus;
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onBack: () => void;
  onDisconnect: () => void;
  onReconnect: () => void;
  onChangeCreds: () => void;
  dark: boolean;
  onToggleDark: () => void;
  showRequests: boolean;
  onToggleRequests: () => void;
  requests: { friends: FriendEvent[]; groupEvents: GroupRobotEvent[]; joinRequests: JoinRequest[] };
  pendingCount: number;
  processingId: string | null;
  requestError: string | null;
  onApproveJoin: (id: string) => void;
  onDeclineJoin: (id: string, reason?: string) => void;
  onOpenChat: (openid: string) => void;
}) {
  const active = conversations.find((c) => c.id === activeId) || null;
  const meta = statusMeta(status.status);

  return (
    <div className="mx-auto flex h-full max-w-6xl overflow-hidden bg-white shadow-2xl dark:bg-slate-900 sm:my-0 sm:h-full sm:max-w-none sm:rounded-none sm:shadow-none">
      {/* sidebar */}
      <aside
        className={`${showRequests ? "flex" : activeId ? "hidden lg:flex" : "flex"} w-full flex-col border-r border-slate-200 dark:border-slate-800 lg:w-[320px] lg:shrink-0`}
      >
        <div className="flex items-center gap-3 border-b border-slate-200 px-4 py-3 dark:border-slate-800">
          <Avatar name={status.bot?.username || "QQ Bot"} url={status.bot?.avatar} size={42} />
          <div className="min-w-0 flex-1">
            <div className="truncate font-semibold leading-tight">{status.bot?.username || "QQ Bot"}</div>
            <div className={`flex items-center gap-1.5 text-xs ${meta.color}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
              {meta.label}
            </div>
          </div>

          <button
            onClick={onToggleRequests}
            className={`relative flex h-9 w-9 items-center justify-center rounded-full text-lg transition hover:bg-slate-100 dark:hover:bg-slate-800 ${showRequests ? "bg-blue-50 dark:bg-slate-800" : ""}`}
            title="通知与请求"
            aria-label="通知与请求"
          >
            🔔
            {pendingCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-semibold text-white">
                {pendingCount > 99 ? "99+" : pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={onToggleDark}
            className="flex h-9 w-9 items-center justify-center rounded-full text-lg hover:bg-slate-100 dark:hover:bg-slate-800"
            title={dark ? "切换到浅色模式" : "切换到深色模式"}
            aria-label="切换主题"
          >
            {dark ? "☀️" : "🌙"}
          </button>
        </div>

        {showRequests ? (
          <RequestPanel
            data={requests}
            processingId={processingId}
            error={requestError}
            onApprove={onApproveJoin}
            onDecline={onDeclineJoin}
            onOpenChat={onOpenChat}
            onBack={() => onToggleRequests()}
          />
        ) : (
          <ConversationList conversations={conversations} activeId={activeId} onSelect={onSelect} />
        )}

        {!showRequests && (
          <div className="space-y-2 border-t border-slate-200 p-2 dark:border-slate-800">
            {status.lastError && status.status === "error" && (
              <p className="line-clamp-2 px-1 text-xs text-red-500">{status.lastError}</p>
            )}
            {status.connected ? (
              <button
                onClick={onDisconnect}
                className="w-full rounded-lg px-3 py-2 text-sm text-slate-500 transition hover:bg-red-50 hover:text-red-600 dark:text-slate-400 dark:hover:bg-red-950/40 dark:hover:text-red-400"
              >
                断开连接
              </button>
            ) : (
              <button
                onClick={onReconnect}
                className="w-full rounded-lg bg-blue-500 px-3 py-2 text-sm font-medium text-white transition hover:bg-blue-600"
              >
                {status.status === "connecting" ? "连接中…" : "重新连接"}
              </button>
            )}
            <button
              onClick={onChangeCreds}
              className="w-full rounded-lg px-3 py-1.5 text-xs text-slate-400 transition hover:text-slate-600 dark:hover:text-slate-300"
            >
              更换凭证
            </button>
          </div>
        )}
      </aside>

      {/* main pane */}
      <main className={`${activeId && !showRequests ? "flex" : "hidden lg:flex"} min-w-0 flex-1 flex-col`}>
        {active && !showRequests ? (
          <ChatPane conversation={active} connected={status.connected} onBack={onBack} />
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-slate-400">
            <div className="text-6xl">🤖</div>
            <div className="text-base font-medium text-slate-500 dark:text-slate-400">选择左侧会话开始聊天</div>
            <div className="text-xs">实时接收 QQ 私聊与群聊消息</div>
          </div>
        )}
      </main>
    </div>
  );
}
