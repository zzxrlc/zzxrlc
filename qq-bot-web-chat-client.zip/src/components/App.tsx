"use client";

import { useEffect, useRef, useState } from "react";
import {
  api,
  ApiError,
  type BotStatus,
  type Conversation,
  type FriendEvent,
  type GroupRobotEvent,
  type JoinRequest,
  type Message,
} from "@/lib/api";
import { clientBus } from "@/lib/events";
import ChatShell from "./ChatShell";
import ConnectScreen from "./ConnectScreen";

function upsertConv(list: Conversation[], conv: Conversation): Conversation[] {
  const idx = list.findIndex((c) => c.id === conv.id);
  const next = idx === -1 ? [...list, conv] : list.map((c) => (c.id === conv.id ? conv : c));
  next.sort((a, b) => b.lastMessageAt - a.lastMessageAt);
  return next;
}

interface RequestsState {
  friends: FriendEvent[];
  groupEvents: GroupRobotEvent[];
  joinRequests: JoinRequest[];
}

function errText(e: unknown): string {
  if (e instanceof ApiError) return `${e.detail.message}${e.detail.suggestion ? `（${e.detail.suggestion}）` : ""}`;
  return "操作失败，请稍后重试";
}

export default function App() {
  const [status, setStatus] = useState<BotStatus | null>(null);
  const [view, setView] = useState<"loading" | "connect" | "chat">("loading");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [connectError, setConnectError] = useState<string | null>(null);
  const [dark, setDark] = useState<boolean>(() =>
    typeof document !== "undefined" ? document.documentElement.classList.contains("dark") : false,
  );

  const [showRequests, setShowRequests] = useState(false);
  const [requests, setRequests] = useState<RequestsState>({ friends: [], groupEvents: [], joinRequests: [] });
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [requestError, setRequestError] = useState<string | null>(null);

  const activeIdRef = useRef<string | null>(null);
  activeIdRef.current = activeId;

  // Boot: load status + conversations + requests, then open the SSE stream.
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const s = await api.status();
        if (!alive) return;
        setStatus(s);
        setView(s.hasCredentials ? "chat" : "connect");
      } catch {
        if (alive) setView("connect");
      }
      try {
        const list = await api.conversations();
        if (alive) setConversations(list);
      } catch {
        /* non-fatal */
      }
      try {
        const r = await api.requests();
        if (alive) setRequests({ friends: r.friends, groupEvents: r.groupEvents, joinRequests: r.joinRequests });
      } catch {
        /* non-fatal */
      }
    })();

    const es = new EventSource("/api/events");
    const onEvent = (ev: MessageEvent) => {
      try {
        clientBus.emit(ev.type || "message", JSON.parse(ev.data));
      } catch {
        /* ignore malformed */
      }
    };
    es.addEventListener("status", onEvent);
    es.addEventListener("message", onEvent);
    es.addEventListener("conversation", onEvent);
    es.addEventListener("upload_progress", onEvent);
    es.addEventListener("friend_add", onEvent);
    es.addEventListener("group_robot_add", onEvent);
    es.addEventListener("group_robot_del", onEvent);
    es.addEventListener("join_request", onEvent);
    return () => {
      alive = false;
      es.close();
    };
  }, []);

  // Realtime updates via SSE.
  useEffect(() => {
    return clientBus.subscribe(({ type, data }) => {
      if (type === "status") {
        const s = data as BotStatus;
        setStatus(s);
        if (s.hasCredentials) setView((v) => (v === "connect" ? "chat" : v));
      } else if (type === "message") {
        const { conversation } = data as { message: Message; conversation: Conversation };
        setConversations((prev) => {
          const isActive = conversation.id === activeIdRef.current;
          return upsertConv(prev, isActive ? { ...conversation, unread: 0 } : conversation);
        });
      } else if (type === "conversation") {
        setConversations((prev) => upsertConv(prev, data as Conversation));
      } else if (type === "friend_add") {
        const f = data as FriendEvent;
        setRequests((prev) => ({ ...prev, friends: [f, ...prev.friends.filter((x) => x.id !== f.id)] }));
      } else if (type === "group_robot_add" || type === "group_robot_del") {
        const g = data as GroupRobotEvent;
        setRequests((prev) => ({ ...prev, groupEvents: [g, ...prev.groupEvents.filter((x) => x.id !== g.id)] }));
      } else if (type === "join_request") {
        const r = data as JoinRequest;
        setRequests((prev) => {
          const idx = prev.joinRequests.findIndex((x) => x.id === r.id);
          const list = idx === -1 ? [r, ...prev.joinRequests] : prev.joinRequests.map((x) => (x.id === r.id ? r : x));
          return { ...prev, joinRequests: list };
        });
      }
    });
  }, []);

  const toggleDark = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("qqbot-theme", next ? "dark" : "light");
    } catch {
      /* ignore */
    }
  };

  const handleConnect = async (appId: string, appSecret: string) => {
    setConnecting(true);
    setConnectError(null);
    try {
      const s = await api.connect(appId, appSecret);
      setStatus(s);
      setView("chat");
      api.conversations().then(setConversations).catch(() => {});
      api
        .requests()
        .then((r) => setRequests({ friends: r.friends, groupEvents: r.groupEvents, joinRequests: r.joinRequests }))
        .catch(() => {});
    } catch (e) {
      setConnectError(errText(e));
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    const s = await api.disconnect().catch(() => null);
    if (s) setStatus(s);
  };

  const handleReconnect = async () => {
    const s = await api.reconnect().catch(() => null);
    if (s) setStatus(s);
  };

  const handleApprove = async (id: string) => {
    setProcessingId(id);
    setRequestError(null);
    try {
      const updated = await api.approveJoin(id);
      setRequests((prev) => ({ ...prev, joinRequests: prev.joinRequests.map((r) => (r.id === id ? updated : r)) }));
    } catch (e) {
      setRequestError(errText(e));
    } finally {
      setProcessingId(null);
    }
  };

  const handleDecline = async (id: string, reason?: string) => {
    setProcessingId(id);
    setRequestError(null);
    try {
      const updated = await api.declineJoin(id, reason);
      setRequests((prev) => ({ ...prev, joinRequests: prev.joinRequests.map((r) => (r.id === id ? updated : r)) }));
    } catch (e) {
      setRequestError(errText(e));
    } finally {
      setProcessingId(null);
    }
  };

  const handleOpenChat = async (openid: string) => {
    const id = `c2c:${openid}`;
    setShowRequests(false);
    setActiveId(id);
    try {
      const list = await api.conversations();
      setConversations(list);
    } catch {
      /* ignore */
    }
  };

  if (view === "loading" || status === null) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-400">
          <span className="h-8 w-8 animate-spin-slow rounded-full border-2 border-slate-300 border-t-blue-500" />
          <span className="text-sm">加载中…</span>
        </div>
      </div>
    );
  }

  if (view === "connect") {
    return (
      <ConnectScreen
        onConnect={handleConnect}
        error={connectError}
        connecting={connecting}
        dark={dark}
        onToggleDark={toggleDark}
      />
    );
  }

  const pendingCount = requests.joinRequests.filter((r) => r.status === "pending").length;

  return (
    <ChatShell
      status={status}
      conversations={conversations}
      activeId={activeId}
      onSelect={setActiveId}
      onBack={() => setActiveId(null)}
      onDisconnect={handleDisconnect}
      onReconnect={handleReconnect}
      onChangeCreds={() => {
        setConnectError(null);
        setView("connect");
      }}
      dark={dark}
      onToggleDark={toggleDark}
      showRequests={showRequests}
      onToggleRequests={() => {
        setShowRequests((v) => !v);
        if (!showRequests) {
          setRequestError(null);
          api
            .requests()
            .then((r) => setRequests({ friends: r.friends, groupEvents: r.groupEvents, joinRequests: r.joinRequests }))
            .catch(() => {});
        }
      }}
      requests={requests}
      pendingCount={pendingCount}
      processingId={processingId}
      requestError={requestError}
      onApproveJoin={handleApprove}
      onDeclineJoin={handleDecline}
      onOpenChat={handleOpenChat}
    />
  );
}
