"use client";

import { useState } from "react";
import type { FriendEvent, GroupRobotEvent, JoinRequest } from "@/lib/api";
import { formatTime } from "@/lib/format";
import Avatar from "./Avatar";

function verifySummary(info: Record<string, unknown> | null): string {
  if (!info) return "";
  const v = info as { verify_message?: string; review_qa_list?: Array<{ question?: string; answer?: string }> };
  const parts: string[] = [];
  if (v.verify_message) parts.push(String(v.verify_message));
  if (Array.isArray(v.review_qa_list)) {
    for (const qa of v.review_qa_list) {
      if (qa?.question && qa?.answer) parts.push(`${qa.question}：${qa.answer}`);
    }
  }
  return parts.join("；");
}

export default function RequestPanel({
  data,
  processingId,
  error,
  onApprove,
  onDecline,
  onOpenChat,
  onBack,
}: {
  data: { friends: FriendEvent[]; groupEvents: GroupRobotEvent[]; joinRequests: JoinRequest[] };
  processingId: string | null;
  error: string | null;
  onApprove: (id: string) => void;
  onDecline: (id: string, reason?: string) => void;
  onOpenChat: (openid: string) => void;
  onBack: () => void;
}) {
  const pending = data.joinRequests.filter((r) => r.status === "pending");
  const processed = data.joinRequests.filter((r) => r.status !== "pending");

  const doDecline = (id: string) => {
    const reason = window.prompt("请输入拒绝理由（可留空）", "");
    if (reason === null) return; // cancelled
    onDecline(id, reason || undefined);
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 border-b border-slate-200 px-4 py-3 dark:border-slate-800">
        <button
          onClick={onBack}
          className="mr-1 flex h-8 w-8 items-center justify-center rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          aria-label="返回"
        >
          ←
        </button>
        <div>
          <div className="font-semibold leading-tight">通知与请求</div>
          <div className="text-xs text-slate-400">好友申请 · 入群申请 · 机器人入群</div>
        </div>
      </div>

      {error && (
        <div className="mx-3 mt-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-600 dark:border-red-900/40 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </div>
      )}

      <div className="flex-1 overflow-y-auto px-3 py-3">
        <SectionTitle title={`入群申请${pending.length ? `（${pending.length}）` : ""}`} />
        {pending.length === 0 && processed.length === 0 ? (
          <Empty text="暂无入群申请" hint="用户申请加入机器人所在群时会出现在这里（需机器人是群管理员）" />
        ) : (
          <div className="space-y-2">
            {pending.map((r) => (
              <div key={r.id} className="rounded-xl border border-slate-200 p-3 dark:border-slate-700">
                <div className="flex items-center gap-2">
                  <Avatar name={r.username} size={34} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{r.username || r.memberOpenid.slice(-8)}</div>
                    <div className="text-[11px] text-slate-400">
                      {formatTime(r.createdAt)} · {r.applySource === "invited" ? "被邀请入群" : "主动申请"}
                    </div>
                  </div>
                </div>
                {verifySummary(r.verifyInfo) && (
                  <div className="mt-2 rounded-lg bg-slate-50 px-2.5 py-1.5 text-xs text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                    验证信息：{verifySummary(r.verifyInfo)}
                  </div>
                )}
                {r.riskTips && <div className="mt-1.5 text-[11px] text-amber-600 dark:text-amber-400">⚠️ {r.riskTips}</div>}
                <div className="mt-2.5 flex gap-2">
                  <button
                    onClick={() => onApprove(r.id)}
                    disabled={processingId === r.id}
                    className="flex-1 rounded-lg bg-emerald-500 py-1.5 text-sm font-medium text-white hover:bg-emerald-600 disabled:opacity-50"
                  >
                    {processingId === r.id ? "处理中…" : "同意"}
                  </button>
                  <button
                    onClick={() => doDecline(r.id)}
                    disabled={processingId === r.id}
                    className="flex-1 rounded-lg bg-red-500 py-1.5 text-sm font-medium text-white hover:bg-red-600 disabled:opacity-50"
                  >
                    拒绝
                  </button>
                </div>
              </div>
            ))}
            {processed.slice(0, 10).map((r) => (
              <div key={r.id} className="flex items-center gap-2 rounded-xl border border-slate-100 px-3 py-2 opacity-60 dark:border-slate-800">
                <Avatar name={r.username} size={28} />
                <span className="min-w-0 flex-1 truncate text-sm">{r.username || r.memberOpenid.slice(-8)}</span>
                <span className={`text-xs ${r.status === "approved" ? "text-emerald-500" : "text-red-400"}`}>
                  {r.status === "approved" ? "已同意" : "已拒绝"}
                </span>
              </div>
            ))}
          </div>
        )}

        <SectionTitle title="好友申请" />
        {data.friends.length === 0 ? (
          <Empty text="暂无好友申请" hint="用户添加机器人为好友后会出现在这里" />
        ) : (
          <div className="space-y-1">
            {data.friends.slice(0, 30).map((f) => (
              <div key={f.id} className="flex items-center gap-2 rounded-lg px-2 py-1.5">
                <Avatar name={`好友${f.openid.slice(-4)}`} size={34} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm">好友 {f.openid.slice(-6)}</div>
                  <div className="text-[11px] text-slate-400">{formatTime(f.createdAt)} 添加了你</div>
                </div>
                <button
                  onClick={() => onOpenChat(f.openid)}
                  className="shrink-0 rounded-lg bg-blue-500 px-2.5 py-1 text-xs font-medium text-white hover:bg-blue-600"
                >
                  开始聊天
                </button>
              </div>
            ))}
          </div>
        )}

        <SectionTitle title="机器人入群 / 退群" />
        {data.groupEvents.length === 0 ? (
          <Empty text="暂无入群记录" hint="机器人被邀请进群或移出群后会出现在这里" />
        ) : (
          <div className="space-y-1">
            {data.groupEvents.slice(0, 30).map((g) => (
              <div key={g.id} className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm">
                <span className="text-base">{g.eventType === "add" ? "✅" : "🚪"}</span>
                <span className="min-w-0 flex-1 truncate">群 {g.groupOpenid.slice(-8)}</span>
                <span className="text-[11px] text-slate-400">
                  {g.eventType === "add" ? "加入" : "移出"} · {formatTime(g.createdAt)}
                </span>
              </div>
            ))}
          </div>
        )}

        <div className="mt-4 rounded-lg bg-slate-50 px-3 py-2.5 text-[11px] leading-relaxed text-slate-400 dark:bg-slate-800/60 dark:text-slate-500">
          说明：QQ 官方机器人好友添加为自动通过；机器人入群由开放平台「入群方式」配置决定；用户申请加群需机器人拥有群管理员身份，方可在此审批。
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ title }: { title: string }) {
  return <div className="mb-1.5 mt-4 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400 first:mt-0">{title}</div>;
}

function Empty({ text, hint }: { text: string; hint: string }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-200 px-3 py-4 text-center dark:border-slate-700">
      <div className="text-sm text-slate-400">{text}</div>
      <div className="mt-0.5 text-[11px] text-slate-400/70">{hint}</div>
    </div>
  );
}
