"use client";

import { useEffect, useRef, useState } from "react";
import { startVoiceRecording, type Recorder } from "@/lib/voice";

export type SendKind = "image" | "video" | "voice" | "file";

export default function Composer({
  onSendText,
  onSendFile,
  disabled,
  busy,
}: {
  onSendText: (text: string) => void;
  onSendFile: (file: File, kind: SendKind) => void;
  disabled?: boolean;
  busy?: string | null;
}) {
  const [text, setText] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recElapsed, setRecElapsed] = useState(0);
  const [micError, setMicError] = useState<string | null>(null);
  const recorderRef = useRef<Recorder | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      recorderRef.current?.cancel();
    };
  }, []);

  const send = () => {
    const t = text.trim();
    if (!t || disabled) return;
    onSendText(t);
    setText("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
  };

  const pick = (kind: SendKind) => {
    setMenuOpen(false);
    const input = fileInputRef.current;
    if (!input) return;
    input.accept =
      kind === "image"
        ? "image/*"
        : kind === "video"
          ? "video/*"
          : kind === "voice"
            ? "audio/*,.mp3,.wav,.m4a,.ogg,.flac,.silk"
            : "*/*";
    input.value = "";
    input.onchange = () => {
      const f = input.files?.[0];
      if (f) onSendFile(f, kind);
      input.value = "";
    };
    input.click();
  };

  const startRec = async () => {
    setMenuOpen(false);
    setMicError(null);
    try {
      const r = await startVoiceRecording();
      recorderRef.current = r;
      setRecording(true);
      setRecElapsed(0);
      timerRef.current = setInterval(() => setRecElapsed(r.elapsedSeconds()), 200);
    } catch {
      setMicError("无法访问麦克风，请检查浏览器权限");
    }
  };

  const stopRec = async () => {
    setRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
    const r = recorderRef.current;
    recorderRef.current = null;
    if (!r) return;
    try {
      const blob = await r.stop();
      if (blob.size < 44) return; // empty recording
      const file = new File([blob], `voice-${Date.now()}.wav`, { type: "audio/wav" });
      onSendFile(file, "voice");
    } catch {
      setMicError("录音处理失败");
    }
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  return (
    <div className="border-t border-slate-200 bg-white/80 px-3 py-2 backdrop-blur dark:border-slate-800 dark:bg-slate-900/80">
      {(micError || busy) && (
        <div className="mb-1.5 flex items-center justify-between gap-2 px-1 text-xs">
          {micError ? <span className="text-red-500">{micError}</span> : <span className="text-slate-400">{busy}</span>}
        </div>
      )}

      <div className="relative flex items-end gap-2">
        <div className="relative">
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-xl text-slate-500 transition hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
            aria-label="添加附件"
            title="添加图片 / 视频 / 文件 / 语音"
          >
            ＋
          </button>

          {menuOpen && (
            <div className="absolute bottom-12 left-0 z-20 w-40 overflow-hidden rounded-xl bg-white py-1 text-sm shadow-xl ring-1 ring-black/10 dark:bg-slate-800 dark:ring-white/10">
              <MenuItem icon="🖼️" label="图片" onClick={() => pick("image")} />
              <MenuItem icon="🎬" label="视频" onClick={() => pick("video")} />
              <MenuItem icon="📎" label="文件" onClick={() => pick("file")} />
              <MenuItem icon="🎤" label="录音" onClick={startRec} />
              <MenuItem icon="🎵" label="上传音频" onClick={() => pick("voice")} />
            </div>
          )}
        </div>

        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            e.target.style.height = "auto";
            e.target.style.height = `${Math.min(e.target.scrollHeight, 140)}px`;
          }}
          onKeyDown={onKeyDown}
          placeholder={recording ? "正在录音…" : disabled ? "机器人未连接" : "输入消息…"}
          disabled={disabled || recording}
          rows={1}
          className="max-h-[140px] min-h-[40px] flex-1 resize-none rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2 text-[15px] outline-none focus:border-blue-400 dark:border-slate-700 dark:bg-slate-800"
        />

        {recording ? (
          <button
            type="button"
            onClick={stopRec}
            className="flex h-10 shrink-0 items-center gap-1.5 rounded-full bg-red-500 px-4 text-sm font-medium text-white hover:bg-red-600"
          >
            <span className="h-2 w-2 animate-pulse-dot rounded-full bg-white" />
            停止 {Math.floor(recElapsed)}s
          </button>
        ) : (
          <button
            type="button"
            onClick={send}
            disabled={disabled || !text.trim()}
            className="flex h-10 shrink-0 items-center rounded-full bg-blue-500 px-4 text-sm font-medium text-white transition hover:bg-blue-600 disabled:cursor-not-allowed disabled:opacity-40"
          >
            发送
          </button>
        )}
      </div>

      <input ref={fileInputRef} type="file" className="hidden" />
    </div>
  );
}

function MenuItem({ icon, label, onClick }: { icon: string; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-2 px-3 py-2 text-left hover:bg-slate-100 dark:hover:bg-slate-700"
    >
      <span>{icon}</span>
      <span>{label}</span>
    </button>
  );
}
