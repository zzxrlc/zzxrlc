import { fail } from "@/server/http";
import { serveInboundMedia } from "@/server/media";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ messageId: string; index: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  const { messageId, index } = await ctx.params;
  try {
    return await serveInboundMedia(messageId, Number(index));
  } catch (e) {
    return fail(e);
  }
}
