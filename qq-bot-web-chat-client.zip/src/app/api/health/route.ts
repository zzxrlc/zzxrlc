import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { getStatus } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  let dbOk = false;
  try {
    getDb();
    dbOk = true;
  } catch {
    dbOk = false;
  }
  const status = getStatus();
  return NextResponse.json(
    {
      ok: dbOk,
      db: dbOk,
      bot: status.status,
      botConnected: status.connected,
      appId: status.appId,
      uptimeSec: Math.round(process.uptime()),
    },
    { status: dbOk ? 200 : 500 },
  );
}
