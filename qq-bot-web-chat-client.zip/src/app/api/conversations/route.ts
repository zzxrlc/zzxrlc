import { listConversations } from "@/lib/db";
import { ok } from "@/server/http";
import { ensureStarted } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureStarted();
  return ok({ conversations: listConversations() });
}
