import { clearUnread, parseConversationId } from "@/lib/db";
import { appError } from "@/lib/errors";
import { fail, isSameOrigin, ok } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  if (!isSameOrigin(req)) {
    return fail(appError("PERMISSION_DENIED", "跨站请求被拒绝", "", false));
  }
  const { id } = await ctx.params;
  const conv = parseConversationId(id);
  if (!conv) return fail(appError("INVALID_REQUEST", "会话标识无效", "", false));
  clearUnread(id);
  return ok({});
}
