import { MediaFileType } from "@tencent-connect/qqbot-nodejs";
import { parseConversationId } from "@/lib/db";
import { appError } from "@/lib/errors";
import { fail, isSameOrigin, ok } from "@/server/http";
import { saveUpload } from "@/server/media";
import { sendMediaMessage } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function kindToFileType(kind: string, contentType: string): MediaFileType {
  if (kind === "image") return MediaFileType.IMAGE;
  if (kind === "video") return MediaFileType.VIDEO;
  if (kind === "voice") return MediaFileType.VOICE;
  if (kind === "file") return MediaFileType.FILE;
  // Fallback: sniff from content type.
  if (contentType.startsWith("image/")) return MediaFileType.IMAGE;
  if (contentType.startsWith("video/")) return MediaFileType.VIDEO;
  if (contentType.startsWith("audio/")) return MediaFileType.VOICE;
  return MediaFileType.FILE;
}

export async function POST(req: Request, ctx: Ctx) {
  if (!isSameOrigin(req)) {
    return fail(appError("PERMISSION_DENIED", "跨站请求被拒绝", "请从本站页面发起发送", false));
  }
  const { id } = await ctx.params;
  const conv = parseConversationId(id);
  if (!conv) return fail(appError("INVALID_REQUEST", "会话标识无效", "", false));

  let saved;
  try {
    saved = await saveUpload(req);
  } catch (e) {
    return fail(e);
  }

  const fileType = kindToFileType(saved.kind, saved.contentType);

  // QQ platform limitation: generic "file" media is not open in group chat.
  if (conv.scope === "group" && fileType === MediaFileType.FILE) {
    try {
      // clean up the just-written file
      const fs = await import("node:fs");
      fs.unlinkSync(saved.localPath);
    } catch {
      /* ignore */
    }
    return fail(
      appError("UNSUPPORTED_MEDIA", "群聊暂不支持发送文件", "请改用图片/视频/语音，或通过私聊发送文件", false),
    );
  }

  try {
    const message = await sendMediaMessage(conv.scope, conv.peerId, {
      fileType,
      localPath: saved.localPath,
      localId: saved.localId,
      fileName: saved.fileName,
      contentType: saved.contentType,
      size: saved.size,
    });
    return ok({ message });
  } catch (e) {
    return fail(e);
  }
}
