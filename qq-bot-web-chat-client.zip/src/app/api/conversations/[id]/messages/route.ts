import { listMessages, parseConversationId } from "@/lib/db";
import { appError } from "@/lib/errors";
import { fail, isSameOrigin, ok } from "@/server/http";
import { sendTextMessage } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const conv = parseConversationId(id);
  if (!conv) return fail(appError("INVALID_REQUEST", "会话标识无效", "", false));

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit")) || 50, 1), 100);
  const beforeRaw = url.searchParams.get("before");
  const before = beforeRaw ? Number(beforeRaw) : undefined;

  const { messages, hasMore } = listMessages(id, limit, before && Number.isFinite(before) ? before : undefined);
  return ok({ messages, hasMore });
}

export async function POST(req: Request, ctx: Ctx) {
  if (!isSameOrigin(req)) {
    return fail(appError("PERMISSION_DENIED", "跨站请求被拒绝", "请从本站页面发起发送", false));
  }
  const { id } = await ctx.params;
  const conv = parseConversationId(id);
  if (!conv) return fail(appError("INVALID_REQUEST", "会话标识无效", "", false));

  let body: { text?: unknown };
  try {
    body = (await req.json()) as { text?: unknown };
  } catch {
    return fail(appError("INVALID_REQUEST", "请求体格式错误", "请提交 JSON", false));
  }

  try {
    const message = await sendTextMessage(conv.scope, conv.peerId, typeof body?.text === "string" ? body.text : "");
    return ok({ message });
  } catch (e) {
    return fail(e);
  }
}
