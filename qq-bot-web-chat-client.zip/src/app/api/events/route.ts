import { bus, safeJson } from "@/lib/bus";
import { getStatus } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Server-Sent Events stream for realtime browser updates.
 *
 * The QQ gateway (WebSocket) pushes events into the in-process bus; this
 * endpoint fans them out to every connected browser tab. SSE auto-reconnects
 * on transient network loss and works behind reverse proxies without any
 * upgrade handling.
 */
export async function GET(req: Request) {
  const encoder = new TextEncoder();
  let controller: ReadableStreamDefaultController<Uint8Array>;

  const stream = new ReadableStream<Uint8Array>({
    start(c) {
      controller = c;
      const send = (type: string, data: unknown) => {
        try {
          controller.enqueue(encoder.encode(`event: ${type}\ndata: ${safeJson(data)}\n\n`));
        } catch {
          /* client gone */
        }
      };

      const unsubscribe = bus.subscribe((event) => send(event.type, event.data));
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(": ping\n\n"));
        } catch {
          /* ignore */
        }
      }, 15000);

      const cleanup = () => {
        clearInterval(heartbeat);
        unsubscribe();
        try {
          controller.close();
        } catch {
          /* ignore */
        }
      };
      req.signal.addEventListener("abort", cleanup, { once: true });

      // Initial snapshot so the client is never in a blank state.
      send("status", getStatus());
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
