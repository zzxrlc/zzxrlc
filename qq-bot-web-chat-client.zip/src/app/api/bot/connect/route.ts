import { appError } from "@/lib/errors";
import { fail, isSameOrigin, ok } from "@/server/http";
import { connect } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!isSameOrigin(req)) {
    return fail(appError("PERMISSION_DENIED", "跨站请求被拒绝", "请从本站页面发起连接", false));
  }

  let body: { appId?: unknown; appSecret?: unknown };
  try {
    body = (await req.json()) as { appId?: unknown; appSecret?: unknown };
  } catch {
    return fail(appError("INVALID_REQUEST", "请求体格式错误", "请提交 JSON", false));
  }

  const appId = typeof body?.appId === "string" ? body.appId.trim() : "";
  const appSecret = typeof body?.appSecret === "string" ? body.appSecret.trim() : "";

  try {
    const status = await connect(appId, appSecret);
    return ok({ status });
  } catch (e) {
    return fail(e);
  }
}
