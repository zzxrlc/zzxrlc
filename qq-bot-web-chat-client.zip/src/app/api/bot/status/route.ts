import { ok } from "@/server/http";
import { ensureStarted, getStatus } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  // Opening the page (or polling) also restores a saved connection after boot.
  await ensureStarted();
  return ok({ status: getStatus() });
}
