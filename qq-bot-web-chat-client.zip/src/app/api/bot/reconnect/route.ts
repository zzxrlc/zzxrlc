import { appError } from "@/lib/errors";
import { fail, isSameOrigin, ok } from "@/server/http";
import { ensureStarted, getStatus } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!isSameOrigin(req)) {
    return fail(appError("PERMISSION_DENIED", "跨站请求被拒绝", "请从本站页面发起连接", false));
  }
  await ensureStarted();
  return ok({ status: getStatus() });
}
