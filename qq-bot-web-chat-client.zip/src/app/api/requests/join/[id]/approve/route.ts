import { appError } from "@/lib/errors";
import { fail, isSameOrigin, ok } from "@/server/http";
import { approveJoinRequest } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  if (!isSameOrigin(req)) {
    return fail(appError("PERMISSION_DENIED", "跨站请求被拒绝", "请从本站页面发起操作", false));
  }
  const { id } = await ctx.params;
  try {
    const request = await approveJoinRequest(id);
    return ok({ request });
  } catch (e) {
    return fail(e);
  }
}
