import { countPendingRequests, listFriendEvents, listGroupRobotEvents, listJoinRequests } from "@/lib/db";
import { ok } from "@/server/http";
import { ensureStarted } from "@/server/runtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureStarted();
  const pending = listJoinRequests("pending", 100);
  const history = listJoinRequests(undefined, 50).filter((r) => r.status !== "pending");
  return ok({
    friends: listFriendEvents(100),
    groupEvents: listGroupRobotEvents(100),
    joinRequests: [...pending, ...history],
    pendingCount: countPendingRequests(),
  });
}
