import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { ReadableStream as WebReadableStream } from "node:stream/web";
import Busboy from "busboy";
import { config, ensureDirs } from "@/lib/config";
import { getMessage } from "@/lib/db";
import { appError } from "@/lib/errors";
import { log } from "@/lib/logger";

/**
 * Streaming media pipeline.
 *
 * - Browser uploads are parsed with busboy and streamed straight to disk, so a
 *   200 MB video never lives in RAM.
 * - Inbound QQ attachments are proxied through a disk cache (streamed, size
 *   capped) so the browser never talks to QQ CDN directly and gets a stable
 *   URL + correct Content-Disposition.
 */

const INLINE_TYPES = new Set(["image/jpeg", "image/png", "image/gif", "image/webp", "video/mp4", "audio/mpeg", "audio/wav", "audio/mp4", "audio/ogg", "audio/x-wav", "audio/aac"]);
const MAX_CACHE_BYTES = 100 * 1024 * 1024; // don't cache inbound files bigger than 100 MB

const MIME_EXT: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/gif": ".gif",
  "image/webp": ".webp",
  "video/mp4": ".mp4",
  "audio/mpeg": ".mp3",
  "audio/mp3": ".mp3",
  "audio/wav": ".wav",
  "audio/x-wav": ".wav",
  "audio/mp4": ".m4a",
  "audio/ogg": ".ogg",
  "application/pdf": ".pdf",
  "application/zip": ".zip",
  "text/plain": ".txt",
};

export function sanitizeName(name: string): string {
  const base = path.basename(String(name || "file")).replace(/[\u0000-\u001f\u007f]/g, "").trim();
  const clean = base || "file";
  return clean.length > 150 ? clean.slice(-150) : clean;
}

function extForMime(mime: string): string {
  return MIME_EXT[mime] || ".bin";
}

export interface SavedUpload {
  localId: string;
  localPath: string;
  fileName: string;
  contentType: string;
  size: number;
  kind: string;
}

/**
 * Parse a multipart/form-data request and stream the single file to
 * `data/media/out`. Returns metadata; the caller later feeds `localPath` into
 * the SDK's `sendMedia` (which streams to QQ via chunked upload).
 */
export function saveUpload(req: Request): Promise<SavedUpload> {
  return new Promise<SavedUpload>((resolve, reject) => {
    const contentType = req.headers.get("content-type") || "";
    if (!contentType.includes("multipart/form-data")) {
      reject(appError("INVALID_REQUEST", "请求不是 multipart 上传", "请使用表单上传文件", false));
      return;
    }
    if (!req.body) {
      reject(appError("INVALID_REQUEST", "上传内容为空", "请选择文件", false));
      return;
    }

    ensureDirs();
    const headers = Object.fromEntries(req.headers.entries());
    const bb = Busboy({ headers, limits: { fileSize: config.maxUploadBytes, files: 1 } });

    const localId = randomUUID();
    let kind = "file";
    let result: SavedUpload | null = null;
    let failure: Error | null = null;
    let finalPath: string | null = null;
    let fileDone = false;
    let bbDone = false;

    const maybeFinish = () => {
      if (!fileDone || !bbDone) return;
      if (failure) {
        if (finalPath) {
          try {
            fs.unlinkSync(finalPath);
          } catch {
            /* ignore */
          }
        }
        reject(failure);
      } else if (result) {
        resolve(result);
      } else {
        reject(appError("INVALID_REQUEST", "未收到文件内容", "请选择文件", false));
      }
    };

    bb.on("field", (name, value) => {
      if (name === "kind") kind = String(value || "file");
    });

    bb.on("file", (_name, fileStream, info) => {
      const safeName = sanitizeName(info.filename);
      const mime = info.mimeType || "application/octet-stream";
      const ext = path.extname(safeName) || extForMime(mime);
      finalPath = path.join(config.outDir, `${localId}${ext}`);
      const ws = fs.createWriteStream(finalPath, { flags: "wx" });
      let size = 0;
      fileStream.on("data", (chunk: Buffer) => {
        size += chunk.length;
      });
      fileStream.on("error", (e: Error) => {
        failure = e;
        ws.destroy();
      });
      ws.on("error", (e: Error) => {
        failure = e;
      });
      ws.on("close", () => {
        fileDone = true;
        result = { localId, localPath: finalPath!, fileName: safeName, contentType: mime, size, kind };
        maybeFinish();
      });
      fileStream.pipe(ws);
    });

    bb.on("limit", () => {
      failure = appError("FILE_TOO_LARGE", `文件超过大小限制（${Math.floor(config.maxUploadBytes / 1024 / 1024)} MB）`, "请选择更小的文件", false);
    });
    bb.on("error", (e: Error) => {
      failure = e;
      bbDone = true;
      maybeFinish();
    });
    bb.on("finish", () => {
      bbDone = true;
      maybeFinish();
    });

    let nodeStream: Readable;
    try {
      nodeStream = Readable.fromWeb(req.body as unknown as WebReadableStream<Uint8Array>);
    } catch (e) {
      reject(e);
      return;
    }
    nodeStream.on("error", (e: Error) => {
      failure = e;
      bbDone = true;
      maybeFinish();
    });
    nodeStream.pipe(bb);
  });
}

function streamFileResponse(filePath: string, contentType: string, filename: string | null, inline: boolean): Response {
  let size = 0;
  try {
    size = fs.statSync(filePath).size;
  } catch {
    throw appError("MEDIA_ERROR", "媒体文件不存在或已过期", "请重新获取", false);
  }
  const stream = fs.createReadStream(filePath);
  const web = Readable.toWeb(stream) as ReadableStream;
  const disposition = filename
    ? `${inline ? "inline" : "attachment"}; filename*=UTF-8''${encodeURIComponent(filename)}`
    : inline
      ? "inline"
      : "attachment";
  return new Response(web, {
    headers: {
      "Content-Type": contentType,
      "Content-Length": String(size),
      "Content-Disposition": disposition,
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}

/** Serve a previously uploaded outbound media file by its local id. */
export function serveOutMedia(id: string): Response {
  const safeId = /^[a-f0-9-]{36}$/.test(id) ? id : null;
  if (!safeId) throw appError("INVALID_REQUEST", "无效的媒体标识", "", false);
  let found: string | null = null;
  try {
    for (const name of fs.readdirSync(config.outDir)) {
      if (name.startsWith(`${safeId}.`)) {
        found = path.join(config.outDir, name);
        break;
      }
    }
  } catch {
    /* ignore */
  }
  if (!found) throw appError("MEDIA_ERROR", "媒体文件不存在或已过期", "请重新发送", false);
  const ext = path.extname(found).toLowerCase();
  const contentType = mimeForExt(ext);
  return streamFileResponse(found, contentType, null, true);
}

function mimeForExt(ext: string): string {
  const map: Record<string, string> = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".mp4": "video/mp4",
    ".mp3": "audio/mpeg",
    ".wav": "audio/wav",
    ".m4a": "audio/mp4",
    ".ogg": "audio/ogg",
    ".pdf": "application/pdf",
    ".zip": "application/zip",
    ".txt": "text/plain",
  };
  return map[ext] || "application/octet-stream";
}

/**
 * Proxy (and cache) an inbound attachment. Picks the WAV URL for voice so the
 * browser can play it directly. Streams QQ → disk, then disk → browser, so a
 * large attachment never occupies memory.
 */
export async function serveInboundMedia(messageId: string, index: number): Promise<Response> {
  const message = getMessage(messageId);
  if (!message) throw appError("INVALID_REQUEST", "消息不存在", "", false);
  const attach = message.attachments[index];
  if (!attach) throw appError("INVALID_REQUEST", "附件不存在", "", false);

  const url = attach.voiceWavUrl || attach.url;
  if (!url) throw appError("MEDIA_ERROR", "该附件没有可用的下载地址", "可能已过期", false);

  const ext = extForMime(attach.contentType || "application/octet-stream");
  const cachePath = path.join(config.inDir, `${messageId}_${index}${ext}`);

  if (fs.existsSync(cachePath)) {
    const inline = INLINE_TYPES.has(attach.contentType || "");
    return streamFileResponse(cachePath, attach.contentType || mimeForExt(ext), attach.filename || null, inline);
  }

  // Stream the remote attachment to the local cache (bounded memory).
  let upstream: Response;
  try {
    upstream = await fetch(url, {
      headers: {
        "User-Agent": "qqbot-web/1.0 (+https://github.com/)",
        Accept: "*/*",
      },
      redirect: "follow",
    });
  } catch (e) {
    log.warn("inbound media fetch failed", e);
    throw appError("NETWORK_ERROR", "获取媒体资源失败", "请检查网络或稍后重试", true);
  }
  if (!upstream.ok || !upstream.body) {
    throw appError("MEDIA_ERROR", "获取媒体资源失败", "QQ 资源可能已过期", true);
  }

  const contentLength = Number(upstream.headers.get("content-length") || 0);
  const cacheable = contentLength === 0 || contentLength <= MAX_CACHE_BYTES;

  if (cacheable) {
    try {
      ensureDirs();
      const nodeStream = Readable.fromWeb(upstream.body as unknown as WebReadableStream<Uint8Array>);
      const ws = fs.createWriteStream(`${cachePath}.part`, { flags: "wx" });
      await pipeline(nodeStream, ws);
      fs.renameSync(`${cachePath}.part`, cachePath);
    } catch (e) {
      try {
        fs.unlinkSync(`${cachePath}.part`);
      } catch {
        /* ignore */
      }
      log.warn("inbound media cache write failed", e);
      // Fall through to direct stream below.
      const inline = INLINE_TYPES.has(attach.contentType || "");
      return new Response(upstream.body, {
        headers: {
          "Content-Type": attach.contentType || "application/octet-stream",
          "Content-Disposition": attach.filename
            ? `attachment; filename*=UTF-8''${encodeURIComponent(attach.filename)}`
            : "attachment",
        },
      });
    }
  }

  const inline = INLINE_TYPES.has(attach.contentType || "");
  if (cacheable && fs.existsSync(cachePath)) {
    return streamFileResponse(cachePath, attach.contentType || mimeForExt(ext), attach.filename || null, inline);
  }
  // Too large to cache — stream straight through.
  return new Response(upstream.body, {
    headers: {
      "Content-Type": attach.contentType || "application/octet-stream",
      "Content-Disposition": attach.filename
        ? `${inline ? "inline" : "attachment"}; filename*=UTF-8''${encodeURIComponent(attach.filename)}`
        : inline
          ? "inline"
          : "attachment",
    },
  });
}
