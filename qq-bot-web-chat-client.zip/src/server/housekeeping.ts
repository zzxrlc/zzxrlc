import fs from "node:fs";
import path from "node:path";
import { config, ensureDirs } from "@/lib/config";
import { log } from "@/lib/logger";

/**
 * Lightweight media housekeeping. Removes stale outbound uploads and inbound
 * media caches older than `MEDIA_RETENTION_DAYS` (default 30) so the disk and
 * the message index stay small. Runs once at boot, then hourly.
 */

let timer: NodeJS.Timeout | null = null;

function sweep(dir: string): void {
  const retentionMs = (Number(process.env.MEDIA_RETENTION_DAYS) || 30) * 86_400_000;
  const now = Date.now();
  let entries: string[] = [];
  try {
    entries = fs.readdirSync(dir);
  } catch {
    return;
  }
  for (const name of entries) {
    const full = path.join(dir, name);
    try {
      const st = fs.statSync(full);
      if (st.isFile() && now - st.mtimeMs > retentionMs) {
        fs.unlinkSync(full);
      }
    } catch {
      /* best-effort */
    }
  }
}

export function runHousekeeping(): void {
  try {
    ensureDirs();
    sweep(config.outDir);
    sweep(config.inDir);
  } catch (e) {
    log.warn("housekeeping failed", e);
  }
}

export function startHousekeeping(): void {
  if (timer) return;
  runHousekeeping();
  timer = setInterval(runHousekeeping, 60 * 60 * 1000);
  timer.unref();
}
