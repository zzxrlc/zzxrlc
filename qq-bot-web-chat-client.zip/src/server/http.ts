import { NextResponse } from "next/server";
import { classifyError, errorBody, type ErrorCategory } from "@/lib/errors";
import { log } from "@/lib/logger";

/** Success envelope shared by every endpoint. */
export function ok<T extends Record<string, unknown>>(data: T, init?: ResponseInit) {
  return NextResponse.json({ success: true, ...data }, init);
}

function statusFor(type: ErrorCategory): number {
  switch (type) {
    case "AUTH_ERROR":
    case "TOKEN_EXPIRED":
      return 401;
    case "PERMISSION_DENIED":
      return 403;
    case "RATE_LIMIT":
      return 429;
    case "INVALID_REQUEST":
    case "UNSUPPORTED_MEDIA":
    case "FILE_TOO_LARGE":
      return 400;
    case "TIMEOUT":
      return 504;
    case "NETWORK_ERROR":
    case "GATEWAY_ERROR":
      return 502;
    default:
      return 500;
  }
}

/** Structured error envelope with a matching HTTP status code. */
export function fail(err: unknown): NextResponse {
  const body = errorBody(err);
  log.warn(`request failed: ${body.error.type} ${body.error.message}`, body.error.raw);
  return NextResponse.json(body, { status: statusFor(body.error.type) });
}

/**
 * Reject cross-origin writes. The client is a single-user, cookie-less app so
 * CSRF surface is small, but this still blocks a third-party page from
 * tricking the browser into POSTing to our control endpoints.
 */
export function isSameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return true;
  try {
    const host = req.headers.get("host");
    if (!host) return false;
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}
