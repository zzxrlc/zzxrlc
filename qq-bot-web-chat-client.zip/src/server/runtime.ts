import { randomUUID } from "node:crypto";
import {
  QQBot,
  MediaFileType,
  FileKVStore,
  kvSessionPersistence,
  type ReplyTarget,
  type QQBotInboundMessage,
} from "@tencent-connect/qqbot-nodejs";
import { bus } from "@/lib/bus";
import { config, ensureDirs } from "@/lib/config";
import {
  convId,
  getConversation,
  getSetting,
  setSetting,
  delSetting,
  getMessage,
  insertMessage,
  updateMessageStatus,
  findMessageByQQId,
  incrUnread,
  upsertConversation,
  updateConversationTitle,
  touchConversation,
  insertFriendEvent,
  findFriendEventByOpenid,
  insertGroupRobotEvent,
  insertJoinRequest,
  getJoinRequest,
  updateJoinRequestStatus,
  listJoinRequests,
  type Message,
  type MsgType,
  type Scope,
  type JoinRequest,
} from "@/lib/db";
import { classifyError, AppError, appError, type QQErrorDetail } from "@/lib/errors";
import { log, sdkLogger } from "@/lib/logger";
import { encryptSecret, decryptSecret, maskSecret } from "@/lib/secret";

export type BotStatus = "disconnected" | "connecting" | "connected" | "error";

export interface BotInfo {
  id: string;
  username: string;
  avatar?: string;
}

export interface StatusPayload {
  status: BotStatus;
  connected: boolean;
  hasCredentials: boolean;
  appId: string | null;
  bot: BotInfo | null;
  lastError: string | null;
}

interface RuntimeState {
  status: BotStatus;
  bot: QQBot | null;
  botInfo: BotInfo | null;
  lastError: string | null;
  lastErrorDetail: QQErrorDetail | null;
  abort: AbortController | null;
  startPromise: Promise<void> | null;
  stopped: boolean;
}

const globalForRuntime = globalThis as unknown as { __qqbotRuntime?: RuntimeState };

function getState(): RuntimeState {
  if (!globalForRuntime.__qqbotRuntime) {
    globalForRuntime.__qqbotRuntime = {
      status: "disconnected",
      bot: null,
      botInfo: null,
      lastError: null,
      lastErrorDetail: null,
      abort: null,
      startPromise: null,
      stopped: false,
    };
  }
  return globalForRuntime.__qqbotRuntime;
}

// ── helpers ────────────────────────────────────────────────────────────────

/** File-backed gateway session so a restart resumes instead of re-identifying. */
function makeSessionPersistence(appId: string) {
  return kvSessionPersistence({
    store: new FileKVStore({ dir: config.dataDir, fileName: "gateway-session.json" }),
    accountId: appId,
  });
}

function currentCreds(): { appId: string; secret: string } | null {
  const raw = getSetting("credentials");
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as { appId: string; secretEnc: string };
    return { appId: parsed.appId, secret: decryptSecret(parsed.secretEnc) };
  } catch {
    return null;
  }
}

function requireBot(): QQBot {
  const st = getState();
  if (!st.bot || st.status !== "connected") {
    throw appError("GATEWAY_ERROR", "QQ Bot 尚未连接", "请先连接机器人", false);
  }
  return st.bot;
}

export function statusPayload(): StatusPayload {
  const st = getState();
  const creds = getSetting("credentials") ? true : false;
  let appId: string | null = null;
  if (creds) {
    try {
      appId = JSON.parse(getSetting("credentials")!).appId as string;
    } catch {
      /* ignore */
    }
  }
  return {
    status: st.status,
    connected: st.status === "connected",
    hasCredentials: creds,
    appId: appId ? maskSecret(appId, 4) : null,
    bot: st.botInfo,
    lastError: st.lastError,
  };
}

function emitStatus(): void {
  bus.emit("status", statusPayload());
}

async function fetchBotInfo(bot: QQBot): Promise<BotInfo | null> {
  try {
    const me = (await bot.api.get("/users/@me")) as { id?: string; username?: string; avatar?: string };
    if (me && me.id) {
      return { id: me.id, username: me.username ?? me.id, avatar: me.avatar };
    }
    return null;
  } catch (e) {
    log.warn("failed to fetch bot self info", e);
    return null;
  }
}

async function fetchGroupName(bot: QQBot, groupOpenid: string, conversationId: string): Promise<void> {
  try {
    const info = (await bot.api.get(`/v2/groups/${encodeURIComponent(groupOpenid)}`)) as { group_name?: string };
    if (info?.group_name) {
      updateConversationTitle(conversationId, info.group_name);
      const conv = getConversation(conversationId);
      if (conv) bus.emit("conversation", conv);
    }
  } catch {
    /* group name is best-effort */
  }
}

function detectMsgType(content: string, attachments: QQBotInboundMessage["attachments"]): MsgType {
  if (attachments && attachments.length > 0) {
    const ct = (attachments[0].content_type || "").toLowerCase();
    if (ct.startsWith("image/")) return "image";
    if (ct.startsWith("video/")) return "video";
    if (ct === "voice" || ct.includes("audio")) return "voice";
    return "file";
  }
  return "text";
}

function previewOf(msgType: MsgType, text: string | null): string {
  switch (msgType) {
    case "image":
      return "[图片]";
    case "video":
      return "[视频]";
    case "voice":
      return "[语音]";
    case "file":
      return "[文件]";
    default:
      return text || "";
  }
}

function timeout(ms: number): Promise<"timeout"> {
  return new Promise((resolve) => setTimeout(() => resolve("timeout"), ms));
}

// ── inbound message handling ──────────────────────────────────────────────

async function handleInbound(msg: QQBotInboundMessage): Promise<void> {
  const st = getState();
  if (st.bot === null) return;

  // Only C2C + group are supported by this client (guild/dm messages have no replyTarget).
  if (msg.kind !== "c2c" && msg.kind !== "group") return;
  if (!msg.replyTarget) return;

  const scope: Scope = msg.kind === "c2c" ? "c2c" : "group";
  const peerId = scope === "c2c" ? msg.senderId : msg.groupOpenid || msg.replyTarget.targetId;
  if (!peerId) return;

  const existing = msg.messageId ? findMessageByQQId(msg.messageId) : null;
  if (existing) return; // idempotent (SDK may redeliver after resume)

  const msgType = detectMsgType(msg.content, msg.attachments);
  const attachments =
    msg.attachments?.map((a, i) => ({
      url: a.url,
      contentType: a.content_type,
      filename: a.filename,
      size: a.size,
      width: a.width,
      height: a.height,
      voiceWavUrl: a.voice_wav_url,
      asrText: a.asr_refer_text,
      localIdx: i,
    })) ?? [];

  const now = Date.now();
  const conversationId = convId(scope, peerId);
  const title = scope === "c2c" ? msg.senderName || peerId : `群聊(${peerId.slice(-6)})`;

  upsertConversation({ id: conversationId, scope, peerId, title, lastMessageAt: now, lastPreview: previewOf(msgType, msg.content) });
  incrUnread(conversationId);

  const message = insertMessage({
    id: randomUUID(),
    qqMessageId: msg.messageId ?? null,
    conversationId,
    scope,
    peerId,
    direction: "in",
    senderId: msg.senderId,
    senderName: msg.senderName,
    msgType,
    text: msg.content || null,
    attachments,
    status: "sent",
    createdAt: now,
  });

  const conversation = getConversation(conversationId);
  bus.emit("message", { message, conversation });
  log.debug(`inbound ${scope} message from ${peerId} (${msgType})`);

  // Lazy group name resolution.
  if (scope === "group" && st.bot) {
    void fetchGroupName(st.bot, peerId, conversationId);
  }
}

// ── friend / group lifecycle events (raw gateway events) ───────────────────

function toEpochSeconds(t: unknown): number {
  if (typeof t === "number") return t;
  if (typeof t === "string") {
    const ms = Date.parse(t);
    if (!Number.isNaN(ms)) return Math.floor(ms / 1000);
    const n = Number(t);
    if (Number.isFinite(n)) return n;
  }
  return Math.floor(Date.now() / 1000);
}

async function handleRawEvent(eventType: string, data: unknown): Promise<void> {
  const st = getState();
  const bot = st.bot;
  if (!bot) return;

  try {
    if (eventType === "FRIEND_ADD") {
      const ev = data as { openid?: string; timestamp?: unknown; scene?: string; short_code?: string };
      if (!ev.openid) return;
      if (findFriendEventByOpenid(ev.openid)) return; // idempotent
      const event = insertFriendEvent({
        openid: ev.openid,
        scene: ev.scene ?? null,
        shortCode: ev.short_code ?? null,
        eventTime: toEpochSeconds(ev.timestamp),
      });
      // Ensure a C2C conversation exists so the new friend appears immediately.
      const id = convId("c2c", ev.openid);
      if (!getConversation(id)) {
        upsertConversation({ id, scope: "c2c", peerId: ev.openid, title: `好友(${ev.openid.slice(-6)})`, lastMessageAt: Date.now() });
      }
      const conv = getConversation(id);
      if (conv) bus.emit("conversation", conv);
      bus.emit("friend_add", event);
      log.info(`FRIEND_ADD ${ev.openid}`);
      return;
    }

    if (eventType === "GROUP_ADD_ROBOT") {
      const ev = data as { group_openid?: string; op_member_openid?: string; timestamp?: unknown };
      if (!ev.group_openid) return;
      const event = insertGroupRobotEvent({
        eventType: "add",
        groupOpenid: ev.group_openid,
        opMemberOpenid: ev.op_member_openid ?? null,
        eventTime: toEpochSeconds(ev.timestamp),
      });
      // Ensure a group conversation exists.
      const id = convId("group", ev.group_openid);
      if (!getConversation(id)) {
        upsertConversation({ id, scope: "group", peerId: ev.group_openid, title: `群聊(${ev.group_openid.slice(-6)})`, lastMessageAt: Date.now() });
        void fetchGroupName(bot, ev.group_openid, id);
      }
      const conv = getConversation(id);
      if (conv) bus.emit("conversation", conv);
      bus.emit("group_robot_add", event);
      log.info(`GROUP_ADD_ROBOT ${ev.group_openid}`);
      return;
    }

    if (eventType === "GROUP_DEL_ROBOT") {
      const ev = data as { group_openid?: string; op_member_openid?: string; timestamp?: unknown };
      if (!ev.group_openid) return;
      const event = insertGroupRobotEvent({
        eventType: "del",
        groupOpenid: ev.group_openid,
        opMemberOpenid: ev.op_member_openid ?? null,
        eventTime: toEpochSeconds(ev.timestamp),
      });
      bus.emit("group_robot_del", event);
      log.info(`GROUP_DEL_ROBOT ${ev.group_openid}`);
      return;
    }

    if (eventType === "GROUP_JOIN_REQUEST") {
      const ev = data as {
        group_openid?: string;
        join_request_id?: string;
        member_openid?: string;
        username?: string;
        apply_at?: string;
        apply_source?: string;
        invited_by?: string;
        verify_info?: Record<string, unknown>;
        risk_tips?: string;
      };
      if (!ev.group_openid || !ev.member_openid) return;
      const req = insertJoinRequest({
        joinRequestId: ev.join_request_id ?? null,
        groupOpenid: ev.group_openid,
        memberOpenid: ev.member_openid,
        username: ev.username ?? null,
        applyAt: ev.apply_at ?? null,
        applySource: ev.apply_source ?? null,
        invitedBy: ev.invited_by ?? null,
        verifyInfo: ev.verify_info ?? null,
        riskTips: ev.risk_tips ?? null,
      });
      bus.emit("join_request", req);
      log.info(`GROUP_JOIN_REQUEST ${ev.member_openid} -> ${ev.group_openid}`);
      return;
    }

    // GROUP_MEMBER_ADD / GROUP_MEMBER_QUIT require the 1<<24 intent which we
    // do not subscribe to by default (may not be granted). Ignore for now.
  } catch (e) {
    log.warn(`raw event ${eventType} handling failed`, e);
  }
}

// ── join-request approval ──────────────────────────────────────────────────

async function applyJoinRequestApproval(requestId: string, op: "approve" | "decline", rejectReason?: string): Promise<JoinRequest> {
  const req = getJoinRequest(requestId);
  if (!req) throw appError("INVALID_REQUEST", "入群申请不存在", "可能已被处理", false);
  if (req.status !== "pending") throw appError("INVALID_REQUEST", "该申请已被处理", "请刷新列表", false);
  const bot = requireBot();

  try {
    await bot.api.post(
      `/v2/groups/${encodeURIComponent(req.groupOpenid)}/approval_join_request/${encodeURIComponent(req.memberOpenid)}`,
      {
        op,
        join_request_id: req.joinRequestId,
        reject_reason: op === "decline" ? rejectReason || undefined : undefined,
        add_to_member_blacklist: false,
      },
    );
  } catch (e) {
    // Surface QQ's own error (e.g. bot not group admin → permission error).
    throw e;
  }

  updateJoinRequestStatus(req.id, op === "approve" ? "approved" : "declined");
  const updated = getJoinRequest(req.id)!;
  bus.emit("join_request", updated);
  log.info(`join request ${op}: ${req.memberOpenid} -> ${req.groupOpenid}`);
  return updated;
}

export async function approveJoinRequest(requestId: string): Promise<JoinRequest> {
  return applyJoinRequestApproval(requestId, "approve");
}

export async function declineJoinRequest(requestId: string, reason?: string): Promise<JoinRequest> {
  return applyJoinRequestApproval(requestId, "decline", reason);
}

// ── public API ─────────────────────────────────────────────────────────────

export async function connect(appId: string, appSecret: string): Promise<StatusPayload> {
  if (!appId || !appId.trim()) throw appError("INVALID_REQUEST", "请填写 AppID", "AppID 为必填项", false);
  if (!appSecret || !appSecret.trim()) throw appError("INVALID_REQUEST", "请填写 AppSecret", "AppSecret 为必填项", false);

  ensureDirs();
  const st = getState();
  await stopBot(false);

  st.status = "connecting";
  st.lastError = null;
  st.lastErrorDetail = null;
  st.stopped = false;
  emitStatus();

  const bot = new QQBot({
    appId: appId.trim(),
    appSecret,
    logger: sdkLogger,
    markdownSupport: false,
    sessionPersistence: makeSessionPersistence(appId.trim()),
  });
  st.bot = bot;

  const ac = new AbortController();
  st.abort = ac;

  let resolveReady!: () => void;
  let resolveError!: (d: QQErrorDetail) => void;
  const readyPromise = new Promise<void>((res) => (resolveReady = res));
  const errorPromise = new Promise<QQErrorDetail>((_, rej) => (resolveError = rej));

  bot.on("ready", () => {
    if (st.bot !== bot) return;
    st.status = "connected";
    st.lastError = null;
    resolveReady();
    // Persist credentials only after a successful connection so failed
    // attempts never leave a broken bot configured.
    setSetting("credentials", JSON.stringify({ appId: appId.trim(), secretEnc: encryptSecret(appSecret) }));
    void fetchBotInfo(bot).then((info) => {
      if (st.bot === bot) {
        st.botInfo = info;
        if (info) setSetting("botInfo", JSON.stringify(info));
      }
      emitStatus();
    });
  });

  bot.on("resumed", () => {
    if (st.bot !== bot) return;
    st.status = "connected";
    emitStatus();
  });

  bot.on("error", (err: Error) => {
    if (st.bot !== bot) return;
    const detail = classifyError(err);
    st.status = "error";
    st.lastError = detail.message;
    st.lastErrorDetail = detail;
    emitStatus();
    resolveError(detail);
  });

  bot.on("message", (_ctx, msg) => {
    void handleInbound(msg).catch((e) => log.error("inbound handler failed", e));
  });

  bot.on("rawEvent", (ctx) => {
    if (st.bot !== bot) return;
    void handleRawEvent(ctx.eventType, ctx.data).catch((e) => log.error("raw event handler failed", e));
  });

  st.startPromise = bot.start(ac.signal).catch((err) => {
    if (st.bot !== bot || st.stopped) return;
    const detail = classifyError(err);
    st.status = "error";
    st.lastError = detail.message;
    st.lastErrorDetail = detail;
    emitStatus();
    resolveError(detail);
  });

  const result = await Promise.race([readyPromise.then(() => "ready" as const), errorPromise.then(() => "error" as const), timeout(15000)]);

  if (result === "ready") {
    log.info("QQ Bot gateway connected");
    return statusPayload();
  }
  if (result === "error") {
    // Connection is already stopped by the error path; surface a clean, classified error.
    const detail = st.lastErrorDetail ?? classifyError(new Error("连接 QQ Bot 失败"));
    throw new AppError(detail);
  }
  // Timeout: gateway still handshaking (slow network). Leave it connecting.
  log.warn("QQ Bot connect is taking longer than expected");
  return statusPayload();
}

export async function disconnect(): Promise<void> {
  await stopBot(true);
}

async function stopBot(emit: boolean): Promise<void> {
  const st = getState();
  st.stopped = true;
  const bot = st.bot;
  const ac = st.abort;
  st.bot = null;
  st.abort = null;
  st.startPromise = null;
  st.status = "disconnected";
  if (emit) st.botInfo = null;
  try {
    ac?.abort();
  } catch {
    /* ignore */
  }
  try {
    bot?.stop();
  } catch {
    /* ignore */
  }
  if (emit) emitStatus();
}

/** Restore a previously saved connection (used at server boot). */
export async function ensureStarted(): Promise<void> {
  const st = getState();
  if (st.status === "connected" || st.status === "connecting") return;
  const creds = currentCreds();
  if (!creds) return;
  try {
    const savedBotInfo = getSetting("botInfo");
    if (savedBotInfo && !st.botInfo) {
      try {
        st.botInfo = JSON.parse(savedBotInfo) as BotInfo;
      } catch {
        /* ignore */
      }
    }
    await connect(creds.appId, creds.secret);
  } catch (e) {
    log.warn("auto-connect failed", classifyError(e).message);
  }
}

export function getStatus(): StatusPayload {
  return statusPayload();
}

export function clearCredentials(): void {
  delSetting("credentials");
  delSetting("botInfo");
}

// ── outbound messages ──────────────────────────────────────────────────────

function upsertOutConversation(scope: Scope, peerId: string, botName: string | null): string {
  const id = convId(scope, peerId);
  const existing = getConversation(id);
  if (!existing) {
    upsertConversation({
      id,
      scope,
      peerId,
      title: scope === "c2c" ? botName || peerId : `群聊(${peerId.slice(-6)})`,
      lastMessageAt: Date.now(),
    });
  }
  return id;
}

function emitMessage(message: Message): void {
  const conversation = getConversation(message.conversationId);
  bus.emit("message", { message, conversation });
}

export async function sendTextMessage(scope: Scope, peerId: string, text: string): Promise<Message> {
  const trimmed = (text || "").trim();
  if (!trimmed) throw appError("INVALID_REQUEST", "消息内容不能为空", "请输入文字", false);
  const bot = requireBot();
  const target: ReplyTarget = { scope, targetId: peerId };

  const botName = getState().botInfo?.username ?? null;
  const conversationId = upsertOutConversation(scope, peerId, botName);

  const message = insertMessage({
    id: randomUUID(),
    conversationId,
    scope,
    peerId,
    direction: "out",
    senderId: getState().botInfo?.id ?? null,
    senderName: botName,
    msgType: "text",
    text: trimmed,
    status: "sending",
    createdAt: Date.now(),
  });
  emitMessage(message);

  try {
    await bot.sendText(target, trimmed);
    updateMessageStatus(message.id, "sent");
    touchConversation(conversationId, Date.now(), trimmed);
  } catch (err) {
    const detail = classifyError(err);
    updateMessageStatus(message.id, "failed", JSON.stringify(detail));
    emitMessage(getMessage(message.id)!);
    throw err;
  }
  const saved = getMessage(message.id)!;
  emitMessage(saved);
  return saved;
}

export interface OutboundMedia {
  fileType: MediaFileType;
  localPath: string;
  localId: string;
  fileName?: string;
  contentType: string;
  size?: number;
}

export async function sendMediaMessage(scope: Scope, peerId: string, media: OutboundMedia): Promise<Message> {
  const bot = requireBot();
  const target: ReplyTarget = { scope, targetId: peerId };
  const botName = getState().botInfo?.username ?? null;
  const conversationId = upsertOutConversation(scope, peerId, botName);

  const msgType: MsgType =
    media.fileType === MediaFileType.IMAGE ? "image" : media.fileType === MediaFileType.VIDEO ? "video" : media.fileType === MediaFileType.VOICE ? "voice" : "file";

  const message = insertMessage({
    id: randomUUID(),
    conversationId,
    scope,
    peerId,
    direction: "out",
    senderId: getState().botInfo?.id ?? null,
    senderName: botName,
    msgType,
    attachments: [{ localId: media.localId, contentType: media.contentType, filename: media.fileName, size: media.size }],
    status: "sending",
    createdAt: Date.now(),
  });
  emitMessage(message);

  try {
    await bot.sendMedia({
      target,
      fileType: media.fileType,
      localPath: media.localPath,
      fileName: media.fileName,
      onProgress: (uploaded, total) => {
        bus.emit("upload_progress", { messageId: message.id, uploaded, total });
      },
    });
    updateMessageStatus(message.id, "sent");
    touchConversation(conversationId, Date.now(), previewOf(msgType, null));
  } catch (err) {
    const detail = classifyError(err);
    updateMessageStatus(message.id, "failed", JSON.stringify(detail));
    emitMessage(getMessage(message.id)!);
    throw err;
  }
  const saved = getMessage(message.id)!;
  emitMessage(saved);
  return saved;
}
