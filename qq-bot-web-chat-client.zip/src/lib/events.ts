/**
 * Tiny client-side pub/sub that fans SSE events out to UI components without
 * prop-drilling. A single EventSource (owned by <App/>) publishes here.
 */

export type ClientEvent = { type: string; data: unknown };
type Handler = (event: ClientEvent) => void;

const handlers = new Set<Handler>();

export const clientBus = {
  emit(type: string, data: unknown): void {
    const event: ClientEvent = { type, data };
    handlers.forEach((h) => h(event));
  },
  subscribe(handler: Handler): () => void {
    handlers.add(handler);
    return () => handlers.delete(handler);
  },
};
