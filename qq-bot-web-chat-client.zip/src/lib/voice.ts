/**
 * Browser voice recorder that encodes straight to 16 kHz mono 16-bit PCM WAV.
 *
 * QQ only accepts silk/wav/mp3/flac voice; WAV is the one format the browser
 * can produce without ffmpeg. We capture raw PCM via the Web Audio API and
 * write the WAV header ourselves, so no extra codecs are needed.
 */

export interface Recorder {
  /** Resolves with a WAV Blob ready to upload. */
  stop: () => Promise<Blob>;
  cancel: () => void;
  /** Recording duration in seconds. */
  elapsedSeconds: () => number;
}

export async function startVoiceRecording(): Promise<Recorder> {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AudioCtx();
  const source = ctx.createMediaStreamSource(stream);
  const sampleRate = 16000;
  const node = ctx.createScriptProcessor(4096, 1, 1);
  const chunks: Float32Array[] = [];
  const startTime = ctx.currentTime;

  node.onaudioprocess = (e: AudioProcessingEvent) => {
    const input = e.inputBuffer.getChannelData(0);
    const ratio = ctx.sampleRate / sampleRate;
    const len = Math.max(1, Math.floor(input.length / ratio));
    const out = new Float32Array(len);
    for (let i = 0; i < len; i++) out[i] = input[Math.floor(i * ratio)];
    chunks.push(out);
  };
  source.connect(node);
  node.connect(ctx.destination);

  const teardown = () => {
    try {
      node.onaudioprocess = null;
      source.disconnect();
      node.disconnect();
    } catch {
      /* ignore */
    }
    stream.getTracks().forEach((t) => t.stop());
    void ctx.close().catch(() => {});
  };

  return {
    elapsedSeconds: () => ctx.currentTime - startTime,
    cancel: () => {
      chunks.length = 0;
      teardown();
    },
    stop: () =>
      new Promise<Blob>((resolve, reject) => {
        try {
          const total = chunks.reduce((a, c) => a + c.length, 0);
          const buffer = new ArrayBuffer(44 + total * 2);
          const view = new DataView(buffer);
          writeWavHeader(view, sampleRate, total);
          let offset = 44;
          for (const c of chunks) {
            for (let i = 0; i < c.length; i++) {
              const s = Math.max(-1, Math.min(1, c[i]));
              view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
              offset += 2;
            }
          }
          teardown();
          resolve(new Blob([buffer], { type: "audio/wav" }));
        } catch (e) {
          teardown();
          reject(e);
        }
      }),
  };
}

function writeWavHeader(view: DataView, sampleRate: number, sampleCount: number): void {
  const bytesPerSample = 2;
  const blockAlign = bytesPerSample;
  const dataSize = sampleCount * bytesPerSample;
  const buffer = view.buffer;

  // RIFF header
  writeAscii(view, 0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeAscii(view, 8, "WAVE");
  // fmt chunk
  writeAscii(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, 1, true); // mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  // data chunk
  writeAscii(view, 36, "data");
  view.setUint32(40, dataSize, true);
  void buffer;
}

function writeAscii(view: DataView, offset: number, text: string): void {
  for (let i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i));
}
