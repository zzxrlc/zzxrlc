/**
 * Client-side API helpers. Mirrors the server types (duplicated here so the
 * client bundle never pulls in server-only / Node builtin code).
 */

export type Scope = "c2c" | "group";
export type MsgType = "text" | "image" | "video" | "voice" | "file";
export type MsgStatus = "sending" | "sent" | "failed";
export type BotStatusState = "disconnected" | "connecting" | "connected" | "error";

export interface AttachmentMeta {
  url?: string;
  localId?: string;
  localIdx?: number;
  contentType: string;
  filename?: string;
  size?: number;
  width?: number;
  height?: number;
  voiceWavUrl?: string;
  asrText?: string;
  duration?: number;
}

export interface Message {
  id: string;
  seq: number;
  conversationId: string;
  scope: Scope;
  peerId: string;
  direction: "in" | "out";
  senderId: string | null;
  senderName: string | null;
  msgType: MsgType;
  text: string | null;
  attachments: AttachmentMeta[];
  status: MsgStatus;
  error: string | null;
  createdAt: number;
}

export interface Conversation {
  id: string;
  scope: Scope;
  peerId: string;
  title: string;
  avatar: string | null;
  lastMessageAt: number;
  lastPreview: string;
  unread: number;
}

export interface BotInfo {
  id: string;
  username: string;
  avatar?: string;
}

export interface FriendEvent {
  id: string;
  openid: string;
  scene: string | null;
  shortCode: string | null;
  eventTime: number;
  createdAt: number;
}

export interface GroupRobotEvent {
  id: string;
  eventType: "add" | "del";
  groupOpenid: string;
  opMemberOpenid: string | null;
  eventTime: number;
  createdAt: number;
}

export type JoinRequestStatus = "pending" | "approved" | "declined";

export interface JoinRequest {
  id: string;
  joinRequestId: string | null;
  groupOpenid: string;
  memberOpenid: string;
  username: string | null;
  applyAt: string | null;
  applySource: string | null;
  invitedBy: string | null;
  verifyInfo: Record<string, unknown> | null;
  riskTips: string | null;
  status: JoinRequestStatus;
  createdAt: number;
  processedAt: number | null;
}

export interface RequestsData {
  friends: FriendEvent[];
  groupEvents: GroupRobotEvent[];
  joinRequests: JoinRequest[];
  pendingCount: number;
}

export interface BotStatus {
  status: BotStatusState;
  connected: boolean;
  hasCredentials: boolean;
  appId: string | null;
  bot: BotInfo | null;
  lastError: string | null;
}

export interface QQErrorDetail {
  source: string;
  code: number | string;
  type: string;
  message: string;
  retryable: boolean;
  suggestion: string;
  raw?: string;
}

export class ApiError extends Error {
  detail: QQErrorDetail;
  constructor(detail: QQErrorDetail) {
    super(detail.message || "请求失败");
    this.name = "ApiError";
    this.detail = detail;
  }
}

function normalizeError(body: unknown): ApiError {
  const b = body as { error?: QQErrorDetail };
  if (b?.error) return new ApiError(b.error);
  return new ApiError({
    source: "client",
    code: "HTTP",
    type: "NETWORK_ERROR",
    message: "请求失败",
    retryable: true,
    suggestion: "请稍后重试",
  });
}

async function json<T>(res: Response): Promise<T> {
  const body = (await res.json().catch(() => ({}))) as { success?: boolean; error?: QQErrorDetail };
  if (!res.ok || body.success === false) throw normalizeError(body);
  return body as T;
}

export const api = {
  async status(): Promise<BotStatus> {
    const body = await json<{ status: BotStatus }>(await fetch("/api/bot/status", { cache: "no-store" }));
    return body.status;
  },

  async connect(appId: string, appSecret: string): Promise<BotStatus> {
    const res = await fetch("/api/bot/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ appId, appSecret }),
    });
    const body = await json<{ status: BotStatus }>(res);
    return body.status;
  },

  async disconnect(): Promise<BotStatus> {
    const body = await json<{ status: BotStatus }>(
      await fetch("/api/bot/disconnect", { method: "POST" }),
    );
    return body.status;
  },

  async reconnect(): Promise<BotStatus> {
    const body = await json<{ status: BotStatus }>(
      await fetch("/api/bot/reconnect", { method: "POST" }),
    );
    return body.status;
  },

  async conversations(): Promise<Conversation[]> {
    const body = await json<{ conversations: Conversation[] }>(
      await fetch("/api/conversations", { cache: "no-store" }),
    );
    return body.conversations;
  },

  async messages(conversationId: string, limit = 50, beforeSeq?: number): Promise<{ messages: Message[]; hasMore: boolean }> {
    const q = new URLSearchParams({ limit: String(limit) });
    if (beforeSeq) q.set("before", String(beforeSeq));
    return json(await fetch(`/api/conversations/${encodeURIComponent(conversationId)}/messages?${q}`, { cache: "no-store" }));
  },

  async sendText(conversationId: string, text: string): Promise<Message> {
    const res = await fetch(`/api/conversations/${encodeURIComponent(conversationId)}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    return (await json<{ message: Message }>(res)).message;
  },

  async markRead(conversationId: string): Promise<void> {
    try {
      await fetch(`/api/conversations/${encodeURIComponent(conversationId)}/read`, { method: "POST" });
    } catch {
      /* best-effort */
    }
  },

  async requests(): Promise<RequestsData> {
    return json(await fetch("/api/requests", { cache: "no-store" }));
  },

  async approveJoin(id: string): Promise<JoinRequest> {
    const res = await fetch(`/api/requests/join/${encodeURIComponent(id)}/approve`, { method: "POST" });
    return (await json<{ request: JoinRequest }>(res)).request;
  },

  async declineJoin(id: string, reason?: string): Promise<JoinRequest> {
    const res = await fetch(`/api/requests/join/${encodeURIComponent(id)}/decline`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason }),
    });
    return (await json<{ request: JoinRequest }>(res)).request;
  },

  mediaIn(messageId: string, index: number): string {
    return `/api/media/in/${encodeURIComponent(messageId)}/${index}`;
  },

  mediaOut(id: string): string {
    return `/api/media/out/${encodeURIComponent(id)}`;
  },
};

export interface UploadResult {
  message: Message;
}

/** Upload a file with progress (uses XHR so the browser→server upload can be tracked). */
export function uploadMedia(
  conversationId: string,
  file: File,
  kind: "image" | "video" | "voice" | "file",
  onProgress: (uploaded: number, total: number) => void,
): Promise<Message> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `/api/conversations/${encodeURIComponent(conversationId)}/media`);
    xhr.responseType = "text";
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(e.loaded, e.total);
    };
    xhr.onload = () => {
      let data: { success?: boolean; message?: Message; error?: QQErrorDetail };
      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        reject(new ApiError({ source: "client", code: "HTTP", type: "UNKNOWN_ERROR", message: "响应解析失败", retryable: false, suggestion: "请重试" }));
        return;
      }
      if (xhr.status >= 200 && xhr.status < 300 && data.success && data.message) resolve(data.message);
      else reject(normalizeError(data));
    };
    xhr.onerror = () =>
      reject(new ApiError({ source: "client", code: 0, type: "NETWORK_ERROR", message: "网络连接失败", retryable: true, suggestion: "请检查网络后重试" }));
    xhr.onabort = () =>
      reject(new ApiError({ source: "client", code: "ABORT", type: "INVALID_REQUEST", message: "上传已取消", retryable: false, suggestion: "" }));

    const fd = new FormData();
    fd.append("kind", kind);
    fd.append("file", file, file.name || "file.bin");
    xhr.send(fd);
  });
}
