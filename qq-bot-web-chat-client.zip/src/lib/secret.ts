import crypto from "node:crypto";
import fs from "node:fs";
import { config, ensureDirs } from "./config";
import { log } from "./logger";

/**
 * At-rest encryption for the AppSecret.
 *
 * The secret is stored AES-256-GCM encrypted inside the SQLite database. The
 * encryption key lives in a separate file (`data/secret.key`) with 0600
 * permissions so a leaked DB dump alone does not expose the secret. The secret
 * is never returned by any API endpoint and never written to logs.
 */

const ALGO = "aes-256-gcm";

function loadOrCreateKey(): Buffer {
  ensureDirs();
  try {
    const existing = fs.readFileSync(config.secretKeyPath);
    if (existing.length === 32) return existing;
    log.warn("secret.key had invalid length, regenerating");
  } catch {
    /* key does not exist yet */
  }
  const key = crypto.randomBytes(32);
  fs.writeFileSync(config.secretKeyPath, key, { mode: 0o600 });
  try {
    fs.chmodSync(config.secretKeyPath, 0o600);
  } catch {
    /* non-posix fs */
  }
  return key;
}

let key: Buffer | null = null;
function getKey(): Buffer {
  if (!key) key = loadOrCreateKey();
  return key;
}

export function encryptSecret(plain: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, getKey(), iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString("base64")}:${tag.toString("base64")}:${enc.toString("base64")}`;
}

export function decryptSecret(payload: string): string {
  try {
    const [ver, ivB64, tagB64, dataB64] = payload.split(":");
    if (ver !== "v1") throw new Error("unsupported version");
    const decipher = crypto.createDecipheriv(ALGO, getKey(), Buffer.from(ivB64, "base64"));
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(dataB64, "base64")), decipher.final()]).toString("utf8");
  } catch (err) {
    log.error("failed to decrypt secret", err);
    throw new Error("无法解密已保存的 AppSecret（密钥文件缺失或损坏）");
  }
}

/** One-way mask used to show the stored AppID in the UI without leaking it. */
export function maskSecret(value: string, keep = 3): string {
  if (!value) return "";
  if (value.length <= keep * 2) return "••••";
  return value.slice(0, keep) + "••••" + value.slice(-keep);
}
