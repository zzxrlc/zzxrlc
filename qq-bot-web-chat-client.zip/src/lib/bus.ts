import { EventEmitter } from "node:events";

/**
 * In-process event bus used to fan out realtime events (new messages,
 * connection status changes) to every connected browser via SSE.
 *
 * A single Node process hosts everything (Next.js server + QQ gateway + SSE),
 * so a plain EventEmitter is the simplest and most memory-efficient transport.
 */

export interface BusEvent {
  type: string;
  data: unknown;
}

type Listener = (event: BusEvent) => void;

const emitter = new EventEmitter();
emitter.setMaxListeners(0);

export const bus = {
  emit(type: string, data: unknown): void {
    emitter.emit("event", { type, data } satisfies BusEvent);
  },
  subscribe(listener: Listener): () => void {
    emitter.on("event", listener);
    return () => emitter.off("event", listener);
  },
};

/** Serialize a payload safely (never throw on circular refs). */
export function safeJson(value: unknown): string {
  try {
    return JSON.stringify(value);
  } catch {
    return "{}";
  }
}
