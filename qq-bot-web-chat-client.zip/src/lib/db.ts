import { randomUUID } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { config, ensureDirs } from "./config";

/**
 * SQLite persistence layer (built on Node's native `node:sqlite`).
 *
 * Stores conversations, messages and app settings in a single file with WAL
 * journaling. No external database server is required, which keeps the total
 * runtime footprint small.
 */

export type Scope = "c2c" | "group";
export type MsgDirection = "in" | "out";
export type MsgType = "text" | "image" | "video" | "voice" | "file";

export interface AttachmentMeta {
  url?: string;
  /** Local media identifier: outbound file uuid or inbound cache key. */
  localId?: string;
  contentType: string;
  filename?: string;
  size?: number;
  width?: number;
  height?: number;
  voiceWavUrl?: string;
  asrText?: string;
  duration?: number;
}

export interface Conversation {
  id: string;
  scope: Scope;
  peerId: string;
  title: string;
  avatar: string | null;
  lastMessageAt: number;
  lastPreview: string;
  unread: number;
}

export interface Message {
  id: string;
  seq: number;
  qqMessageId: string | null;
  conversationId: string;
  scope: Scope;
  peerId: string;
  direction: MsgDirection;
  senderId: string | null;
  senderName: string | null;
  msgType: MsgType;
  text: string | null;
  attachments: AttachmentMeta[];
  status: "sending" | "sent" | "failed";
  error: string | null;
  createdAt: number;
}

export function convId(scope: Scope, peerId: string): string {
  return `${scope}:${peerId}`;
}

export function parseConversationId(id: string): { scope: Scope; peerId: string } | null {
  const idx = id.indexOf(":");
  if (idx <= 0) return null;
  const scope = id.slice(0, idx);
  if (scope !== "c2c" && scope !== "group") return null;
  return { scope, peerId: id.slice(idx + 1) };
}

const globalForDb = globalThis as unknown as { __qqbotDb?: DatabaseSync };

export function getDb(): DatabaseSync {
  if (!globalForDb.__qqbotDb) {
    ensureDirs();
    const db = new DatabaseSync(config.dbPath);
    db.exec("PRAGMA journal_mode = WAL;");
    db.exec("PRAGMA synchronous = NORMAL;");
    db.exec("PRAGMA busy_timeout = 5000;");
    migrate(db);
    globalForDb.__qqbotDb = db;
  }
  return globalForDb.__qqbotDb;
}

function migrate(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      scope TEXT NOT NULL,
      peer_id TEXT NOT NULL,
      title TEXT NOT NULL,
      avatar TEXT,
      last_message_at INTEGER NOT NULL,
      last_preview TEXT NOT NULL DEFAULT '',
      unread INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_conversations_scope ON conversations(scope, last_message_at DESC);
    CREATE TABLE IF NOT EXISTS messages (
      seq INTEGER PRIMARY KEY AUTOINCREMENT,
      id TEXT NOT NULL UNIQUE,
      qq_message_id TEXT,
      conversation_id TEXT NOT NULL,
      scope TEXT NOT NULL,
      peer_id TEXT NOT NULL,
      direction TEXT NOT NULL,
      sender_id TEXT,
      sender_name TEXT,
      msg_type TEXT NOT NULL,
      text TEXT,
      attachments TEXT,
      status TEXT NOT NULL DEFAULT 'sent',
      error TEXT,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, seq);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_qq ON messages(qq_message_id) WHERE qq_message_id IS NOT NULL;

    CREATE TABLE IF NOT EXISTS friend_events (
      id TEXT PRIMARY KEY,
      openid TEXT NOT NULL,
      scene TEXT,
      short_code TEXT,
      event_time INTEGER NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_friend_events_time ON friend_events(created_at DESC);

    CREATE TABLE IF NOT EXISTS group_robot_events (
      id TEXT PRIMARY KEY,
      event_type TEXT NOT NULL,
      group_openid TEXT NOT NULL,
      op_member_openid TEXT,
      event_time INTEGER NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_group_robot_events_time ON group_robot_events(created_at DESC);

    CREATE TABLE IF NOT EXISTS join_requests (
      id TEXT PRIMARY KEY,
      join_request_id TEXT,
      group_openid TEXT NOT NULL,
      member_openid TEXT NOT NULL,
      username TEXT,
      apply_at TEXT,
      apply_source TEXT,
      invited_by TEXT,
      verify_info TEXT,
      risk_tips TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at INTEGER NOT NULL,
      processed_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_join_requests_status ON join_requests(status, created_at DESC);
  `);
}

// ── settings ──────────────────────────────────────────────────────────────

export function getSetting(key: string): string | null {
  const row = getDb().prepare("SELECT value FROM settings WHERE key = ?").get(key) as { value: string } | undefined;
  return row ? row.value : null;
}

export function setSetting(key: string, value: string): void {
  getDb()
    .prepare("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")
    .run(key, value);
}

export function delSetting(key: string): void {
  getDb().prepare("DELETE FROM settings WHERE key = ?").run(key);
}

// ── conversations ─────────────────────────────────────────────────────────

function rowToConversation(row: Record<string, unknown>): Conversation {
  return {
    id: row.id as string,
    scope: row.scope as Scope,
    peerId: row.peer_id as string,
    title: row.title as string,
    avatar: (row.avatar as string | null) ?? null,
    lastMessageAt: row.last_message_at as number,
    lastPreview: (row.last_preview as string) ?? "",
    unread: row.unread as number,
  };
}

export function getConversation(id: string): Conversation | null {
  const row = getDb().prepare("SELECT * FROM conversations WHERE id = ?").get(id) as Record<string, unknown> | undefined;
  return row ? rowToConversation(row) : null;
}

export function listConversations(): Conversation[] {
  const rows = getDb()
    .prepare("SELECT * FROM conversations ORDER BY last_message_at DESC")
    .all() as unknown as Record<string, unknown>[];
  return rows.map(rowToConversation);
}

export function upsertConversation(c: {
  id: string;
  scope: Scope;
  peerId: string;
  title: string;
  avatar?: string | null;
  lastMessageAt: number;
  lastPreview?: string;
  unread?: number;
}): void {
  getDb()
    .prepare(
      `INSERT INTO conversations (id, scope, peer_id, title, avatar, last_message_at, last_preview, unread)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         title = excluded.title,
         avatar = COALESCE(excluded.avatar, conversations.avatar),
         last_message_at = MAX(conversations.last_message_at, excluded.last_message_at),
         last_preview = CASE WHEN excluded.last_preview = '' THEN conversations.last_preview ELSE excluded.last_preview END,
         unread = conversations.unread + excluded.unread`
    )
    .run(c.id, c.scope, c.peerId, c.title, c.avatar ?? null, c.lastMessageAt, c.lastPreview ?? "", c.unread ?? 0);
}

export function incrUnread(id: string): void {
  getDb().prepare("UPDATE conversations SET unread = unread + 1 WHERE id = ?").run(id);
}

export function clearUnread(id: string): void {
  getDb().prepare("UPDATE conversations SET unread = 0 WHERE id = ?").run(id);
}

export function updateConversationTitle(id: string, title: string): void {
  getDb().prepare("UPDATE conversations SET title = ? WHERE id = ?").run(title, id);
}

export function touchConversation(id: string, lastMessageAt: number, preview: string): void {
  getDb()
    .prepare("UPDATE conversations SET last_message_at = MAX(last_message_at, ?), last_preview = ? WHERE id = ?")
    .run(lastMessageAt, preview, id);
}

// ── messages ──────────────────────────────────────────────────────────────

function rowToMessage(row: Record<string, unknown>): Message {
  let attachments: AttachmentMeta[] = [];
  if (row.attachments) {
    try {
      attachments = JSON.parse(row.attachments as string) as AttachmentMeta[];
    } catch {
      attachments = [];
    }
  }
  return {
    id: row.id as string,
    seq: row.seq as number,
    qqMessageId: (row.qq_message_id as string | null) ?? null,
    conversationId: row.conversation_id as string,
    scope: row.scope as Scope,
    peerId: row.peer_id as string,
    direction: row.direction as MsgDirection,
    senderId: (row.sender_id as string | null) ?? null,
    senderName: (row.sender_name as string | null) ?? null,
    msgType: row.msg_type as MsgType,
    text: (row.text as string | null) ?? null,
    attachments,
    status: row.status as Message["status"],
    error: (row.error as string | null) ?? null,
    createdAt: row.created_at as number,
  };
}

export function insertMessage(m: {
  id: string;
  qqMessageId?: string | null;
  conversationId: string;
  scope: Scope;
  peerId: string;
  direction: MsgDirection;
  senderId?: string | null;
  senderName?: string | null;
  msgType: MsgType;
  text?: string | null;
  attachments?: AttachmentMeta[];
  status?: Message["status"];
  error?: string | null;
  createdAt: number;
}): Message {
  const db = getDb();
  db.prepare(
    `INSERT INTO messages (id, qq_message_id, conversation_id, scope, peer_id, direction, sender_id, sender_name, msg_type, text, attachments, status, error, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    m.id,
    m.qqMessageId ?? null,
    m.conversationId,
    m.scope,
    m.peerId,
    m.direction,
    m.senderId ?? null,
    m.senderName ?? null,
    m.msgType,
    m.text ?? null,
    JSON.stringify(m.attachments ?? []),
    m.status ?? "sent",
    m.error ?? null,
    m.createdAt,
  );
  const row = db.prepare("SELECT * FROM messages WHERE id = ?").get(m.id) as Record<string, unknown>;
  return rowToMessage(row);
}

export function findMessageByQQId(qqMessageId: string): Message | null {
  const row = getDb().prepare("SELECT * FROM messages WHERE qq_message_id = ?").get(qqMessageId) as
    | Record<string, unknown>
    | undefined;
  return row ? rowToMessage(row) : null;
}

export function getMessage(id: string): Message | null {
  const row = getDb().prepare("SELECT * FROM messages WHERE id = ?").get(id) as Record<string, unknown> | undefined;
  return row ? rowToMessage(row) : null;
}

export function updateMessageStatus(id: string, status: Message["status"], error?: string | null): void {
  getDb().prepare("UPDATE messages SET status = ?, error = ? WHERE id = ?").run(status, error ?? null, id);
}

/**
 * Paginated history. Returns messages in ascending order plus a `hasMore`
 * flag. Pagination uses the monotonic `seq` column so "load more" never skips
 * messages even when several share the same millisecond timestamp.
 */
// ── friend / group lifecycle events ────────────────────────────────────────

export interface FriendEvent {
  id: string;
  openid: string;
  scene: string | null;
  shortCode: string | null;
  eventTime: number;
  createdAt: number;
}

export interface GroupRobotEvent {
  id: string;
  eventType: "add" | "del";
  groupOpenid: string;
  opMemberOpenid: string | null;
  eventTime: number;
  createdAt: number;
}

export type JoinRequestStatus = "pending" | "approved" | "declined";

export interface JoinRequest {
  id: string;
  joinRequestId: string | null;
  groupOpenid: string;
  memberOpenid: string;
  username: string | null;
  applyAt: string | null;
  applySource: string | null;
  invitedBy: string | null;
  verifyInfo: Record<string, unknown> | null;
  riskTips: string | null;
  status: JoinRequestStatus;
  createdAt: number;
  processedAt: number | null;
}

function rowToFriendEvent(row: Record<string, unknown>): FriendEvent {
  return {
    id: row.id as string,
    openid: row.openid as string,
    scene: (row.scene as string | null) ?? null,
    shortCode: (row.short_code as string | null) ?? null,
    eventTime: row.event_time as number,
    createdAt: row.created_at as number,
  };
}

function rowToGroupRobotEvent(row: Record<string, unknown>): GroupRobotEvent {
  return {
    id: row.id as string,
    eventType: row.event_type as "add" | "del",
    groupOpenid: row.group_openid as string,
    opMemberOpenid: (row.op_member_openid as string | null) ?? null,
    eventTime: row.event_time as number,
    createdAt: row.created_at as number,
  };
}

function rowToJoinRequest(row: Record<string, unknown>): JoinRequest {
  let verifyInfo: Record<string, unknown> | null = null;
  if (row.verify_info) {
    try {
      verifyInfo = JSON.parse(row.verify_info as string) as Record<string, unknown>;
    } catch {
      verifyInfo = null;
    }
  }
  return {
    id: row.id as string,
    joinRequestId: (row.join_request_id as string | null) ?? null,
    groupOpenid: row.group_openid as string,
    memberOpenid: row.member_openid as string,
    username: (row.username as string | null) ?? null,
    applyAt: (row.apply_at as string | null) ?? null,
    applySource: (row.apply_source as string | null) ?? null,
    invitedBy: (row.invited_by as string | null) ?? null,
    verifyInfo,
    riskTips: (row.risk_tips as string | null) ?? null,
    status: row.status as JoinRequestStatus,
    createdAt: row.created_at as number,
    processedAt: (row.processed_at as number | null) ?? null,
  };
}

export function insertFriendEvent(e: { openid: string; scene?: string | null; shortCode?: string | null; eventTime: number }): FriendEvent {
  const id = randomUUID();
  getDb()
    .prepare("INSERT INTO friend_events (id, openid, scene, short_code, event_time, created_at) VALUES (?, ?, ?, ?, ?, ?)")
    .run(id, e.openid, e.scene ?? null, e.shortCode ?? null, e.eventTime, Date.now());
  return rowToFriendEvent(getDb().prepare("SELECT * FROM friend_events WHERE id = ?").get(id) as Record<string, unknown>);
}

export function listFriendEvents(limit = 100): FriendEvent[] {
  const rows = getDb().prepare("SELECT * FROM friend_events ORDER BY created_at DESC LIMIT ?").all(limit) as unknown as Record<string, unknown>[];
  return rows.map(rowToFriendEvent);
}

export function findFriendEventByOpenid(openid: string): FriendEvent | null {
  const row = getDb().prepare("SELECT * FROM friend_events WHERE openid = ? ORDER BY created_at DESC LIMIT 1").get(openid) as
    | Record<string, unknown>
    | undefined;
  return row ? rowToFriendEvent(row) : null;
}

export function insertGroupRobotEvent(e: { eventType: "add" | "del"; groupOpenid: string; opMemberOpenid?: string | null; eventTime: number }): GroupRobotEvent {
  const id = randomUUID();
  getDb()
    .prepare("INSERT INTO group_robot_events (id, event_type, group_openid, op_member_openid, event_time, created_at) VALUES (?, ?, ?, ?, ?, ?)")
    .run(id, e.eventType, e.groupOpenid, e.opMemberOpenid ?? null, e.eventTime, Date.now());
  return rowToGroupRobotEvent(getDb().prepare("SELECT * FROM group_robot_events WHERE id = ?").get(id) as Record<string, unknown>);
}

export function listGroupRobotEvents(limit = 100): GroupRobotEvent[] {
  const rows = getDb().prepare("SELECT * FROM group_robot_events ORDER BY created_at DESC LIMIT ?").all(limit) as unknown as Record<string, unknown>[];
  return rows.map(rowToGroupRobotEvent);
}

export function insertJoinRequest(r: {
  joinRequestId?: string | null;
  groupOpenid: string;
  memberOpenid: string;
  username?: string | null;
  applyAt?: string | null;
  applySource?: string | null;
  invitedBy?: string | null;
  verifyInfo?: Record<string, unknown> | null;
  riskTips?: string | null;
}): JoinRequest {
  const id = randomUUID();
  getDb()
    .prepare(
      `INSERT INTO join_requests (id, join_request_id, group_openid, member_openid, username, apply_at, apply_source, invited_by, verify_info, risk_tips, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`,
    )
    .run(
      id,
      r.joinRequestId ?? null,
      r.groupOpenid,
      r.memberOpenid,
      r.username ?? null,
      r.applyAt ?? null,
      r.applySource ?? null,
      r.invitedBy ?? null,
      r.verifyInfo ? JSON.stringify(r.verifyInfo) : null,
      r.riskTips ?? null,
      Date.now(),
    );
  return rowToJoinRequest(getDb().prepare("SELECT * FROM join_requests WHERE id = ?").get(id) as Record<string, unknown>);
}

export function getJoinRequest(id: string): JoinRequest | null {
  const row = getDb().prepare("SELECT * FROM join_requests WHERE id = ?").get(id) as Record<string, unknown> | undefined;
  return row ? rowToJoinRequest(row) : null;
}

export function listJoinRequests(status?: JoinRequestStatus, limit = 100): JoinRequest[] {
  const rows = (status
    ? getDb().prepare("SELECT * FROM join_requests WHERE status = ? ORDER BY created_at DESC LIMIT ?").all(status, limit)
    : getDb().prepare("SELECT * FROM join_requests ORDER BY created_at DESC LIMIT ?").all(limit)) as unknown as Record<string, unknown>[];
  return rows.map(rowToJoinRequest);
}

export function updateJoinRequestStatus(id: string, status: JoinRequestStatus): void {
  getDb().prepare("UPDATE join_requests SET status = ?, processed_at = ? WHERE id = ?").run(status, Date.now(), id);
}

export function countPendingRequests(): number {
  const row = getDb().prepare("SELECT COUNT(*) AS c FROM join_requests WHERE status = 'pending'").get() as { c: number };
  return row.c;
}

export function listMessages(
  conversationId: string,
  limit = 50,
  beforeSeq?: number,
): { messages: Message[]; hasMore: boolean } {
  const db = getDb();
  const rows = (beforeSeq
    ? db
        .prepare("SELECT * FROM messages WHERE conversation_id = ? AND seq < ? ORDER BY seq DESC LIMIT ?")
        .all(conversationId, beforeSeq, limit + 1)
    : db
        .prepare("SELECT * FROM messages WHERE conversation_id = ? ORDER BY seq DESC LIMIT ?")
        .all(conversationId, limit + 1)) as unknown as Record<string, unknown>[];
  const hasMore = rows.length > limit;
  const page = rows.slice(0, limit).reverse();
  return { messages: page.map(rowToMessage), hasMore };
}
