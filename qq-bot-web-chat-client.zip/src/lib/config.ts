import fs from "node:fs";
import path from "node:path";

/**
 * Central runtime configuration.
 *
 * All tunables are read from environment variables with sane defaults, so the
 * same build can run locally, under systemd, or behind a reverse proxy without
 * any code change.
 */
const dataDir = path.resolve(process.env.DATA_DIR || path.join(process.cwd(), "data"));

export const config = {
  dataDir,
  dbPath: path.join(dataDir, "qqbot.db"),
  logDir: path.join(dataDir, "logs"),
  logFile: path.join(dataDir, "logs", "app.log"),
  mediaDir: path.join(dataDir, "media"),
  outDir: path.join(dataDir, "media", "out"),
  inDir: path.join(dataDir, "media", "in"),
  secretKeyPath: path.join(dataDir, "secret.key"),

  logLevel: (process.env.LOG_LEVEL || "info").toLowerCase(),
  // Maximum accepted upload size from the browser (bytes). 200 MB default.
  maxUploadBytes: (Number(process.env.MAX_UPLOAD_MB) || 200) * 1024 * 1024,
  // Port is managed by Next.js; kept here for scripts/status reporting.
  port: Number(process.env.PORT || 3000),
} as const;

export type AppConfig = typeof config;

/** Create the on-disk directory tree used by the app (idempotent). */
export function ensureDirs(): void {
  for (const dir of [config.dataDir, config.logDir, config.mediaDir, config.outDir, config.inDir]) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

/** Rough estimate of free disk capacity for media housekeeping. */
export function freeDiskBytes(): number {
  try {
    const s = fs.statfsSync(config.dataDir);
    return s.bavail * s.bsize;
  } catch {
    return Infinity;
  }
}
