import { ApiError } from "@tencent-connect/qqbot-nodejs";

/**
 * Unified, user-facing error model.
 *
 * Every failure is normalised into a structured `QQErrorDetail` with a stable
 * machine-readable category plus a Chinese, human-readable message and a
 * concrete suggestion. The original error is always preserved in `raw`.
 */

export type ErrorCategory =
  | "AUTH_ERROR"
  | "NETWORK_ERROR"
  | "TIMEOUT"
  | "RATE_LIMIT"
  | "PERMISSION_DENIED"
  | "INVALID_REQUEST"
  | "MEDIA_ERROR"
  | "FILE_TOO_LARGE"
  | "UNSUPPORTED_MEDIA"
  | "TOKEN_EXPIRED"
  | "GATEWAY_ERROR"
  | "UNKNOWN_ERROR";

export interface QQErrorDetail {
  source: "qq" | "app" | "client";
  code: number | string;
  type: ErrorCategory;
  message: string;
  retryable: boolean;
  suggestion: string;
  raw?: string;
}

export class AppError extends Error {
  readonly detail: QQErrorDetail;
  constructor(detail: QQErrorDetail) {
    super(detail.message);
    this.name = "AppError";
    this.detail = detail;
  }
}

interface CodeRule {
  type: ErrorCategory;
  message: string;
  suggestion: string;
  retryable: boolean;
}

/** Known QQ Open Platform business error codes. */
const CODE_RULES: Record<number, CodeRule> = {
  10001: { type: "AUTH_ERROR", message: "AppID 或 AppSecret 错误", suggestion: "请核对凭证后重新连接", retryable: false },
  10003: { type: "AUTH_ERROR", message: "凭证无效", suggestion: "请核对凭证后重新连接", retryable: false },
  10004: { type: "AUTH_ERROR", message: "机器人不存在", suggestion: "请检查 AppID 是否正确", retryable: false },
  10006: { type: "AUTH_ERROR", message: "AppID 或 AppSecret 格式错误", suggestion: "请检查输入格式", retryable: false },
  22009: { type: "RATE_LIMIT", message: "消息发送超频", suggestion: "请稍后再试", retryable: true },
  40034104: { type: "RATE_LIMIT", message: "群消息发送频率受到限制", suggestion: "请稍后再试", retryable: true },
  40034090: { type: "PERMISSION_DENIED", message: "当前机器人没有 Markdown 权限", suggestion: "请改用普通文本消息", retryable: false },
  304082: { type: "MEDIA_ERROR", message: "富媒体资源拉取失败", suggestion: "请重新上传后再试", retryable: true },
  304083: { type: "MEDIA_ERROR", message: "富媒体资源转换失败", suggestion: "请更换文件格式后重试", retryable: true },
  40093001: { type: "MEDIA_ERROR", message: "文件上传失败", suggestion: "请重新上传", retryable: true },
  40093002: { type: "RATE_LIMIT", message: "已超过今天发送文件的容量上限", suggestion: "请明天再试或减小文件大小", retryable: false },
  850018: { type: "PERMISSION_DENIED", message: "群或机器人被禁言", suggestion: "请解除禁言后再发送", retryable: false },
  850019: { type: "UNSUPPORTED_MEDIA", message: "不支持的文件格式", suggestion: "请检查文件类型是否正确", retryable: false },
  850026: { type: "MEDIA_ERROR", message: "下载原始文件失败", suggestion: "请检查资源地址或重试", retryable: true },
  850027: { type: "TIMEOUT", message: "发送数据超时", suggestion: "请稍后重试", retryable: true },
  850031: { type: "FILE_TOO_LARGE", message: "上传文件超过大小限制", suggestion: "请减小文件大小后重试", retryable: false },
  10000: { type: "INVALID_REQUEST", message: "请求参数不正确", suggestion: "请检查输入内容", retryable: false },
};

function fromBizCode(code: number): QQErrorDetail {
  const rule = CODE_RULES[code];
  if (rule) {
    return {
      source: "qq",
      code,
      type: rule.type,
      message: rule.message,
      retryable: rule.retryable,
      suggestion: rule.suggestion,
    };
  }
  return {
    source: "qq",
    code,
    type: "UNKNOWN_ERROR",
    message: `QQ 平台返回错误 (${code})`,
    retryable: false,
    suggestion: "请查阅 QQ 开放平台文档或稍后重试",
  };
}

function fromHttpStatus(status: number, message: string, code?: number): QQErrorDetail {
  if (code !== undefined) return fromBizCode(code);
  if (status === 401) {
    return {
      source: "qq",
      code: 401,
      type: "TOKEN_EXPIRED",
      message: "访问凭证无效或已过期",
      retryable: true,
      suggestion: "系统将自动刷新凭证，请重试",
    };
  }
  if (status === 403) {
    return { source: "qq", code: 403, type: "PERMISSION_DENIED", message: "没有操作权限", retryable: false, suggestion: "请检查机器人权限配置" };
  }
  if (status === 429) {
    return { source: "qq", code: 429, type: "RATE_LIMIT", message: "请求过于频繁", retryable: true, suggestion: "请稍后再试" };
  }
  if (status >= 400 && status < 500) {
    return { source: "qq", code: status, type: "INVALID_REQUEST", message: message || "请求被拒绝", retryable: false, suggestion: "请检查输入内容" };
  }
  if (status === 0) {
    return { source: "app", code: 0, type: "NETWORK_ERROR", message: "网络连接失败", retryable: true, suggestion: "请检查网络后重试" };
  }
  return { source: "qq", code: status, type: "UNKNOWN_ERROR", message: message || "服务器错误", retryable: true, suggestion: "请稍后重试" };
}

/**
 * Convert any thrown value into a structured error detail. Understands the SDK
 * `ApiError` (carrying httpStatus / bizCode / bizMessage) as well as timeouts,
 * network failures and our own `AppError`.
 */
export function classifyError(err: unknown): QQErrorDetail {
  if (err instanceof AppError) return err.detail;

  if (err instanceof ApiError) {
    if (err.bizCode !== undefined) return { ...fromBizCode(err.bizCode), raw: err.bizMessage };
    if (err.httpStatus === 0) return { ...fromHttpStatus(0, err.bizMessage ?? err.message), raw: err.message };
    return { ...fromHttpStatus(err.httpStatus, err.bizMessage ?? err.message), raw: err.message };
  }

  const e = err as Error;
  const rawMessage = e?.message || String(err);
  const msg = rawMessage.toLowerCase();

  // SDK token fetch errors embed the QQ business code as JSON in the message
  // (e.g. `Failed to get access_token: {"code":10004,"message":"机器人不存在"}`).
  const embeddedCode = rawMessage.match(/"code"\s*:\s*(\d+)/);
  if (embeddedCode) {
    const code = Number(embeddedCode[1]);
    const embeddedMsg = rawMessage.match(/"message"\s*:\s*"([^"]+)"/)?.[1];
    return { ...fromBizCode(code), raw: embeddedMsg || rawMessage };
  }

  if (/timeout|timed out|abort|aborted|etimedout|esockettimedout/i.test(msg)) {
    return { source: "app", code: "TIMEOUT", type: "TIMEOUT", message: "请求超时", retryable: true, suggestion: "请稍后重试", raw: e?.message };
  }
  if (/econnreset|econnrefused|enetunreach|enotfound|network|socket|fetch failed/i.test(msg)) {
    return { source: "app", code: "NETWORK", type: "NETWORK_ERROR", message: "网络连接失败", retryable: true, suggestion: "请检查网络后重试", raw: e?.message };
  }
  if (/invalid|unauthorized|authentication|credential|appid|secret|4004/i.test(msg)) {
    return { source: "app", code: "AUTH", type: "AUTH_ERROR", message: "鉴权失败，请检查 AppID / AppSecret", retryable: false, suggestion: "请核对凭证后重新连接", raw: e?.message };
  }
  return { source: "app", code: "UNKNOWN", type: "UNKNOWN_ERROR", message: e?.message || "发生未知错误", retryable: false, suggestion: "请查看服务端日志", raw: e?.message };
}

/** Convenience for throwing a typed app error. */
export function appError(type: ErrorCategory, message: string, suggestion: string, retryable = false, code: number | string = type): AppError {
  return new AppError({ source: "app", code, type, message, suggestion, retryable });
}

/** Shape returned by every API endpoint on failure. */
export interface ApiErrorBody {
  success: false;
  error: QQErrorDetail;
}

export function errorBody(err: unknown): ApiErrorBody {
  const detail = classifyError(err);
  return { success: false, error: detail };
}
