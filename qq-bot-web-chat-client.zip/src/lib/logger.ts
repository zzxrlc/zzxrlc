import fs from "node:fs";
import path from "node:path";
import { config, ensureDirs } from "./config";

/**
 * Minimal, dependency-free leveled logger.
 *
 * - Levels: DEBUG < INFO < WARN < ERROR (configurable via LOG_LEVEL).
 * - Writes to stdout (for `journalctl`/pm2 capture) and a rotating log file.
 * - Never logs secrets: `logSecretSafe` redacts AppSecret / access_token values.
 */

type Level = "debug" | "info" | "warn" | "error";

const LEVEL_NUM: Record<Level, number> = { debug: 10, info: 20, warn: 30, error:40 };

const MAX_LOG_BYTES = 5 * 1024 * 1024; // rotate at 5 MB
const MAX_LOG_FILES = 3;

const SECRET_PATTERNS = [
  /("?(?:appSecret|clientSecret|access_token|secret)"?\s*[:=]\s*"?)[A-Za-z0-9\-_.]{6,}("?)/gi,
  /(QQBot\s+)[A-Za-z0-9\-_.]{8,}/gi,
  /(Bearer\s+)[A-Za-z0-9\-_.]{8,}/gi,
];

export function redactSecrets(input: string): string {
  let out = input;
  for (const re of SECRET_PATTERNS) {
    out = out.replace(re, "$1***REDACTED***$2");
  }
  return out;
}

let currentLevel: number = LEVEL_NUM[(config.logLevel as Level)] ?? LEVEL_NUM.info;
let logPath: string | null = null;

function rotateIfNeeded(): void {
  if (!logPath) return;
  try {
    const stat = fs.statSync(logPath);
    if (stat.size >= MAX_LOG_BYTES) {
      for (let i = MAX_LOG_FILES; i >= 1; i--) {
        const old = `${logPath}.${i}`;
        const next = `${logPath}.${i + 1}`;
        if (i === MAX_LOG_FILES) {
          if (fs.existsSync(old)) fs.unlinkSync(old);
          continue;
        }
        if (fs.existsSync(old)) fs.renameSync(old, next);
      }
      fs.renameSync(logPath, `${logPath}.1`);
    }
  } catch {
    /* rotation is best-effort */
  }
}

function write(level: Level, message: string, meta?: unknown): void {
  if (LEVEL_NUM[level] < currentLevel) return;
  const line = `[${new Date().toISOString()}] [${level.toUpperCase()}] ${message}`;
  const clean = redactSecrets(line);
  // eslint-disable-next-line no-console
  const printer = level === "error" ? console.error : level === "warn" ? console.warn : console.log;
  printer(clean);
  if (meta !== undefined) {
    printer(redactSecrets(safeStringify(meta)));
  }
  try {
    if (!logPath) {
      ensureDirs();
      logPath = path.join(config.logDir, "app.log");
    }
    rotateIfNeeded();
    fs.appendFileSync(logPath, clean + "\n", { encoding: "utf8" });
  } catch {
    /* logging must never crash the app */
  }
}

function safeStringify(v: unknown): string {
  try {
    return typeof v === "string" ? v : JSON.stringify(v);
  } catch {
    return String(v);
  }
}

export const log = {
  debug: (msg: string, meta?: unknown) => write("debug", msg, meta),
  info: (msg: string, meta?: unknown) => write("info", msg, meta),
  warn: (msg: string, meta?: unknown) => write("warn", msg, meta),
  error: (msg: string, meta?: unknown) => write("error", msg, meta),
  setLevel: (level: string) => {
    currentLevel = LEVEL_NUM[level as Level] ?? LEVEL_NUM.info;
  },
};

/**
 * Adapter that satisfies the QQ SDK's `Logger` interface. The SDK may pass
 * request bodies via `meta`; redaction happens in `write()` before output.
 */
export const sdkLogger = {
  info: (msg: string, meta?: Record<string, unknown>) => log.info(msg, meta),
  error: (msg: string, meta?: Record<string, unknown>) => log.error(msg, meta),
  warn: (msg: string, meta?: Record<string, unknown>) => log.warn(msg, meta),
  debug: (msg: string, meta?: Record<string, unknown>) => log.debug(msg, meta),
};
