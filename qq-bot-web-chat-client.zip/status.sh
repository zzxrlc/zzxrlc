#!/usr/bin/env bash
set -uo pipefail
cd "$(dirname "$0")"

PIDFILE="data/qqbot-web.pid"
PORT="${PORT:-3000}"

if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  PID="$(cat "$PIDFILE")"
  echo "状态: 运行中 (PID $PID)"
  RSS=$(ps -o rss= -p "$PID" 2>/dev/null | tr -d ' ')
  if [ -n "$RSS" ]; then
    echo "内存占用 (RSS): $((RSS / 1024)) MB"
  fi
else
  echo "状态: 未运行"
fi

if command -v curl >/dev/null 2>&1; then
  HTTP=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:${PORT}/api/health" 2>/dev/null || echo "000")
  echo "健康检查 /api/health: HTTP $HTTP"
fi
