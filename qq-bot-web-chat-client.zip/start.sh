#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

PIDFILE="data/qqbot-web.pid"
PORT="${PORT:-3000}"

if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "服务已在运行 (PID $(cat "$PIDFILE"))"
  exit 0
fi

if [ ! -f ".next/BUILD_ID" ]; then
  echo "==> 未检测到构建产物，先执行生产构建"
  npm run build
fi

mkdir -p data/logs
echo "==> 启动 QQ Bot Web（端口 ${PORT}）"
nohup env PORT="$PORT" node_modules/.bin/next start -p "$PORT" >> data/logs/server.log 2>&1 &
echo $! > "$PIDFILE"

sleep 2
if kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "==> 已启动 (PID $(cat "$PIDFILE"))"
  ./status.sh || true
else
  echo "==> 启动失败，请查看 data/logs/server.log"
  rm -f "$PIDFILE"
  exit 1
fi
