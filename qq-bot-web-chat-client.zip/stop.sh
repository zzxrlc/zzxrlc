#!/usr/bin/env bash
set -uo pipefail
cd "$(dirname "$0")"

PIDFILE="data/qqbot-web.pid"

if [ -f "$PIDFILE" ]; then
  PID="$(cat "$PIDFILE")"
  if kill -0 "$PID" 2>/dev/null; then
    echo "==> 停止服务 (PID $PID)"
    kill "$PID" 2>/dev/null || true
    for _ in $(seq 1 15); do
      kill -0 "$PID" 2>/dev/null || break
      sleep 1
    done
    if kill -0 "$PID" 2>/dev/null; then
      echo "==> 强制终止"
      kill -9 "$PID" 2>/dev/null || true
    fi
  fi
  rm -f "$PIDFILE"
fi
echo "==> 已停止"
