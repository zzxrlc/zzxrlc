#!/bin/sh
set -eu
RPK="$1"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python - <<PY
import zipfile,sys
p=sys.argv[1]; d=sys.argv[2]
z=zipfile.ZipFile(p); z.extractall(d)
print('Extracted',len(z.namelist()),'files')
PY "$RPK" "$TMP"
node - <<'JS' "$TMP/app.js"
const {Runtime}=require('../runtime/runtime.js');
const r=new Runtime();
try{r.runFile(process.argv[2]); console.log('APP.JS EXEC: OK'); console.log(r.logs.slice(0,30).join('\n'));}catch(e){console.error('APP.JS EXEC: FAIL',e.stack); process.exit(2)}
JS
