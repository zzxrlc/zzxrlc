'use strict';
const {Runtime}=require('../runtime/runtime.js');
const fs=require('fs');
const paths=process.argv.slice(2);
if(!paths.length){console.error('usage: node tools/run_samples.js <js...>');process.exit(2)}
let bad=0;
for(const f of paths){
 const r=new Runtime();
 try{
  r.runFile(f);
  console.log(`PASS ${f}`);
  console.log(`  registered: ${r.defines.join(', ')||'(none)'}`);
  const errs=r.logs.filter(x=>x.startsWith('DEFINE_ERROR'));
  if(errs.length){bad++; console.log('  runtime errors:',errs.join(' | '));}
 }catch(e){bad++; console.log(`FAIL ${f}\n  ${e.stack}`)}
}
process.exitCode=bad?1:0;
