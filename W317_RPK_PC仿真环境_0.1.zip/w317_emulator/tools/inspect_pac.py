from pathlib import Path
import re, json, sys
p=Path(sys.argv[1])
d=p.read_bytes()
keys=[
'JSFramework','jerryscript-2.3.0','PackageControl','jsfwk_check_can_install','jsfwk_check_can_run',
'MMIAPIXTC_JSFWK_CreateThirdJsAppTestWin','MMIAPIXTC_JSFWK_LAUNCH_RPK',
'MMIAPIXTC_VIDEO_CreateWin_WithAppPackageName','Xtc_JS_PlayVideoEntry','XtcPlayVideo_initContext',
'openInputMethod','nativeapi_fs_impl.c','nativeapi_network_impl.cpp','third_party/http-client',
'xtc_network_compliance_get_permission_en','GetPackageRpkPathWithPackageName'
]
print('PAC:',p)
print('size:',len(d))
for k in keys:
    i=d.find(k.encode())
    print(f'{k:55} {i}')
print('\nArchitecture / runtime clues:')
for k in [b'W317',b'Spreadtrum Boot Block',b'QuickJS',b'FreeRTOS',b'Zephyr',b'jerryscript-2.3.0']:
    print(k.decode(errors='ignore'), d.find(k))
