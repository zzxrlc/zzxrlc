import sys,zipfile,json,hashlib,posixpath,re
p=sys.argv[1]
z=zipfile.ZipFile(p)
names=z.namelist()
print('RPK:',p)
print('entries:',len(names))
for x in ['manifest.json','app.js','META-INF/CERT']:
    print(x, 'OK' if x in names else 'MISSING')
manifest=json.loads(z.read('manifest.json'))
print('package:',manifest.get('package'))
print('toolkit:',manifest.get('packageInfo',{}).get('toolkit'))
print('minPlatformVersion:',manifest.get('minPlatformVersion'))
print('features:',', '.join(x.get('name','') for x in manifest.get('features',[])))
app=z.read('app.js').decode('utf8','ignore')
for s in ['$app_define$("@app-application/app"','$app_bootstrap$("@app-application/app"','packagerVersion:"1.9.16"','window.createAppHandler']:
    print(s, 'YES' if s in app else 'NO')
if 'META-INF/CERT' in names:
    cert=z.read('META-INF/CERT')
    print('CERT bytes:',len(cert),'head:',cert[:8])
    if cert[:4]==b'PK\x03\x04':
      cz=zipfile.ZipFile(__import__('io').BytesIO(cert)); print('CERT entries:',cz.namelist())
      if 'hash.json' in cz.namelist():
       h=json.loads(cz.read('hash.json')); print('hash entries:',len(h) if isinstance(h,dict) else type(h).__name__)
print('zip test: OK')
z.testzip()
