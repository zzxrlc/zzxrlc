'use strict';
const vm = require('vm');
const fs = require('fs');

function baseModules(self) {
  return {
    '@app-module/system.media': { playVideo(o){ self.mediaCalls.push(o||{}); return true; }, getPlayState(){ return {state:'idle'}; }, seek(){} },
    '@app-module/system.input': { openInputMethod(o){ const out=self.inputQueue.length?self.inputQueue.shift():''; o?.success?.({outputText:out}); return true; }, closeInputMethod(){return true;} },
    '@app-module/system.prompt': { showToast(o){ self.logs.push('TOAST: '+(o?.message||'')); } },
    '@app-module/system.router': { push(o){self.routerCalls.push(['push',o]);}, replace(o){self.routerCalls.push(['replace',o]);}, back(){self.routerCalls.push(['back']);} },
    '@app-module/system.fetch': { fetch(o){ self.fetchCalls.push(o||{}); return Promise.resolve({code:200,data:{}}); } },
    '@app-module/system.request': { request(o){ self.requestCalls.push(o||{}); return Promise.resolve({code:200,data:{}}); } },
    '@app-module/system.file': { readText(o){return Promise.resolve({text:''});}, writeText(o){return Promise.resolve();}, list(o){return Promise.resolve([]);}, access(){return true;} },
    '@app-module/system.network': { getNetworkType(){return {type:'wifi'};} },
    '@app-module/system.storage': { get(o){o?.success?.({});}, set(o){o?.success?.();}, delete(o){o?.success?.();}, clear(){} },
    '@app-module/system.device': { getInfo(o){o?.success?.({manufacturer:'XTC',model:'W317'});} },
    '@app-module/system.configuration': { getLocale(){return {language:'zh',countryOrRegion:'CN'};} },
    '@app-module/system.package': {},
    '@app-module/system.xtc': {},
  };
}

class Runtime {
  constructor(opts={}) {
    this.logs=[]; this.mediaCalls=[]; this.routerCalls=[]; this.fetchCalls=[]; this.requestCalls=[]; this.inputQueue=[]; this.defines=[];
    const self=this;
    const modules=baseModules(self);
    this.context = vm.createContext({
      console:{log:(...a)=>self.logs.push(a.join(' ')),error:(...a)=>self.logs.push('ERROR '+a.join(' '))},
      setTimeout,clearTimeout,setInterval,clearInterval,JSON,Math,Date,Promise,
      $app_define$:(name,deps,factory)=>{ self.defines.push(name); const exports={}; const module={exports}; const requireHost=(name)=>self.hostModules[name] ?? (()=>{throw new Error('Host module not found: '+name)})(); try{ factory(requireHost,exports,module); }catch(e){ self.logs.push('DEFINE_ERROR '+name+': '+e.message); } self.exportsByName[name]=module.exports; },
      $app_bootstrap$:(name,meta)=>self.logs.push('BOOTSTRAP '+name+' '+JSON.stringify(meta)),
      $app_require$:(name)=>self.hostModules[name] ?? (()=>{throw new Error('Host module not found: '+name)})(),
      window: undefined,
    });
    this.exportsByName={};
    // The actual bundle's internal webpack-like require resolves @app-module/* through a runtime-provided hook.
    // We reproduce that hook by adding a helper the preprocessor injects into the bundle's module cache.
    this.hostModules=modules;
  }

  patchedSource(src){
    const entries=Object.entries(this.hostModules).map(([k,v])=>JSON.stringify(k)+':'+`globalThis.__hostModules[${JSON.stringify(k)}]`).join(',');
    // Bundle pattern: o={};function a(e){var t=o[e];...
    // Add host modules to the same cache object. This mirrors the runtime's external module resolution point.
    src=src.replace(/o=\{\};function\s*([A-Za-z_$][\w$]*)\(e\)\{/, `o={${entries}};function $1(e){`);
    return src;
  }

  runSource(src,label='<rpk>'){
    this.context.__hostModules=this.hostModules;
    const patched=this.patchedSource(src);
    return vm.runInContext(patched,this.context,{filename:label,timeout:5000});
  }
  runFile(file){ return this.runSource(fs.readFileSync(file,'utf8'),file); }
}
module.exports={Runtime};
