@echo off
setlocal
if "%~1"=="" (
  echo Usage: run.bat PAC_FILE [RPK_FILE ...]
  exit /b 2
)
python tools\inspect_pac.py "%~1"
shift
:loop
if "%~1"=="" goto done
python tools\validate_rpk.py "%~1"
for %%F in ("%~1") do (
  if exist "%%~dpFapp.js" (
    rem no-op
  )
)
shift
goto loop
:done
endlocal
