# W317 RPK PC Compatibility Harness

用途：在没有实体手表时，对 W317 PAC 和原生 RPK 做静态兼容性检查，并用 Windows/Node.js 对真实 1.9.16 bundle 做 host-side smoke test。

## 已根据固件确认的关键信息
- JSFramework 代码路径：`JSFramework/port/W317/...`
- JS 引擎：PAC 中包含 `jerryscript-2.3.0`
- RPK 安装/运行检查：`jsfwk_check_can_install`、`jsfwk_check_can_run`
- 第三方 JS App 窗口：`MMIAPIXTC_JSFWK_CreateThirdJsAppTestWin`
- 视频窗口：`MMIAPIXTC_VIDEO_CreateWin_WithAppPackageName`
- 视频入口：`Xtc_JS_PlayVideoEntry`、`XtcPlayVideo_initContext`
- 输入法：`openInputMethod` / `closeInputMethod`
- 文件 API：`move/copy/delete/list/get/readText/writeText/access/mkdir/rmdir/readArrayBuffer/writeArrayBuffer`
- 网络底层：`JSFramework/port/W317/networkkit/nativeapi_network_impl.cpp`
- HTTP 客户端：`JSFramework/third_party/http-client/httpclient/...`

## 原生 RPK 样本验证
`应用中心1.5.1.rpk` 和 `春节运营1.1.1(1).rpk` 都是 toolkit 1.9.16、minPlatformVersion 1070 的 RPK；两者 `META-INF/CERT` 内含 `hash.json`。

## 运行
1. 安装 Node.js LTS 和 Python 3。
2. 将 PAC 与 RPK 放到你电脑任意目录。
3. `python tools\\inspect_pac.py path\\to\\W3.1.6_2229_260626.pac`
4. `python tools\\validate_rpk.py path\\to\\应用中心1.5.1.rpk`
5. 解出 RPK 的 `app.js` / 页面 JS 后：
   `node tools\\run_samples.js extracted\\app.js extracted\\home\\index.js`

说明：这里的 `system.*` 是 Host stub，不是把 PAC 本身完整模拟成 QEMU。它用于提前验证真实 RPK bundle 的加载边界、manifest/封装和 JS API 调用路径。完整整机 QEMU 仍需确认 PAC 的 CPU/板级硬件是否有可模拟目标。
