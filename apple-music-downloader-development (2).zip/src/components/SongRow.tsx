"use client";

import { downloadHref, fmtDuration, type Song } from "./types";

type Props = {
  song: Song;
  index?: number;
  playing: boolean;
  onPlay: (song: Song) => void;
  onDownload: (song: Song) => void;
  onOpenAlbum?: (albumId: string, name: string, artist: string) => void;
  onCopy: (text: string) => void;
  compact?: boolean;
};

export default function SongRow({
  song,
  index,
  playing,
  onPlay,
  onDownload,
  onOpenAlbum,
  onCopy,
  compact,
}: Props) {
  const href = downloadHref(song);
  const unmatched = song.matched === false;

  return (
    <li
      className={`flex items-center gap-3 px-3 py-2.5 ${
        playing ? "bg-[#fa2d48]/10" : "active:bg-white/5"
      }`}
    >
      {compact ? (
        <span className="w-6 shrink-0 text-center text-sm tabular-nums text-zinc-500">
          {song.trackNumber ?? index}
        </span>
      ) : song.artworkUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={song.artworkUrl}
          alt=""
          className="h-12 w-12 shrink-0 rounded-md bg-zinc-800 object-cover"
          loading="lazy"
        />
      ) : (
        <div className="h-12 w-12 shrink-0 rounded-md bg-zinc-800" />
      )}

      <button
        type="button"
        onClick={() => song.previewUrl && onPlay(song)}
        className="min-w-0 flex-1 text-left"
        disabled={!song.previewUrl}
      >
        <div className="flex items-center gap-1.5">
          <span className={`truncate text-[15px] ${playing ? "text-[#fa2d48]" : "text-zinc-100"}`}>
            {song.name}
          </span>
          {song.explicit && (
            <span className="shrink-0 rounded-sm bg-zinc-600 px-1 text-[9px] font-bold leading-4 text-zinc-100">
              E
            </span>
          )}
          {unmatched && (
            <span className="shrink-0 rounded-sm bg-amber-500/20 px-1 text-[10px] leading-4 text-amber-300">
              未匹配
            </span>
          )}
        </div>
        <div className="truncate text-[13px] text-zinc-400">
          {song.artist}
          {!compact && song.album ? ` · ${song.album}` : ""}
        </div>
      </button>

      <span className="hidden text-xs tabular-nums text-zinc-500 sm:block">
        {fmtDuration(song.durationMs)}
      </span>

      <div className="flex shrink-0 items-center gap-1">
        {onOpenAlbum && song.albumId && !compact && (
          <IconBtn title="查看专辑" onClick={() => onOpenAlbum(song.albumId!, song.album, song.artist)}>
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
              <circle cx="12" cy="12" r="9" />
              <circle cx="12" cy="12" r="2.5" />
            </svg>
          </IconBtn>
        )}
        {song.url && (
          <IconBtn title="复制链接" onClick={() => onCopy(song.url)}>
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M10 13a5 5 0 0 0 7.07 0l2.83-2.83a5 5 0 0 0-7.07-7.07L11 4.93" />
              <path d="M14 11a5 5 0 0 0-7.07 0L4.1 13.83a5 5 0 0 0 7.07 7.07L13 19.07" />
            </svg>
          </IconBtn>
        )}
        {href ? (
          <IconBtn title="下载预览片段" onClick={() => onDownload(song)} accent>
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 4v11m0 0 4-4m-4 4-4-4M5 19h14" />
            </svg>
          </IconBtn>
        ) : (
          <span className="w-9" />
        )}
      </div>
    </li>
  );
}

function IconBtn({
  children,
  onClick,
  title,
  accent,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  accent?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      onClick={onClick}
      className={`flex h-9 w-9 items-center justify-center rounded-full ${
        accent ? "text-[#fa2d48] active:bg-[#fa2d48]/20" : "text-zinc-400 active:bg-white/10"
      }`}
    >
      {children}
    </button>
  );
}
