export type Song = {
  id: string;
  name: string;
  artist: string;
  album: string;
  albumId: string | null;
  url: string;
  previewUrl: string | null;
  artworkUrl: string | null;
  durationMs: number | null;
  trackNumber: number | null;
  discNumber: number | null;
  explicit: boolean;
  releaseDate: string | null;
  genre: string | null;
  source: "apple" | "deezer" | "musicbrainz";
  matched?: boolean;
};

export type Album = {
  id: string;
  name: string;
  artist: string;
  url: string;
  artworkUrl: string | null;
  trackCount: number | null;
  releaseDate: string | null;
  genre: string | null;
  copyright: string | null;
};

export type AccountInfo = {
  id: number;
  label: string;
  storefront: string;
  cookieCount: number;
  verified: boolean;
  verifyMessage: string | null;
  verifiedAt: string | null;
  createdAt: string;
  tokenPreview: string;
};

export type DownloadRow = {
  id: number;
  appleTrackId: string | null;
  trackName: string;
  artistName: string;
  albumName: string;
  appleUrl: string | null;
  previewUrl: string | null;
  artworkUrl: string | null;
  source: string;
  status: string;
  createdAt: string;
};

export type AlbumResponse = {
  album: Album | null;
  tracks: Song[];
  source: "apple" | "deezer" | "musicbrainz";
  fallback: {
    provider: string;
    providerId: string;
    name: string;
    artist: string;
    total: number;
    matched: number;
  } | null;
  error?: string;
};

export function fmtDuration(ms: number | null): string {
  if (!ms) return "--:--";
  const s = Math.round(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function downloadHref(song: Song): string | null {
  if (!song.previewUrl) return null;
  const filename = `${song.artist} - ${song.name}`;
  return `/api/download?url=${encodeURIComponent(song.previewUrl)}&filename=${encodeURIComponent(filename)}`;
}

export function sourceLabel(source: string): string {
  switch (source) {
    case "deezer":
      return "Deezer 兜底";
    case "musicbrainz":
      return "MusicBrainz 兜底";
    default:
      return "Apple Music";
  }
}
