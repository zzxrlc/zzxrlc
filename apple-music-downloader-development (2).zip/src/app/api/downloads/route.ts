import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { downloads } from "@/db/schema";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const format = searchParams.get("format");
  const rows = await db.select().from(downloads).orderBy(desc(downloads.id)).limit(500);

  if (format === "txt") {
    const lines = rows.map((r) => `${r.artistName} - ${r.trackName}\t${r.appleUrl ?? ""}`);
    return new Response(lines.join("\n"), {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": "attachment; filename=\"apple-music-links.txt\"",
      },
    });
  }
  if (format === "json") {
    return new Response(JSON.stringify(rows, null, 2), {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": "attachment; filename=\"apple-music-links.json\"",
      },
    });
  }
  return NextResponse.json({ downloads: rows });
}

export async function DELETE() {
  await db.delete(downloads);
  return NextResponse.json({ ok: true });
}
