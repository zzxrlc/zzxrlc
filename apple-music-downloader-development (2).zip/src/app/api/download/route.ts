import { NextResponse } from "next/server";
import { db } from "@/db";
import { downloads } from "@/db/schema";

export const runtime = "nodejs";

const ALLOWED_HOSTS = [/\.apple\.com$/i, /\.mzstatic\.com$/i, /\.itunes\.apple\.com$/i];

function safeFilename(name: string): string {
  return name.replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 150) || "track";
}

/**
 * Proxies Apple's official preview clip so the browser can save it with a
 * proper filename (iOS Safari does not honour cross-origin `download`).
 */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const url = searchParams.get("url") ?? "";
  const filename = safeFilename(searchParams.get("filename") ?? "preview");

  let target: URL;
  try {
    target = new URL(url);
  } catch {
    return NextResponse.json({ error: "无效的 URL" }, { status: 400 });
  }
  if (!ALLOWED_HOSTS.some((re) => re.test(target.hostname))) {
    return NextResponse.json({ error: "仅允许下载 Apple 官方预览资源" }, { status: 403 });
  }

  const upstream = await fetch(target, { signal: AbortSignal.timeout(30_000), cache: "no-store" });
  if (!upstream.ok || !upstream.body) {
    return NextResponse.json({ error: `上游返回 ${upstream.status}` }, { status: 502 });
  }

  const ext = target.pathname.match(/\.(m4a|mp4|aac|m4v)$/i)?.[1]?.toLowerCase() ?? "m4a";
  const contentType = upstream.headers.get("content-type") ?? "audio/mp4";

  return new Response(upstream.body, {
    headers: {
      "Content-Type": contentType,
      "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(`${filename}.${ext}`)}`,
      "Cache-Control": "no-store",
    },
  });
}

/** Record a download / export event. */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as
    | {
        items?: {
          id?: string;
          name: string;
          artist?: string;
          album?: string;
          url?: string;
          previewUrl?: string | null;
          artworkUrl?: string | null;
          source?: string;
        }[];
        status?: string;
      }
    | null;

  if (!body?.items?.length) {
    return NextResponse.json({ error: "缺少 items" }, { status: 400 });
  }

  const rows = await db
    .insert(downloads)
    .values(
      body.items.map((i) => ({
        appleTrackId: i.id ?? null,
        trackName: i.name,
        artistName: i.artist ?? "",
        albumName: i.album ?? "",
        appleUrl: i.url ?? null,
        previewUrl: i.previewUrl ?? null,
        artworkUrl: i.artworkUrl ?? null,
        source: i.source ?? "apple",
        status: body.status ?? "done",
      })),
    )
    .returning();

  return NextResponse.json({ inserted: rows.length });
}
