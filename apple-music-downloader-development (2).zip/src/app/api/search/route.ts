import { NextResponse } from "next/server";
import { db } from "@/db";
import { searchLogs } from "@/db/schema";
import { getStorefront } from "@/lib/account";
import { searchAlbums, searchSongs } from "@/lib/apple";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") ?? "").trim();
  const kind = searchParams.get("kind") === "album" ? "album" : "song";
  const country = (searchParams.get("country") ?? (await getStorefront())).toLowerCase();

  if (!q) return NextResponse.json({ error: "缺少搜索词" }, { status: 400 });

  try {
    if (kind === "album") {
      const albums = await searchAlbums(q, country, 50);
      await db.insert(searchLogs).values({ query: q, kind, resultCount: albums.length });
      return NextResponse.json({ kind, country, albums });
    }
    const songs = await searchSongs(q, country, 50);
    await db.insert(searchLogs).values({ query: q, kind, resultCount: songs.length });
    return NextResponse.json({ kind, country, songs });
  } catch (err) {
    const message = err instanceof Error ? err.message : "搜索失败";
    return NextResponse.json({ error: `Apple 搜索接口错误：${message}` }, { status: 502 });
  }
}
