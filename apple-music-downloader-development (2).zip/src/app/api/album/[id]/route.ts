import { NextResponse } from "next/server";
import { getStorefront } from "@/lib/account";
import { lookupAlbum } from "@/lib/apple";
import { matchTracksToApple, resolveFallbackAlbum } from "@/lib/fallback";

export const runtime = "nodejs";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const { searchParams } = new URL(req.url);
  const country = (searchParams.get("country") ?? (await getStorefront())).toLowerCase();
  const forceFallback = searchParams.get("fallback") === "1";
  const hintName = searchParams.get("name") ?? "";
  const hintArtist = searchParams.get("artist") ?? "";

  let album = null;
  let tracks: Awaited<ReturnType<typeof lookupAlbum>>["tracks"] = [];
  let appleError: string | null = null;

  try {
    const res = await lookupAlbum(id, country);
    album = res.album;
    tracks = res.tracks;
  } catch (err) {
    appleError = err instanceof Error ? err.message : "lookup failed";
  }

  if (!forceFallback && tracks.length > 0) {
    return NextResponse.json({ album, tracks, source: "apple", fallback: null });
  }

  // Apple could not output this album's tracklist -> third-party fallback.
  const name = album?.name || hintName;
  const artist = album?.artist || hintArtist;
  if (!name) {
    return NextResponse.json(
      { error: appleError ? `Apple 查询失败：${appleError}` : "Apple 未返回该专辑，且缺少专辑名用于兜底搜索" },
      { status: 404 },
    );
  }

  const fb = await resolveFallbackAlbum(name, artist);
  if (!fb) {
    return NextResponse.json(
      {
        album,
        tracks: [],
        source: "apple",
        fallback: null,
        error: "Apple 与第三方（Deezer / MusicBrainz）均未找到该专辑的曲目",
      },
      { status: 404 },
    );
  }

  const matched = await matchTracksToApple(fb.tracks, country, fb.provider);
  return NextResponse.json({
    album: album ?? {
      id,
      name: fb.name,
      artist: fb.artist,
      url: "",
      artworkUrl: fb.artworkUrl,
      trackCount: fb.tracks.length,
      releaseDate: null,
      genre: null,
      copyright: null,
      source: "apple",
    },
    tracks: matched,
    source: fb.provider,
    fallback: {
      provider: fb.provider,
      providerId: fb.providerId,
      name: fb.name,
      artist: fb.artist,
      total: fb.tracks.length,
      matched: matched.filter((t) => t.matched).length,
    },
  });
}
