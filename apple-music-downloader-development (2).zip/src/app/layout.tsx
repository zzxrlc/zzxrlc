import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "AM Downloader · Apple Music 搜索下载器",
  description:
    "导入 cookies 登录 Apple Music，纯音乐搜索、专辑查看、第三方歌单兜底与预览下载。可作为 PWA 添加到 iOS 主屏幕。",
  manifest: "/manifest.webmanifest",
  applicationName: "AM Downloader",
  appleWebApp: {
    capable: true,
    title: "AM Downloader",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: "/icons/icon-512.png",
    apple: "/icons/icon-512.png",
  },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: "#0b0b0f",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="zh-CN">
      <body className="min-h-dvh bg-[#0b0b0f] text-zinc-100 antialiased">{children}</body>
    </html>
  );
}
