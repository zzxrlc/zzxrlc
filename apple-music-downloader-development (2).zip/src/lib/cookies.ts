/**
 * Cookie import, modelled on how gamdl consumes `cookies.txt`.
 *
 * gamdl reads a Netscape-format cookies file exported from music.apple.com and
 * pulls two things out of it:
 *   - `media-user-token`  -> sent as the `media-user-token` header to amp-api
 *   - `itua`              -> the user's storefront (country code)
 *
 * We accept the same Netscape format, plus a raw `Cookie:` header string and the
 * JSON array format produced by browser extensions such as EditThisCookie.
 */

export type ParsedCookies = {
  cookies: Record<string, string>;
  mediaUserToken: string | null;
  storefront: string;
  count: number;
  format: "netscape" | "header" | "json" | "unknown";
};

function normalizeStorefront(raw: string | undefined): string {
  if (!raw) return "us";
  const value = decodeURIComponent(raw).trim().toLowerCase();
  return /^[a-z]{2}$/.test(value) ? value : "us";
}

export function parseCookies(input: string): ParsedCookies {
  const text = input.trim();
  const cookies: Record<string, string> = {};
  let format: ParsedCookies["format"] = "unknown";

  if (!text) {
    return { cookies, mediaUserToken: null, storefront: "us", count: 0, format };
  }

  // 1) JSON export (array of {name, value}) or object map
  if (text.startsWith("[") || text.startsWith("{")) {
    try {
      const parsed = JSON.parse(text) as unknown;
      if (Array.isArray(parsed)) {
        for (const item of parsed) {
          if (item && typeof item === "object" && "name" in item && "value" in item) {
            const c = item as { name: string; value: string };
            cookies[String(c.name)] = String(c.value);
          }
        }
        format = "json";
      } else if (parsed && typeof parsed === "object") {
        for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
          cookies[k] = String(v);
        }
        format = "json";
      }
    } catch {
      // fall through to other formats
    }
  }

  // 2) Netscape cookies.txt (7 tab-separated columns, `#` comments)
  if (format === "unknown") {
    const lines = text.split(/\r?\n/);
    let netscapeHits = 0;
    for (const line of lines) {
      if (!line || line.startsWith("#")) continue;
      const cols = line.split("\t");
      if (cols.length >= 7) {
        const name = cols[5].trim();
        const value = cols.slice(6).join("\t").trim();
        if (name) {
          cookies[name] = value;
          netscapeHits++;
        }
      }
    }
    if (netscapeHits > 0) format = "netscape";
  }

  // 3) Raw `Cookie:` header / document.cookie string
  if (format === "unknown" && text.includes("=")) {
    const body = text.replace(/^cookie:\s*/i, "");
    for (const part of body.split(/;\s*/)) {
      const idx = part.indexOf("=");
      if (idx > 0) {
        cookies[part.slice(0, idx).trim()] = part.slice(idx + 1).trim();
      }
    }
    if (Object.keys(cookies).length > 0) format = "header";
  }

  const mediaUserToken =
    cookies["media-user-token"] ?? cookies["mediaUserToken"] ?? null;
  const storefront = normalizeStorefront(cookies["itua"]);

  return {
    cookies,
    mediaUserToken: mediaUserToken ? decodeURIComponent(mediaUserToken) : null,
    storefront,
    count: Object.keys(cookies).length,
    format,
  };
}

export function maskToken(token: string): string {
  if (token.length <= 12) return "••••••";
  return `${token.slice(0, 6)}…${token.slice(-6)}`;
}
