/**
 * Third-party album tracklist fallback.
 *
 * When Apple's lookup cannot return an album's tracks (region-locked, removed,
 * pre-release, etc.) we resolve the tracklist from a public catalog API
 * (Deezer first, MusicBrainz second) and then match each track back to Apple
 * Music via the single-song search to obtain the proper name + URL.
 */

import { matchSong, type Song } from "./apple";

export type FallbackTrack = {
  position: number;
  title: string;
  artist: string;
  durationMs: number | null;
};

export type FallbackAlbum = {
  provider: "deezer" | "musicbrainz";
  providerId: string;
  name: string;
  artist: string;
  artworkUrl: string | null;
  tracks: FallbackTrack[];
};

const TIMEOUT_MS = 10_000;
const MB_UA = "AppleMusicSearchDownloader/1.0 (https://example.invalid)";

async function getJson<T>(url: string, headers: Record<string, string> = {}): Promise<T> {
  const res = await fetch(url, {
    headers: { Accept: "application/json", ...headers },
    signal: AbortSignal.timeout(TIMEOUT_MS),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} from ${new URL(url).host}`);
  return (await res.json()) as T;
}

/* ------------------------------ Deezer -------------------------------- */

type DeezerAlbum = {
  id: number;
  title: string;
  cover_xl?: string;
  cover_big?: string;
  artist?: { name: string };
  nb_tracks?: number;
};

export async function deezerFindAlbum(
  album: string,
  artist: string,
): Promise<FallbackAlbum | null> {
  const q = artist ? `artist:"${artist}" album:"${album}"` : album;
  const search = await getJson<{ data: DeezerAlbum[] }>(
    `https://api.deezer.com/search/album?q=${encodeURIComponent(q)}&limit=5`,
  );
  let hit = search.data?.[0];
  if (!hit) {
    const loose = await getJson<{ data: DeezerAlbum[] }>(
      `https://api.deezer.com/search/album?q=${encodeURIComponent(`${artist} ${album}`)}&limit=5`,
    );
    hit = loose.data?.[0];
  }
  if (!hit) return null;

  const detail = await getJson<
    DeezerAlbum & {
      tracks?: { data: { title: string; duration: number; track_position?: number; artist?: { name: string } }[] };
    }
  >(`https://api.deezer.com/album/${hit.id}`);

  const tracks = (detail.tracks?.data ?? []).map((t, i) => ({
    position: t.track_position ?? i + 1,
    title: t.title,
    artist: t.artist?.name ?? detail.artist?.name ?? artist,
    durationMs: t.duration ? t.duration * 1000 : null,
  }));

  return {
    provider: "deezer",
    providerId: String(detail.id),
    name: detail.title,
    artist: detail.artist?.name ?? artist,
    artworkUrl: detail.cover_xl ?? detail.cover_big ?? null,
    tracks,
  };
}

/* ---------------------------- MusicBrainz ----------------------------- */

type MBRelease = {
  id: string;
  title: string;
  "artist-credit"?: { name: string }[];
  media?: { tracks?: { position: number; title: string; length?: number }[] }[];
};

export async function musicbrainzFindAlbum(
  album: string,
  artist: string,
): Promise<FallbackAlbum | null> {
  const query = artist ? `release:"${album}" AND artist:"${artist}"` : `release:"${album}"`;
  const search = await getJson<{ releases: MBRelease[] }>(
    `https://musicbrainz.org/ws/2/release/?query=${encodeURIComponent(query)}&fmt=json&limit=5`,
    { "User-Agent": MB_UA },
  );
  const hit = search.releases?.[0];
  if (!hit) return null;

  const detail = await getJson<MBRelease>(
    `https://musicbrainz.org/ws/2/release/${hit.id}?inc=recordings+artist-credits&fmt=json`,
    { "User-Agent": MB_UA },
  );
  const artistName = detail["artist-credit"]?.map((a) => a.name).join("") || artist;
  const tracks: FallbackTrack[] = [];
  let offset = 0;
  for (const medium of detail.media ?? []) {
    for (const t of medium.tracks ?? []) {
      tracks.push({
        position: offset + t.position,
        title: t.title,
        artist: artistName,
        durationMs: t.length ?? null,
      });
    }
    offset += medium.tracks?.length ?? 0;
  }
  return {
    provider: "musicbrainz",
    providerId: detail.id,
    name: detail.title,
    artist: artistName,
    artworkUrl: `https://coverartarchive.org/release/${detail.id}/front-500`,
    tracks,
  };
}

/* ------------------------------ Resolver ------------------------------ */

export async function resolveFallbackAlbum(
  album: string,
  artist: string,
): Promise<FallbackAlbum | null> {
  try {
    const dz = await deezerFindAlbum(album, artist);
    if (dz && dz.tracks.length > 0) return dz;
  } catch {
    // ignore, try next provider
  }
  try {
    const mb = await musicbrainzFindAlbum(album, artist);
    if (mb && mb.tracks.length > 0) return mb;
  } catch {
    // ignore
  }
  return null;
}

/** Match every fallback track back to Apple Music with limited concurrency. */
export async function matchTracksToApple(
  tracks: FallbackTrack[],
  country: string,
  provider: FallbackAlbum["provider"],
  concurrency = 4,
): Promise<Song[]> {
  const results: Song[] = new Array(tracks.length);
  let cursor = 0;
  async function worker() {
    while (cursor < tracks.length) {
      const idx = cursor++;
      const t = tracks[idx];
      const hit = await matchSong(t.title, t.artist, country).catch(() => null);
      results[idx] = hit
        ? { ...hit, trackNumber: t.position, source: provider }
        : {
            id: `${provider}-${idx}`,
            name: t.title,
            artist: t.artist,
            album: "",
            albumId: null,
            url: "",
            previewUrl: null,
            artworkUrl: null,
            durationMs: t.durationMs,
            trackNumber: t.position,
            discNumber: 1,
            explicit: false,
            releaseDate: null,
            genre: null,
            source: provider,
            matched: false,
          };
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, tracks.length) }, worker));
  return results;
}
