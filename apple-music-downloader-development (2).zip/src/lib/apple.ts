/**
 * Apple Music catalog access.
 *
 * Two channels, mirroring gamdl's design:
 *  1. Public iTunes Search API (no auth) – used for search / album lookup and
 *     filtered so that ONLY music (songs / albums) is returned.
 *  2. amp-api.music.apple.com – gamdl's authenticated channel. It needs a bearer
 *     token scraped from music.apple.com's JS bundle plus the `media-user-token`
 *     cookie. We use it to verify an imported cookie file and, when available,
 *     to fetch richer album metadata.
 */

export type Song = {
  id: string;
  name: string;
  artist: string;
  album: string;
  albumId: string | null;
  url: string;
  previewUrl: string | null;
  artworkUrl: string | null;
  durationMs: number | null;
  trackNumber: number | null;
  discNumber: number | null;
  explicit: boolean;
  releaseDate: string | null;
  genre: string | null;
  source: "apple" | "deezer" | "musicbrainz";
  matched?: boolean;
};

export type Album = {
  id: string;
  name: string;
  artist: string;
  url: string;
  artworkUrl: string | null;
  trackCount: number | null;
  releaseDate: string | null;
  genre: string | null;
  copyright: string | null;
  source: "apple";
};

const ITUNES = "https://itunes.apple.com";
const AMP = "https://amp-api.music.apple.com";
const TIMEOUT_MS = 10_000;

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15";

export function upscaleArtwork(url: string | null | undefined, size = 600): string | null {
  if (!url) return null;
  // iTunes returns .../100x100bb.jpg ; amp-api returns {w}x{h} templates.
  return url
    .replace("{w}x{h}", `${size}x${size}`)
    .replace(/\/\d+x\d+(bb|-\d+)?\.(jpg|png|webp)$/i, `/${size}x${size}bb.$2`);
}

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "User-Agent": UA, Accept: "application/json", ...(init?.headers ?? {}) },
    signal: AbortSignal.timeout(TIMEOUT_MS),
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} from ${new URL(url).host}`);
  }
  return (await res.json()) as T;
}

/* ---------------------------------------------------------------------- */
/* iTunes Search API (public)                                              */
/* ---------------------------------------------------------------------- */

type ITunesItem = {
  wrapperType?: string;
  kind?: string;
  collectionType?: string;
  trackId?: number;
  collectionId?: number;
  trackName?: string;
  collectionName?: string;
  artistName?: string;
  trackViewUrl?: string;
  collectionViewUrl?: string;
  previewUrl?: string;
  artworkUrl100?: string;
  trackTimeMillis?: number;
  trackNumber?: number;
  discNumber?: number;
  trackExplicitness?: string;
  collectionExplicitness?: string;
  releaseDate?: string;
  primaryGenreName?: string;
  trackCount?: number;
  copyright?: string;
  isStreamable?: boolean;
};

function isSong(item: ITunesItem): boolean {
  return item.wrapperType === "track" && item.kind === "song";
}

function isAlbum(item: ITunesItem): boolean {
  return item.wrapperType === "collection" && item.collectionType === "Album";
}

export function toSong(item: ITunesItem): Song {
  return {
    id: String(item.trackId),
    name: item.trackName ?? "",
    artist: item.artistName ?? "",
    album: item.collectionName ?? "",
    albumId: item.collectionId ? String(item.collectionId) : null,
    url: item.trackViewUrl ?? item.collectionViewUrl ?? "",
    previewUrl: item.previewUrl ?? null,
    artworkUrl: upscaleArtwork(item.artworkUrl100),
    durationMs: item.trackTimeMillis ?? null,
    trackNumber: item.trackNumber ?? null,
    discNumber: item.discNumber ?? null,
    explicit: item.trackExplicitness === "explicit",
    releaseDate: item.releaseDate ?? null,
    genre: item.primaryGenreName ?? null,
    source: "apple",
  };
}

function toAlbum(item: ITunesItem): Album {
  return {
    id: String(item.collectionId),
    name: item.collectionName ?? "",
    artist: item.artistName ?? "",
    url: item.collectionViewUrl ?? "",
    artworkUrl: upscaleArtwork(item.artworkUrl100),
    trackCount: item.trackCount ?? null,
    releaseDate: item.releaseDate ?? null,
    genre: item.primaryGenreName ?? null,
    copyright: item.copyright ?? null,
    source: "apple",
  };
}

export async function searchSongs(term: string, country: string, limit = 50): Promise<Song[]> {
  const params = new URLSearchParams({
    term,
    country,
    media: "music",
    entity: "song",
    limit: String(limit),
  });
  const data = await fetchJson<{ results: ITunesItem[] }>(`${ITUNES}/search?${params}`);
  // Filter away anything that is not a plain song (music videos, podcasts, etc.)
  return data.results.filter(isSong).map(toSong);
}

export async function searchAlbums(term: string, country: string, limit = 50): Promise<Album[]> {
  const params = new URLSearchParams({
    term,
    country,
    media: "music",
    entity: "album",
    limit: String(limit),
  });
  const data = await fetchJson<{ results: ITunesItem[] }>(`${ITUNES}/search?${params}`);
  return data.results.filter(isAlbum).map(toAlbum);
}

export async function lookupAlbum(
  albumId: string,
  country: string,
): Promise<{ album: Album | null; tracks: Song[] }> {
  const params = new URLSearchParams({ id: albumId, country, entity: "song", limit: "200" });
  const data = await fetchJson<{ results: ITunesItem[] }>(`${ITUNES}/lookup?${params}`);
  const albumItem = data.results.find(isAlbum) ?? null;
  const tracks = data.results
    .filter(isSong)
    .map(toSong)
    .sort(
      (a, b) =>
        (a.discNumber ?? 1) - (b.discNumber ?? 1) || (a.trackNumber ?? 0) - (b.trackNumber ?? 0),
    );
  return { album: albumItem ? toAlbum(albumItem) : null, tracks };
}

/** Find the best iTunes song match for a "title + artist" pair (used by fallbacks). */
export async function matchSong(
  title: string,
  artist: string,
  country: string,
): Promise<Song | null> {
  const candidates = await searchSongs(`${artist} ${title}`, country, 10).catch(() => []);
  if (candidates.length === 0) return null;
  const norm = (s: string) =>
    s
      .toLowerCase()
      .replace(/\(.*?\)|\[.*?\]/g, "")
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim();
  const t = norm(title);
  const a = norm(artist);
  const scored = candidates.map((c) => {
    let score = 0;
    const cn = norm(c.name);
    const ca = norm(c.artist);
    if (cn === t) score += 5;
    else if (cn.includes(t) || t.includes(cn)) score += 3;
    if (ca === a) score += 3;
    else if (ca.includes(a) || a.includes(ca)) score += 2;
    return { c, score };
  });
  scored.sort((x, y) => y.score - x.score);
  return scored[0].score >= 3 ? { ...scored[0].c, matched: true } : { ...scored[0].c, matched: false };
}

/* ---------------------------------------------------------------------- */
/* amp-api (authenticated, gamdl-style)                                    */
/* ---------------------------------------------------------------------- */

const tokenCache: { token: string | null; fetchedAt: number } = { token: null, fetchedAt: 0 };
const TOKEN_TTL = 12 * 60 * 60 * 1000;

/**
 * gamdl obtains the developer bearer token by loading music.apple.com, locating
 * the main JS bundle and regex-matching the embedded JWT (`eyJh...`).
 */
export async function getDeveloperToken(): Promise<string> {
  if (tokenCache.token && Date.now() - tokenCache.fetchedAt < TOKEN_TTL) {
    return tokenCache.token;
  }
  const home = await fetch("https://music.apple.com", {
    headers: { "User-Agent": UA },
    signal: AbortSignal.timeout(TIMEOUT_MS),
    cache: "no-store",
    redirect: "follow",
  });
  const html = await home.text();
  // Same regex as gamdl: /assets/index~<hash>.js or /assets/index-<hash>.js
  const indexMatch = html.match(/\/(assets\/index[~-][^/"]+\.js)/);
  if (!indexMatch) throw new Error("在 music.apple.com 首页未找到 index.js");

  const js = await fetch(`https://music.apple.com/${indexMatch[1]}`, {
    headers: { "User-Agent": UA },
    signal: AbortSignal.timeout(TIMEOUT_MS),
    cache: "no-store",
  }).then((r) => r.text());

  const tokenMatch = js.match(/"(eyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+)"/);
  if (!tokenMatch) throw new Error("index.js 中未找到 developer token");

  tokenCache.token = tokenMatch[1];
  tokenCache.fetchedAt = Date.now();
  return tokenMatch[1];
}

type AccountInfoResponse = {
  meta?: {
    subscription?: {
      active?: boolean;
      storefront?: string;
      isTrial?: boolean;
      expirationDate?: string;
    };
  };
};

export async function verifyMediaUserToken(
  mediaUserToken: string,
  storefront: string,
): Promise<{ ok: boolean; message: string; storefront: string }> {
  try {
    const devToken = await getDeveloperToken();
    // gamdl: GET /v1/me/account?meta=subscription with the media-user-token header
    const data = await fetchJson<AccountInfoResponse>(`${AMP}/v1/me/account?meta=subscription`, {
      headers: {
        Authorization: `Bearer ${devToken}`,
        "media-user-token": mediaUserToken,
        Origin: "https://music.apple.com",
        Referer: "https://music.apple.com/",
      },
    });
    const sub = data.meta?.subscription;
    const sf = (sub?.storefront ?? storefront).toLowerCase();
    const status = sub?.active
      ? `订阅有效${sub.isTrial ? "（试用）" : ""}`
      : "账号有效但无有效 Apple Music 订阅";
    return {
      ok: true,
      message: `已通过 amp-api 验证 · ${status} · 店面 ${sf.toUpperCase()}`,
      storefront: sf,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (/HTTP 401|HTTP 403/.test(msg)) {
      return { ok: false, message: "media-user-token 无效或已过期 (401/403)", storefront };
    }
    return {
      ok: false,
      message: `无法联系 amp-api（${msg}），已保存 cookies，将使用公开搜索 API`,
      storefront,
    };
  }
}
