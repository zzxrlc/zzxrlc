import Link from "next/link";
import { IconBack, IconBolt, IconCheck, IconServer } from "@/components/ui";

export const metadata = { title: "服务器部署教程 · QQ 机器人工作台" };

function Code({ children }: { children: string }) {
  return (
    <pre className="bg-night text-night-text rounded-xl px-4 py-3.5 text-[13px] leading-relaxed overflow-x-auto whitespace-pre">
      <code>{children}</code>
    </pre>
  );
}

function H2({ n, children }: { n: string; children: React.ReactNode }) {
  return (
    <h2 className="font-display text-xl font-bold mt-10 mb-3 flex items-center gap-2.5">
      <span className="h-7 w-7 rounded-lg bg-brand text-white text-sm grid place-items-center shrink-0">{n}</span>
      {children}
    </h2>
  );
}

export default function GuidePage() {
  return (
    <div className="min-h-dvh bg-paper">
      <header className="bg-night text-white">
        <div className="max-w-3xl mx-auto px-5 py-10">
          <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-night-text/70 hover:text-white mb-6">
            <IconBack size={16} /> 返回工作台
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <span className="h-11 w-11 rounded-xl bg-brand grid place-items-center">
              <IconServer size={22} />
            </span>
            <h1 className="font-display text-3xl font-bold">服务器部署教程</h1>
          </div>
          <p className="text-night-text/75 leading-relaxed">
            把「QQ 机器人工作台」部署到你自己的 Linux 服务器，7×24 小时常驻接收消息；浏览器随开随用，离线期间的消息一条不丢。
          </p>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-5 pb-20 text-[15px] leading-relaxed">
        <H2 n="1">准备：创建 QQ 机器人</H2>
        <ol className="list-decimal pl-5 space-y-1.5 text-ink-soft">
          <li>
            打开 <b className="text-ink">QQ 开放平台 q.qq.com</b>，注册并创建一个「机器人」，完成主体认证。
          </li>
          <li>
            在机器人管理页的 <b className="text-ink">开发设置</b> 中拿到 <b className="text-ink">AppID</b> 与 <b className="text-ink">AppSecret</b>。
          </li>
          <li>
            在 <b className="text-ink">权限申请 / 机器人能力</b> 中，为机器人开通：
            <span className="block mt-1 space-y-1">
              <Tip text="群聊消息收发（群聊 @机器人 / 私聊消息）" />
              <Tip text="群聊消息记录、私聊消息记录（用于离线补拉历史消息，强烈建议开通）" />
              <Tip text="群成员列表（可选，用于查看群成员）" />
            </span>
          </li>
          <li>沙箱 / 测试阶段：把要测试的群与 QQ 号加入「沙箱配置」，机器人即可在沙箱群里收发消息。</li>
        </ol>

        <H2 n="2">服务器环境要求</H2>
        <ul className="space-y-1.5 text-ink-soft">
          <li>· Linux 服务器（Ubuntu 22.04 / Debian 12 / CentOS 7+ 均可），1 核 1G 起步</li>
          <li>· Node.js 20 或更高版本</li>
          <li>· PostgreSQL 14 或更高版本</li>
          <li>· 服务器需要能访问外网（与 QQ 开放平台通信）</li>
        </ul>
        <div className="mt-3">
          <Code>{`# Ubuntu / Debian 安装 Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs postgresql

# 创建数据库与用户
sudo -u postgres psql -c "CREATE USER qqbot WITH PASSWORD '换成强密码';"
sudo -u postgres psql -c "CREATE DATABASE qqbot_web OWNER qqbot;"`}</Code>
        </div>

        <H2 n="3">上传代码并安装依赖</H2>
        <Code>{`# 把项目放到服务器，例如 /opt/qqbot-web
cd /opt/qqbot-web
npm ci        # 或 npm install

# 配置环境变量
cat > .env <<'EOF'
DATABASE_URL=postgresql://qqbot:换成强密码@127.0.0.1:5432/qqbot_web
DATA_DIR=/opt/qqbot-web/data
LOG_LEVEL=info
MAX_UPLOAD_MB=200
EOF

# 初始化数据库表结构
npx drizzle-kit push

# 构建生产版本
npm run build`}</Code>
        <p className="text-sm text-ink-soft mt-2">
          说明：<code className="bg-line-soft px-1.5 py-0.5 rounded text-[13px]">DATA_DIR</code> 存放媒体缓存、网关会话与密钥文件，建议放在持久化磁盘上；
          <code className="bg-line-soft px-1.5 py-0.5 rounded text-[13px]">MAX_UPLOAD_MB</code> 是浏览器上传单文件上限。
        </p>

        <H2 n="4">常驻运行（关键：消息 7×24 接收）</H2>
        <p className="text-ink-soft mb-3">用 systemd 把服务注册成系统服务，开机自启、崩溃自动拉起：</p>
        <Code>{`sudo tee /etc/systemd/system/qqbot-web.service <<'EOF'
[Unit]
Description=QQ Bot Web Console
After=network.target postgresql.service

[Service]
WorkingDirectory=/opt/qqbot-web
ExecStart=/usr/bin/npm run start
Restart=always
RestartSec=5
Environment=NODE_ENV=production
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now qqbot-web
sudo systemctl status qqbot-web    # 查看运行状态
journalctl -u qqbot-web -f         # 实时查看日志`}</Code>
        <p className="text-sm text-ink-soft mt-3">
          也可以用 pm2：<code className="bg-line-soft px-1.5 py-0.5 rounded text-[13px]">pm2 start npm --name qqbot-web -- start</code> 然后
          <code className="bg-line-soft px-1.5 py-0.5 rounded text-[13px]">pm2 save && pm2 startup</code>。
        </p>

        <H2 n="5">（推荐）Nginx 反向代理 + HTTPS</H2>
        <Code>{`sudo apt install -y nginx certbot python3-certbot-nginx

# /etc/nginx/sites-available/qqbot
server {
    server_name bot.example.com;
    client_max_body_size 220m;     # 与 MAX_UPLOAD_MB 对应

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_buffering off;         # SSE 实时推送必须关闭缓冲
        proxy_read_timeout 3600s;
    }
}

sudo ln -s /etc/nginx/sites-available/qqbot /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d bot.example.com   # 免费 HTTPS 证书`}</Code>

        <H2 n="6">开始使用</H2>
        <ol className="list-decimal pl-5 space-y-1.5 text-ink-soft">
          <li>浏览器打开网站，先「注册」一个账号（数据只存在你自己的服务器上）。</li>
          <li>进入「设置」，填入 AppID / AppSecret，点击「连接机器人」。</li>
          <li>
            确认 <b className="text-ink">常驻接收开关处于开启状态</b> —— 此后无论你是否开着浏览器，消息都会持续入库。
          </li>
          <li>在群里 @机器人 或私聊机器人，消息会实时出现在列表里；也可以点「同步」手动拉取历史。</li>
        </ol>

        <H2 n="7">常见问题</H2>
        <div className="space-y-4">
          <Faq q="群名 / 好友名显示不对？">
            本版本已修复：群名通过官方「获取群信息」接口解析并缓存，群成员昵称通过「获取群成员」接口解析，私聊可通过会话标题旁的「笔」图标自定义备注名。所有解析结果持久化在数据库，重启后依然生效。
          </Faq>
          <Faq q="关掉浏览器再打开，之前的消息还在吗？">
            在。只要「常驻接收」开关是开的，服务器会持续接收并入库；重新打开浏览器会先读取数据库中的全部历史记录，再自动同步一次补齐空档。
          </Faq>
          <Faq q="两部手机登录不同账号会串号吗？">
            不会。每个账号有独立的会话 Cookie 与独立的数据空间（含机器人连接），互不可见；同一账号在多个设备登录看到的是同一份数据。
          </Faq>
          <Faq q="完全连接不上机器人，一直显示「连接中」？">
            按顺序排查：① 到 QQ 开放平台（q.qq.com）确认机器人已完成「发布 / 上线」，新机器人默认处于沙箱模式、未上线时网关会直接拒绝连接；② 确认 AppID / AppSecret 复制正确（无多余空格）；③ 在机器人「场景能力」中开通「群聊」与「私聊」能力；④ 若用沙箱测试，把测试群和测试成员加入「沙箱配置」。也可以在设置页点「诊断」按钮，一键检测网络连通性与凭证是否有效。
          </Faq>
          <Faq q="为什么有时候收不到群消息？">
            官方平台对机器人有权限与频控：请确认已开通「群聊消息」能力，机器人在沙箱/正式环境中与测试群匹配。本应用会在每次进入时自动同步一次，也可手动点「同步」补齐。
          </Faq>
          <Faq q="发送失败提示超频？">
            官方平台对主动消息有频控（群聊尤其严格）。引用回复对方刚发的消息走「被动回复」通道，基本不受频控限制，建议优先使用回复功能。
          </Faq>
        </div>

        <div className="mt-12 rounded-2xl bg-brand-soft border border-brand/20 p-5 flex gap-3 items-start">
          <span className="h-9 w-9 rounded-xl bg-brand text-white grid place-items-center shrink-0">
            <IconBolt size={18} />
          </span>
          <div>
            <div className="font-display font-bold">现在就试试</div>
            <p className="text-sm text-ink-soft mt-1">
              部署完成后回到 <Link href="/" className="text-brand font-semibold hover:underline">工作台</Link>
              ，注册账号并连接你的机器人即可。
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

function Tip({ text }: { text: string }) {
  return (
    <span className="flex items-center gap-1.5 text-sm">
      <IconCheck size={14} className="text-brand shrink-0" /> {text}
    </span>
  );
}

function Faq({ q, children }: { q: string; children: React.ReactNode }) {
  return (
    <div className="bg-card border border-line-soft rounded-xl p-4">
      <div className="font-semibold mb-1.5">{q}</div>
      <div className="text-sm text-ink-soft leading-relaxed">{children}</div>
    </div>
  );
}
