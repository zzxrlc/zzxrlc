import { getSessionUser } from "@/lib/auth";
import { statusPayload } from "@/server/botManager";
import { listConversations, listFriendEvents, listGroupRobotEvents, listJoinRequests } from "@/server/repo";
import AuthScreen from "@/components/AuthScreen";
import ChatApp from "@/components/ChatApp";
import type { Conversation, RequestsData } from "@/lib/api";

export const dynamic = "force-dynamic";

export default async function Home({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const sp = await searchParams;
  // 登录态三级回退：Cookie → Authorization 头 → ?token=（iframe 等屏蔽 Cookie 的环境）
  const user = await getSessionUser(sp.token);
  if (!user) return <AuthScreen />;

  const [status, conversations, friends, groupEvents, joinRequests] = await Promise.all([
    statusPayload(user.id).catch(() => null),
    listConversations(user.id).catch(() => []),
    listFriendEvents(user.id).catch(() => []),
    listGroupRobotEvents(user.id).catch(() => []),
    listJoinRequests(user.id).catch(() => []),
  ]);

  const requests: RequestsData = {
    friends,
    groupEvents: groupEvents as RequestsData["groupEvents"],
    joinRequests: joinRequests as RequestsData["joinRequests"],
    pendingCount: joinRequests.filter((r) => r.status === "pending").length,
  };

  return (
    <ChatApp
      username={user.username}
      authToken={sp.token ?? null}
      initialStatus={status}
      initialConversations={conversations as unknown as Conversation[]}
      initialRequests={requests}
    />
  );
}
