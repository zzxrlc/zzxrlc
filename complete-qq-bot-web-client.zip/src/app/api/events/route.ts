import { getSessionUserFromRequest } from "@/lib/auth";
import { bus, safeJson } from "@/lib/bus";
import { ensureBoot, statusPayload } from "@/server/botManager";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * SSE 实时推送：按用户过滤，浏览器里消息即发即显，无需刷新。
 * EventSource 断线会自动重连。
 */
export async function GET(req: Request) {
  const user = await getSessionUserFromRequest(req);
  if (!user) {
    return Response.json({ success: false, error: { message: "未登录" } }, { status: 401 });
  }
  ensureBoot();
  const userId = user.id;

  const encoder = new TextEncoder();
  let controller: ReadableStreamDefaultController<Uint8Array>;

  const stream = new ReadableStream<Uint8Array>({
    start(c) {
      controller = c;
      const send = (type: string, data: unknown) => {
        try {
          controller.enqueue(encoder.encode(`event: ${type}\ndata: ${safeJson(data)}\n\n`));
        } catch {
          /* client gone */
        }
      };

      const unsubscribe = bus.subscribe((event) => {
        if (event.userId !== userId) return; // 多账号隔离：只推自己的事件
        send(event.type, event.data);
      });

      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(`: ping ${Date.now()}\n\n`));
        } catch {
          /* ignore */
        }
      }, 20000);

      const cleanup = () => {
        clearInterval(heartbeat);
        unsubscribe();
        try {
          controller.close();
        } catch {
          /* ignore */
        }
      };
      req.signal.addEventListener("abort", cleanup, { once: true });

      // 初始快照：客户端不会处于空白状态。
      void statusPayload(userId).then((s) => send("status", s));
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
