import { recallMessage, resendFailed } from "@/server/botManager";
import { appError } from "@/lib/errors";
import { fail, ok, readJson, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** 消息操作：{ op: "recall" } 撤回；{ op: "resend" } 重发。 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    const { op } = await readJson<{ op?: string }>(req);
    if (op === "recall") {
      await recallMessage(user.id, id);
      return ok({ done: true });
    }
    if (op === "resend") {
      const message = await resendFailed(user.id, id);
      return ok({ message });
    }
    throw appError("INVALID_REQUEST", "未知操作", "");
  } catch (e) {
    return fail(e);
  }
}
