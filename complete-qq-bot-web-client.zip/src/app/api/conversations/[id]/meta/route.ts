import { markConversationRead, renameConversation } from "@/server/botManager";
import { appError } from "@/lib/errors";
import { fail, ok, readJson, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** 会话操作：{ action: "read" } 清除未读；{ action: "rename", remark } 设置备注名。 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    const body = await readJson<{ action?: string; remark?: string }>(req);
    if (body.action === "read") {
      await markConversationRead(user.id, id);
      return ok({ done: true });
    }
    if (body.action === "rename") {
      if (typeof body.remark !== "string" || body.remark.length > 40) {
        throw appError("INVALID_REQUEST", "备注名需在 40 字以内", "");
      }
      const conversation = await renameConversation(user.id, id, body.remark);
      return ok({ conversation });
    }
    throw appError("INVALID_REQUEST", "未知操作", "");
  } catch (e) {
    return fail(e);
  }
}
