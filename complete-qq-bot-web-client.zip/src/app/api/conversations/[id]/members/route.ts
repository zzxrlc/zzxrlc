import { listGroupMembers } from "@/server/botManager";
import { getConversation } from "@/server/repo";
import { appError } from "@/lib/errors";
import { fail, ok, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** 群成员列表（仅群聊）。 */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    const conv = await getConversation(user.id, id);
    if (!conv) throw appError("INVALID_REQUEST", "会话不存在", "请刷新页面");
    if (conv.scope !== "group") throw appError("INVALID_REQUEST", "仅群聊支持查看成员", "");
    const members = await listGroupMembers(user.id, conv.peerId);
    return ok({ members });
  } catch (e) {
    return fail(e);
  }
}
