import { sendText } from "@/server/botManager";
import { listMessages, markRead, parseConversationId } from "@/server/repo";
import { appError } from "@/lib/errors";
import { fail, ok, readJson, requireUser } from "@/server/httpUtil";
import type { Scope } from "@/server/repo";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    const url = new URL(req.url);
    const limit = Math.min(Number(url.searchParams.get("limit") || 50) || 50, 200);
    const before = url.searchParams.get("before") ? Number(url.searchParams.get("before")) : undefined;
    const { rows, hasMore } = await listMessages(user.id, id, limit, before);
    // 打开会话即视为读到最新消息。
    await markRead(user.id, id);
    return ok({ messages: rows, hasMore });
  } catch (e) {
    return fail(e, 401);
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    const parsed = parseConversationId(id);
    if (!parsed) throw appError("INVALID_REQUEST", "会话 ID 无效", "请刷新页面");
    const { text, replyTo } = await readJson<{ text?: string; replyTo?: string | null }>(req);
    const message = await sendText(user.id, parsed.scope as Scope, parsed.peerId, { text: text ?? "", replyTo: replyTo ?? null });
    return ok({ message });
  } catch (e) {
    return fail(e);
  }
}
