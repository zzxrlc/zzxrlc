import { sendMedia } from "@/server/botManager";
import { saveUpload } from "@/server/media";
import { parseConversationId, type Scope } from "@/server/repo";
import { appError } from "@/lib/errors";
import { fail, ok, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

const KINDS = new Set(["image", "video", "voice", "file"]);

/** multipart/form-data 上传并发送：字段 kind（image|video|voice|file）、replyTo（可选）、file。 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    const parsed = parseConversationId(id);
    if (!parsed) throw appError("INVALID_REQUEST", "会话 ID 无效", "请刷新页面");

    const cloned = req.clone();
    let kind = "file";
    let replyTo: string | null = null;
    try {
      const fd = await cloned.formData();
      kind = String(fd.get("kind") || "file");
      replyTo = (fd.get("replyTo") as string | null) || null;
    } catch {
      /* formData 解析失败时继续走 busboy，只取文件 */
    }
    if (!KINDS.has(kind)) kind = "file";

    const saved = await saveUpload(req);
    const message = await sendMedia(user.id, parsed.scope as Scope, parsed.peerId, {
      localPath: saved.localPath,
      fileName: saved.fileName,
      contentType: saved.contentType,
      size: saved.size,
      kind: kind as "image" | "video" | "voice" | "file",
      replyTo,
    });
    return ok({ message });
  } catch (e) {
    return fail(e);
  }
}
