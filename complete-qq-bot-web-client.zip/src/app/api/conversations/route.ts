import { ensureBoot } from "@/server/botManager";
import { listConversations } from "@/server/repo";
import { fail, ok, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const user = await requireUser(req);
    ensureBoot();
    const conversations = await listConversations(user.id);
    return ok({ conversations });
  } catch (e) {
    return fail(e, 401);
  }
}
