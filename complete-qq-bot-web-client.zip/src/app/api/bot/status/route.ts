import { ensureBoot, statusPayload } from "@/server/botManager";
import { fail, ok, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const user = await requireUser(req);
    ensureBoot();
    return ok({ status: await statusPayload(user.id) });
  } catch (e) {
    return fail(e, 401);
  }
}
