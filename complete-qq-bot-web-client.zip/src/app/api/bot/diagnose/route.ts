import { diagnose } from "@/server/botManager";
import { fail, ok, readJson, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** 连接自检：网络连通性 + 凭证校验，帮助定位无法连接的原因。 */
export async function POST(req: Request) {
  try {
    const user = await requireUser(req);
    const body = await readJson<{ appId?: string; appSecret?: string }>(req).catch((): { appId?: string; appSecret?: string } => ({}));
    const result = await diagnose(user.id, body?.appId, body?.appSecret);
    return ok({ result });
  } catch (e) {
    return fail(e);
  }
}
