import { sync } from "@/server/botManager";
import { fail, ok, readJson, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** 手动/进入页面时同步：拉取群列表 + 补齐历史消息。 */
export async function POST(req: Request) {
  try {
    const user = await requireUser(req);
    const body = await readJson<{ force?: boolean }>(req).catch((): { force?: boolean } => ({}));
    const result = await sync(user.id, !!body?.force);
    return ok({ result });
  } catch (e) {
    return fail(e);
  }
}
