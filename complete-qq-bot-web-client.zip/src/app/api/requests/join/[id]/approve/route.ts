import { decideJoinRequest } from "@/server/botManager";
import { fail, ok, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    const request = await decideJoinRequest(user.id, id, "approve");
    return ok({ request });
  } catch (e) {
    return fail(e);
  }
}
