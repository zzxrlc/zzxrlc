import { decideJoinRequest } from "@/server/botManager";
import { fail, ok, readJson, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    const body = await readJson<{ reason?: string }>(req).catch((): { reason?: string } => ({}));
    const request = await decideJoinRequest(user.id, id, "decline", body?.reason);
    return ok({ request });
  } catch (e) {
    return fail(e);
  }
}
