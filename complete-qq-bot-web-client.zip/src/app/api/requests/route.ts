import { listFriendEvents, listGroupRobotEvents, listJoinRequests } from "@/server/repo";
import { fail, ok, requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const user = await requireUser(req);
    const [friends, groupEvents, joinRequests] = await Promise.all([
      listFriendEvents(user.id),
      listGroupRobotEvents(user.id),
      listJoinRequests(user.id),
    ]);
    const pendingCount = joinRequests.filter((r) => r.status === "pending").length;
    return ok({ friends, groupEvents, joinRequests, pendingCount });
  } catch (e) {
    return fail(e, 401);
  }
}
