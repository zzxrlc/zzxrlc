import fs from "node:fs";
import { Readable } from "node:stream";
import { cacheInbound, getCached, sanitizeName } from "@/server/media";
import { getMessage } from "@/server/repo";
import { appError } from "@/lib/errors";
import { requireUser } from "@/server/httpUtil";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

const INLINE = new Set([
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
  "video/mp4",
  "audio/mpeg",
  "audio/wav",
  "audio/mp4",
  "audio/ogg",
]);

/** 代理并缓存 QQ 入站附件，浏览器不直连 QQ CDN。 */
export async function GET(req: Request, { params }: { params: Promise<{ messageId: string; index: string }> }) {
  try {
    const user = await requireUser(req);
    const { messageId, index } = await params;
    const idx = Number(index);
    if (!Number.isInteger(idx) || idx < 0) throw appError("INVALID_REQUEST", "无效的附件序号", "");

    const message = await getMessage(user.id, messageId);
    if (!message) throw appError("INVALID_REQUEST", "消息不存在", "请刷新页面");
    const att = message.attachments[idx];
    if (!att) throw appError("INVALID_REQUEST", "附件不存在", "");

    let cached = getCached(message.id, idx);
    if (!cached) {
      if (!att.url) throw appError("INVALID_REQUEST", "该附件没有下载地址", "");
      let getToken: (() => Promise<string>) | undefined;
      try {
        const { requireBot } = await import("@/server/botManager");
        const bot = requireBot(user.id);
        getToken = () => bot.api.getToken();
      } catch {
        /* 机器人离线时尝试匿名下载 */
      }
      cached = await cacheInbound(message.id, idx, att.url, att.contentType, getToken);
    }

    const body = Readable.toWeb(fs.createReadStream(cached.path)) as ReadableStream<Uint8Array>;
    const filename = sanitizeName(att.filename || `file-${idx + 1}`);
    const disposition = INLINE.has(cached.contentType.split(";")[0]) ? "inline" : "attachment";
    return new Response(body, {
      headers: {
        "Content-Type": cached.contentType,
        "Content-Length": String(cached.size),
        "Content-Disposition": `${disposition}; filename*=UTF-8''${encodeURIComponent(filename)}`,
        "Cache-Control": "private, max-age=86400",
      },
    });
  } catch (e) {
    const { fail } = await import("@/server/httpUtil");
    return fail(e, 404);
  }
}
