/**
 * 服务器启动钩子：进程一起来就把所有开启了“常驻接收”的机器人重新连上，
 * 保证即使没人开着浏览器，消息也持续入库。
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  // 稍等片刻再启动，确保数据库连接池就绪。
  setTimeout(() => {
    import("@/server/botManager")
      .then((m) => m.bootAll())
      .catch(() => {});
  }, 1500);
  setTimeout(() => {
    import("@/server/botManager")
      .then((m) => m.bootAll())
      .catch(() => {});
  }, 15000);
}
