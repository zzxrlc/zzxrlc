"use client";

import { useState } from "react";
import { formatTime, type RequestsData } from "@/lib/api";
import { IconCheck, IconClose, Spinner } from "./ui";

interface Props {
  data: RequestsData;
  onApprove: (id: string) => Promise<void>;
  onDecline: (id: string, reason?: string) => Promise<void>;
}

export default function RequestsPanel({ data, onApprove, onDecline }: Props) {
  const [busyId, setBusyId] = useState<string | null>(null);

  async function act(id: string, op: "approve" | "decline") {
    setBusyId(id);
    try {
      if (op === "approve") await onApprove(id);
      else await onDecline(id);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="flex flex-col h-full min-h-0">
      <header className="px-4 pt-4 pb-2">
        <h1 className="font-display font-bold text-xl">通知</h1>
        <p className="text-xs text-ink-soft mt-1">入群申请、新好友与机器人入群动态</p>
      </header>
      <div className="flex-1 overflow-y-auto px-3 pb-6 space-y-5">
        {/* 入群申请 */}
        <section>
          <SectionTitle text="入群申请" />
          {data.joinRequests.length === 0 && <Empty text="暂无入群申请" />}
          {data.joinRequests.map((r) => (
            <div key={r.id} className="bg-card border border-line-soft rounded-xl p-3 mb-2">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-semibold text-[14px] truncate">{r.username || "未知用户"}</div>
                  <div className="text-xs text-ink-soft mt-0.5">
                    申请加入群 <span className="font-mono">{r.groupOpenid.slice(0, 10)}…</span>
                  </div>
                  {r.applySource && <div className="text-xs text-ink-soft mt-0.5">来源：{r.applySource}</div>}
                  {r.riskTips && <div className="text-xs text-accent mt-0.5">风险提示：{r.riskTips}</div>}
                  <div className="text-[11px] text-ink-faint mt-1">{formatTime(r.createdAt)}</div>
                </div>
                {r.status === "pending" ? (
                  <div className="flex gap-1.5 shrink-0">
                    <button
                      onClick={() => void act(r.id, "approve")}
                      disabled={busyId === r.id}
                      className="h-8 px-3 rounded-lg bg-brand text-white text-xs font-bold flex items-center gap-1 hover:bg-brand-deep disabled:opacity-50"
                    >
                      {busyId === r.id ? <Spinner size={12} /> : <IconCheck size={12} />}
                      同意
                    </button>
                    <button
                      onClick={() => void act(r.id, "decline")}
                      disabled={busyId === r.id}
                      className="h-8 px-3 rounded-lg bg-danger-soft text-danger text-xs font-bold flex items-center gap-1 hover:bg-danger hover:text-white disabled:opacity-50"
                    >
                      <IconClose size={12} />
                      拒绝
                    </button>
                  </div>
                ) : (
                  <span className={`shrink-0 text-xs font-bold px-2 py-1 rounded-lg ${r.status === "approved" ? "bg-brand-soft text-brand" : "bg-danger-soft text-danger"}`}>
                    {r.status === "approved" ? "已同意" : "已拒绝"}
                  </span>
                )}
              </div>
            </div>
          ))}
        </section>

        {/* 好友动态 */}
        <section>
          <SectionTitle text="新好友" />
          {data.friends.length === 0 && <Empty text="还没有好友添加记录" />}
          {data.friends.map((f) => (
            <div key={f.id} className="bg-card border border-line-soft rounded-xl p-3 mb-2 text-sm">
              <div className="font-semibold">用户添加了机器人好友</div>
              <div className="text-xs text-ink-soft mt-1 font-mono break-all">openid: {f.openid}</div>
              {f.scene && <div className="text-xs text-ink-soft mt-0.5">场景：{f.scene}</div>}
              <div className="text-[11px] text-ink-faint mt-1">{formatTime(f.createdAt)}</div>
            </div>
          ))}
        </section>

        {/* 机器人入群 */}
        <section>
          <SectionTitle text="机器人入群动态" />
          {data.groupEvents.length === 0 && <Empty text="暂无记录" />}
          {data.groupEvents.map((e) => (
            <div key={e.id} className="bg-card border border-line-soft rounded-xl p-3 mb-2 text-sm">
              <div className="font-semibold">{e.eventType === "add" ? "机器人被添加到了群聊" : "机器人被移出了群聊"}</div>
              <div className="text-xs text-ink-soft mt-1 font-mono break-all">群 openid: {e.groupOpenid}</div>
              <div className="text-[11px] text-ink-faint mt-1">{formatTime(e.createdAt)}</div>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}

function SectionTitle({ text }: { text: string }) {
  return <div className="px-1 pt-3 pb-2 text-[11px] font-bold text-ink-faint tracking-wider">{text}</div>;
}

function Empty({ text }: { text: string }) {
  return <div className="text-center text-xs text-ink-faint bg-line-soft/50 rounded-xl py-4">{text}</div>;
}
