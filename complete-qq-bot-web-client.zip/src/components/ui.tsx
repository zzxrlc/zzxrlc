import type { ReactNode, SVGProps } from "react";

/** 内联 SVG 图标库（stroke 风格，统一 24 视图）。 */

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function base({ size = 20, ...props }: IconProps, children: ReactNode) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      {...props}
    >
      {children}
    </svg>
  );
}

export const IconChat = (p: IconProps) =>
  base(p, <path d="M21 11.5a8.4 8.4 0 0 1-8.5 8.3 9 9 0 0 1-3.2-.6L4 20.5l1.4-3.9A8 8 0 0 1 4 11.5 8.4 8.4 0 0 1 12.5 3.2 8.4 8.4 0 0 1 21 11.5Z" />);
export const IconBell = (p: IconProps) =>
  base(p, <><path d="M18 8.5a6 6 0 1 0-12 0c0 6.6-2.5 7.7-2.5 7.7h17S18 15.1 18 8.5" /><path d="M10.3 20a2 2 0 0 0 3.4 0" /></>);
export const IconGear = (p: IconProps) =>
  base(p, <><circle cx="12" cy="12" r="3.2" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.9 2.9l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5v.2a2 2 0 1 1-4.1 0v-.1a1.7 1.7 0 0 0-1.1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.9-2.9l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H2.5a2 2 0 1 1 0-4.1h.1a1.7 1.7 0 0 0 1.6-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.9-2.9l.1.1a1.7 1.7 0 0 0 1.9.3h.1a1.7 1.7 0 0 0 1-1.5V2.4a2 2 0 1 1 4.1 0v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.9 2.9l-.1.1a1.7 1.7 0 0 0-.3 1.9v.1a1.7 1.7 0 0 0 1.5 1h.2a2 2 0 1 1 0 4.1h-.1a1.7 1.7 0 0 0-1.6 1Z" /></>);
export const IconSend = (p: IconProps) => base(p, <><path d="m21.5 2.5-10 10" /><path d="M21.5 2.5 15 21.5l-3.5-9-9-3.5Z" /></>);
export const IconClip = (p: IconProps) =>
  base(p, <path d="m21 11.6-8.8 8.8a6 6 0 0 1-8.5-8.5l8.8-8.8a4 4 0 0 1 5.7 5.7l-8.8 8.7a2 2 0 0 1-2.8-2.8l8.1-8.1" />);
export const IconImage = (p: IconProps) =>
  base(p, <><rect x="3" y="3" width="18" height="18" rx="2.5" /><circle cx="8.8" cy="8.8" r="1.7" /><path d="m21 15.5-4.8-4.8L5.5 21" /></>);
export const IconVideo = (p: IconProps) =>
  base(p, <><rect x="2.5" y="5.5" width="13" height="13" rx="2.5" /><path d="m15.5 10.8 6-3.5v9.4l-6-3.5" /></>);
export const IconMic = (p: IconProps) =>
  base(p, <><rect x="9" y="2.5" width="6" height="11.5" rx="3" /><path d="M5 11a7 7 0 0 0 14 0" /><path d="M12 18v3.5" /></>);
export const IconFile = (p: IconProps) =>
  base(p, <><path d="M14 2.5H6.5A2 2 0 0 0 4.5 4.5v15a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V8Z" /><path d="M14 2.5V8h5.5" /></>);
export const IconReply = (p: IconProps) => base(p, <><path d="m9.5 14-5-5 5-5" /><path d="M4.5 9h9.6a6 6 0 0 1 6 6v4" /></>);
export const IconClose = (p: IconProps) => base(p, <><path d="M6 6l12 12" /><path d="M18 6 6 18" /></>);
export const IconBack = (p: IconProps) => base(p, <><path d="m14.5 5.5-6.5 6.5 6.5 6.5" /></>);
export const IconRefresh = (p: IconProps) =>
  base(p, <><path d="M20.5 11a8.5 8.5 0 1 0-2.2 6.5" /><path d="M20.5 4.5V11H14" /></>);
export const IconPower = (p: IconProps) => base(p, <><path d="M12 2.5v9" /><path d="M17.7 6.2a8 8 0 1 1-11.4 0" /></>);
export const IconCheck = (p: IconProps) => base(p, <path d="m4.5 12.5 5 5 10-11" />);
export const IconAlert = (p: IconProps) =>
  base(p, <><path d="M12 3 1.8 20.2h20.4Z" /><path d="M12 9.5v5" /><path d="M12 17.6v.1" /></>);
export const IconLogout = (p: IconProps) =>
  base(p, <><path d="M9.5 21h-4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="m15.5 16.5 4.5-4.5-4.5-4.5" /><path d="M20 12H9.5" /></>);
export const IconBook = (p: IconProps) =>
  base(p, <><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V2.5H6.5A2.5 2.5 0 0 0 4 5Z" /><path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5" /></>);
export const IconUsers = (p: IconProps) =>
  base(p, <><path d="M16.5 21v-2a4 4 0 0 0-4-4h-6a4 4 0 0 0-4 4v2" /><circle cx="9.5" cy="7.5" r="3.7" /><path d="M21.5 21v-2a4 4 0 0 0-3-3.9" /><path d="M15.5 3.9a3.7 3.7 0 0 1 0 7.2" /></>);
export const IconDownload = (p: IconProps) => base(p, <><path d="M12 3v11" /><path d="m7.5 10 4.5 4.5L16.5 10" /><path d="M4 20.5h16" /></>);
export const IconEdit = (p: IconProps) =>
  base(p, <><path d="M12 20h9" /><path d="M16.7 3.8a2.2 2.2 0 0 1 3.2 3.2L7.5 19.4 3 20.5l1.1-4.5Z" /></>);
export const IconEye = (p: IconProps) =>
  base(p, <><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z" /><circle cx="12" cy="12" r="3" /></>);
export const IconBolt = (p: IconProps) => base(p, <path d="M13 2 4.5 13.5H11l-1 8.5L19.5 10.5H13Z" />);
export const IconServer = (p: IconProps) =>
  base(p, <><rect x="2.5" y="3" width="19" height="7.5" rx="2" /><rect x="2.5" y="13.5" width="19" height="7.5" rx="2" /><path d="M6.5 6.8h.01M6.5 17.3h.01" /></>);
export const IconCopy = (p: IconProps) =>
  base(p, <><rect x="9" y="9" width="12" height="12" rx="2" /><path d="M5.5 15H4.5a2 2 0 0 1-2-2V4.5a2 2 0 0 1 2-2H13a2 2 0 0 1 2 2v1" /></>);

/** 头像：有图用图，没图用首字色块。 */
const AVATAR_COLORS = ["#0e7566", "#b3652c", "#5b6abf", "#a84f69", "#3f7d4e", "#8a5fb0", "#37718f"];

export function colorHash(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

export function Avatar({
  name,
  url,
  scope,
  size = 40,
  className = "",
}: {
  name: string;
  url?: string | null;
  scope?: "c2c" | "group";
  size?: number;
  className?: string;
}) {
  const letter = (name || "?").trim().charAt(0).toUpperCase() || "?";
  const rounded = scope === "group" ? "rounded-xl" : "rounded-full";
  if (url) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={url}
        alt={name}
        width={size}
        height={size}
        className={`${rounded} shrink-0 object-cover bg-line-soft ${className}`}
        style={{ width: size, height: size }}
        onError={(e) => {
          (e.target as HTMLImageElement).style.display = "none";
          (e.target as HTMLImageElement).nextElementSibling?.classList.remove("hidden");
        }}
      />
    );
  }
  return (
    <span
      className={`${rounded} shrink-0 grid place-items-center font-display font-semibold text-white ${className}`}
      style={{ width: size, height: size, background: colorHash(name || "?"), fontSize: size * 0.42 }}
    >
      {letter}
    </span>
  );
}

/** 带占位回退的头像（远程图裂开时显示首字）。 */
export function SafeAvatar({ name, url, scope, size = 40 }: { name: string; url?: string | null; scope?: "c2c" | "group"; size?: number }) {
  return (
    <span className="relative inline-block shrink-0" style={{ width: size, height: size }}>
      {url ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={url}
          alt={name}
          width={size}
          height={size}
          loading="lazy"
          className={`${scope === "group" ? "rounded-xl" : "rounded-full"} absolute inset-0 object-cover bg-line-soft`}
          style={{ width: size, height: size }}
          onError={(e) => {
            (e.target as HTMLImageElement).style.visibility = "hidden";
          }}
        />
      ) : null}
      <span
        className={`${scope === "group" ? "rounded-xl" : "rounded-full"} absolute inset-0 grid place-items-center font-display font-semibold text-white`}
        style={{ background: colorHash(name || "?"), fontSize: size * 0.42, zIndex: -0 }}
      >
        {(name || "?").trim().charAt(0).toUpperCase() || "?"}
      </span>
    </span>
  );
}

/** 开关。 */
export function Toggle({ on, onChange, disabled, label }: { on: boolean; onChange: (v: boolean) => void; disabled?: boolean; label?: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!on)}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors duration-200 ${on ? "bg-brand" : "bg-line"} ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all duration-200 ${on ? "left-[22px]" : "left-0.5"}`}
      />
    </button>
  );
}

export function Spinner({ size = 16, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={`spin ${className}`} aria-hidden>
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.25" strokeWidth="3" />
      <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}
