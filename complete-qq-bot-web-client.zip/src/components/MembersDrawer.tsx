"use client";

import { useEffect, useState } from "react";
import { api, convTitle, errText, type Conversation } from "@/lib/api";
import { SafeAvatar, IconClose, IconUsers, Spinner } from "./ui";

interface Member {
  openid: string;
  name: string | null;
  avatar: string | null;
  joinTime: string | null;
}

export default function MembersDrawer({ conv, onClose }: { conv: Conversation; onClose: () => void }) {
  const [members, setMembers] = useState<Member[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const list = await api.groupMembers(conv.id);
        if (alive) setMembers(list);
      } catch (e) {
        if (alive) setError(errText(e));
      }
    })();
    return () => {
      alive = false;
    };
  }, [conv.id]);

  return (
    <div className="fixed inset-0 z-40 flex justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/35 fade-in" />
      <div className="relative w-full max-w-sm h-full bg-panel shadow-2xl flex flex-col fade-in" onClick={(e) => e.stopPropagation()}>
        <header className="h-14 shrink-0 flex items-center gap-2 px-4 border-b border-line">
          <IconUsers size={18} className="text-brand" />
          <h3 className="font-display font-bold flex-1 truncate">群成员 · {convTitle(conv)}</h3>
          <button onClick={onClose} className="h-9 w-9 grid place-items-center rounded-lg text-ink-soft hover:bg-line-soft">
            <IconClose size={18} />
          </button>
        </header>
        <div className="flex-1 overflow-y-auto p-3">
          {members === null && !error && (
            <div className="grid place-items-center py-16 text-ink-faint">
              <Spinner size={22} />
            </div>
          )}
          {error && (
            <div className="text-sm text-ink-soft text-center py-14 px-6 leading-relaxed">
              {error}
              <br />
              <span className="text-xs text-ink-faint">（群成员接口需要在开放平台为机器人开通相关权限）</span>
            </div>
          )}
          {members?.map((m) => (
            <div key={m.openid} className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-line-soft/60">
              <SafeAvatar name={m.name || m.openid.slice(-6)} url={m.avatar} size={38} />
              <div className="min-w-0">
                <div className="text-sm font-semibold truncate">{m.name || `成员 ${m.openid.slice(-6)}`}</div>
                <div className="text-[11px] text-ink-faint font-mono truncate">{m.openid}</div>
              </div>
            </div>
          ))}
          {members && members.length === 0 && <div className="text-center text-sm text-ink-faint py-14">暂无可见成员</div>}
        </div>
      </div>
    </div>
  );
}
