"use client";

import { useEffect, useState } from "react";
import { api, errText, getStoredToken, setAuthToken, setStoredToken } from "@/lib/api";
import { IconBolt, IconServer, Spinner } from "./ui";

export default function AuthScreen() {
  const [mode, setMode] = useState<"login" | "register">("login");

  // Cookie 被环境屏蔽时的兜底：本地已有有效 token 则直接进入应用。
  useEffect(() => {
    const token = getStoredToken();
    if (!token) return;
    let alive = true;
    api
      .status()
      .then(() => {
        if (alive) window.location.replace(`/?token=${encodeURIComponent(token)}`);
      })
      .catch(() => {
        if (alive) setStoredToken(null); // token 已失效，清掉展示登录表单
      });
    return () => {
      alive = false;
    };
  }, []);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit() {
    setError(null);
    if (mode === "register" && password !== password2) {
      setError("两次输入的密码不一致");
      return;
    }
    setBusy(true);
    try {
      const result = mode === "register" ? await api.register(username, password) : await api.login(username, password);
      setAuthToken(result.token ?? null);
      if (result.token) {
        // 关键：把 token 带在 URL 上跳转，完全不依赖 Cookie / localStorage 是否被环境屏蔽，
        // 确保登录后一定能进入应用。
        window.location.replace(`/?token=${encodeURIComponent(result.token)}`);
      } else {
        window.location.href = "/";
      }
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-dvh grid lg:grid-cols-[1.05fr_1fr]">
      {/* 品牌区 */}
      <div className="hidden lg:flex flex-col justify-between bg-night text-night-text p-12 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-40"
          style={{ background: "radial-gradient(600px 420px at 18% 8%, rgba(18,144,125,0.28), transparent 60%), radial-gradient(520px 380px at 85% 92%, rgba(217,131,36,0.14), transparent 60%)" }}
        />
        <div className="relative">
          <div className="flex items-center gap-3">
            <span className="h-10 w-10 rounded-xl bg-brand grid place-items-center text-white">
              <IconBolt size={22} />
            </span>
            <div>
              <div className="font-display font-bold text-white text-lg leading-tight">QQ 机器人工作台</div>
              <div className="text-xs text-night-text/70 font-display tracking-wide">BOT CONSOLE</div>
            </div>
          </div>
        </div>
        <div className="relative max-w-md">
          <h1 className="font-display text-4xl font-bold text-white leading-snug">
            把 QQ 机器人，
            <br />
            装进你的浏览器。
          </h1>
          <p className="mt-4 text-night-text/80 leading-relaxed">
            基于 QQ 开放平台官方接口，像原版 QQ 一样收发消息：私聊、群聊、图片、语音、视频、文件、引用回复，一个都不少。
          </p>
          <ul className="mt-8 space-y-4 text-sm">
            <li className="flex gap-3 items-start">
              <span className="mt-0.5 h-7 w-7 rounded-lg bg-night-3 grid place-items-center text-brand-bright">
                <IconServer size={15} />
              </span>
              <span>
                <b className="text-white">常驻服务器接收</b> —— 关掉浏览器消息也持续入库，随时打开随时补上，还能一键暂停。
              </span>
            </li>
            <li className="flex gap-3 items-start">
              <span className="mt-0.5 h-7 w-7 rounded-lg bg-night-3 grid place-items-center text-brand-bright">
                <IconBolt size={15} />
              </span>
              <span>
                <b className="text-white">实时无漏</b> —— 消息即收即显，群名、好友名自动解析，多设备多账号互不串号。
              </span>
            </li>
          </ul>
        </div>
        <div className="relative text-xs text-night-text/50">首次使用请先注册一个本地账号，数据只保存在你自己的服务器上。</div>
      </div>

      {/* 表单区 */}
      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <span className="h-10 w-10 rounded-xl bg-brand grid place-items-center text-white">
              <IconBolt size={22} />
            </span>
            <div>
              <div className="font-display font-bold text-lg leading-tight">QQ 机器人工作台</div>
              <div className="text-xs text-ink-soft">BOT CONSOLE</div>
            </div>
          </div>

          <div className="bg-card border border-line rounded-2xl shadow-[0_16px_40px_-24px_rgba(29,34,39,0.35)] p-6 sm:p-8 fade-in">
            <div className="flex p-1 rounded-xl bg-paper border border-line-soft mb-6">
              {(["login", "register"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    setMode(m);
                    setError(null);
                  }}
                  className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${
                    mode === m ? "bg-card shadow-sm text-ink" : "text-ink-soft hover:text-ink"
                  }`}
                >
                  {m === "login" ? "登录" : "注册"}
                </button>
              ))}
            </div>

            <h2 className="font-display text-xl font-bold mb-1">{mode === "login" ? "欢迎回来" : "创建账号"}</h2>
            <p className="text-sm text-ink-soft mb-6">{mode === "login" ? "登录后进入你的消息中心。" : "账号保存在本机数据库中，各设备互不干扰。"}</p>

            <label className="block text-sm font-medium mb-4">
              <span className="text-ink-soft">用户名</span>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="2-20 位中文 / 字母 / 数字"
                autoComplete="username"
                className="mt-1.5 w-full rounded-xl border border-line bg-panel px-3.5 py-2.5 text-[15px] focus:border-brand focus:ring-2 focus:ring-brand/15 transition-shadow"
                onKeyDown={(e) => e.key === "Enter" && submit()}
              />
            </label>
            <label className="block text-sm font-medium mb-4">
              <span className="text-ink-soft">密码</span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={mode === "register" ? "至少 6 位" : "输入密码"}
                autoComplete={mode === "register" ? "new-password" : "current-password"}
                className="mt-1.5 w-full rounded-xl border border-line bg-panel px-3.5 py-2.5 text-[15px] focus:border-brand focus:ring-2 focus:ring-brand/15 transition-shadow"
                onKeyDown={(e) => e.key === "Enter" && submit()}
              />
            </label>
            {mode === "register" && (
              <label className="block text-sm font-medium mb-4">
                <span className="text-ink-soft">确认密码</span>
                <input
                  type="password"
                  value={password2}
                  onChange={(e) => setPassword2(e.target.value)}
                  placeholder="再输入一次"
                  autoComplete="new-password"
                  className="mt-1.5 w-full rounded-xl border border-line bg-panel px-3.5 py-2.5 text-[15px] focus:border-brand focus:ring-2 focus:ring-brand/15 transition-shadow"
                  onKeyDown={(e) => e.key === "Enter" && submit()}
                />
              </label>
            )}

            {error && (
              <div className="mb-4 rounded-xl bg-danger-soft text-danger text-sm px-3.5 py-2.5 flex items-center gap-2">
                <IconShield size={15} className="shrink-0" />
                {error}
              </div>
            )}

            <button
              onClick={submit}
              disabled={busy || !username || !password}
              className="w-full rounded-xl bg-brand hover:bg-brand-deep disabled:opacity-50 text-white font-semibold py-2.5 transition-colors grid place-items-center"
            >
              {busy ? <Spinner size={18} /> : mode === "login" ? "登 录" : "注册并登录"}
            </button>
          </div>

          <p className="mt-6 text-center text-xs text-ink-faint">
            部署指引见 <a href="/guide" className="text-brand font-medium hover:underline">服务器部署教程</a>
          </p>
        </div>
      </div>
    </div>
  );
}

const IconShield = ({ size = 16, className = "" }: { size?: number; className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden>
    <path d="M12 2.5 4 5.5v6c0 5 3.5 8.5 8 10 4.5-1.5 8-5 8-10v-6Z" />
  </svg>
);
