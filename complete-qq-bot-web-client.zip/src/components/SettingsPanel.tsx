"use client";

import { useState } from "react";
import { api, formatTime, type BotStatus } from "@/lib/api";
import { IconAlert, IconBolt, IconCheck, IconLogout, IconPower, IconRefresh, SafeAvatar, Spinner, Toggle } from "./ui";

interface Props {
  status: BotStatus | null;
  username: string;
  onConnect: (appId?: string, appSecret?: string) => Promise<void>;
  onDisconnect: (clearCreds: boolean) => Promise<void>;
  onToggleReceive: (on: boolean) => Promise<void>;
  onSync: () => void;
  onLogout: () => void;
}

const STATUS_TEXT: Record<string, { text: string; cls: string }> = {
  connected: { text: "已连接", cls: "bg-brand-soft text-brand" },
  connecting: { text: "连接中…", cls: "bg-accent-soft text-accent" },
  error: { text: "连接异常", cls: "bg-danger-soft text-danger" },
  disconnected: { text: "未连接", cls: "bg-line-soft text-ink-soft" },
};

export default function SettingsPanel({ status, username, onConnect, onDisconnect, onToggleReceive, onSync, onLogout }: Props) {
  const [appId, setAppId] = useState("");
  const [secret, setSecret] = useState("");
  const [showSecret, setShowSecret] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [diag, setDiag] = useState<Awaited<ReturnType<typeof api.diagnose>> | null>(null);
  const [diagBusy, setDiagBusy] = useState(false);

  const st = status?.status ?? "disconnected";
  const badge = STATUS_TEXT[st] ?? STATUS_TEXT.disconnected;

  async function run(key: string, fn: () => Promise<void>) {
    setBusy(key);
    try {
      await fn();
    } finally {
      setBusy(null);
    }
  }

  async function runDiagnose() {
    setDiagBusy(true);
    setDiag(null);
    try {
      setDiag(await api.diagnose(appId.trim() || undefined, secret.trim() || undefined));
    } catch {
      setDiag(null);
    } finally {
      setDiagBusy(false);
    }
  }

  return (
    <div className="flex flex-col h-full min-h-0">
      <header className="px-4 pt-4 pb-2">
        <h1 className="font-display font-bold text-xl">设置</h1>
      </header>
      <div className="flex-1 overflow-y-auto px-3 pb-6 space-y-3">
        {/* 机器人状态卡片 */}
        <div className="bg-night text-night-text rounded-2xl p-4 mt-1">
          <div className="flex items-center gap-3">
            {status?.bot ? (
              <SafeAvatar name={status.bot.username} url={status.bot.avatar} size={44} />
            ) : (
              <span className="h-11 w-11 rounded-full bg-night-3 grid place-items-center text-night-text/60">
                <IconBolt size={20} />
              </span>
            )}
            <div className="min-w-0 flex-1">
              <div className="font-display font-bold text-white truncate">{status?.bot?.username || "未连接机器人"}</div>
              <div className="text-xs text-night-text/60 truncate">
                {status?.bot ? `机器人 ID：${status.bot.id}` : status?.appId ? `AppID：${status.appId}` : "填写 AppID / AppSecret 开始"}
              </div>
            </div>
            <span className={`shrink-0 text-xs font-bold px-2.5 py-1 rounded-lg ${badge.cls} ${st === "connecting" ? "pulse-dot" : ""}`}>{badge.text}</span>
          </div>
          {status?.lastError && (st === "error" || st === "connecting") && (
            <div className="mt-3 text-xs text-accent bg-accent/10 rounded-lg px-3 py-2 leading-relaxed">
              {status.lastError}
              {st === "connecting" && <span className="ml-1 opacity-70">（若长时间无响应，可点下方「诊断」）</span>}
            </div>
          )}
        </div>

        {/* 常驻接收 */}
        <div className="bg-card border border-line-soft rounded-2xl p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="font-semibold text-[15px]">常驻服务器接收</div>
              <div className="text-xs text-ink-soft mt-1 leading-relaxed">
                开启后，即使关掉浏览器，服务器也会持续接收消息并入库；下次打开可以看到期间的全部消息。关闭即停止接收。
              </div>
            </div>
            <Toggle
              on={status?.receive ?? false}
              disabled={busy === "receive" || !status?.hasCredentials}
              onChange={(v) => void run("receive", () => onToggleReceive(v))}
              label="常驻接收开关"
            />
          </div>
          <div className="mt-3 flex items-center justify-between gap-2 border-t border-line-soft pt-3">
            <div className="text-xs text-ink-soft">
              上次同步：{status?.lastSyncAt ? formatTime(status.lastSyncAt) : "从未"}
              {status?.syncing && <span className="ml-2 text-brand font-semibold">同步中…</span>}
            </div>
            <button
              onClick={() => {
                onSync();
              }}
              disabled={status?.syncing}
              className="h-8 px-3 rounded-lg bg-brand-soft text-brand text-xs font-bold flex items-center gap-1.5 hover:bg-brand/15 disabled:opacity-50"
            >
              {status?.syncing ? <Spinner size={12} /> : <IconRefresh size={12} />}
              立即同步
            </button>
          </div>
        </div>

        {/* 凭证 */}
        <div className="bg-card border border-line-soft rounded-2xl p-4">
          <div className="font-semibold text-[15px] mb-1">机器人凭证</div>
          <p className="text-xs text-ink-soft mb-3 leading-relaxed">
            在 <span className="font-semibold">QQ 开放平台 q.qq.com</span> 创建机器人后，于「开发 → 开发设置」获取 AppID 与 AppSecret。密钥加密存储，不会上传到任何第三方。
          </p>
          <input
            value={appId}
            onChange={(e) => setAppId(e.target.value)}
            placeholder="AppID（留空则使用已保存凭证）"
            className="w-full rounded-xl border border-line bg-panel px-3.5 py-2.5 text-sm mb-2 focus:border-brand focus:ring-2 focus:ring-brand/15"
          />
          <div className="relative mb-3">
            <input
              value={secret}
              onChange={(e) => setSecret(e.target.value)}
              type={showSecret ? "text" : "password"}
              placeholder="AppSecret（留空则使用已保存凭证）"
              className="w-full rounded-xl border border-line bg-panel px-3.5 py-2.5 pr-16 text-sm focus:border-brand focus:ring-2 focus:ring-brand/15"
            />
            <button onClick={() => setShowSecret((v) => !v)} className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-bold text-brand px-2 py-1">
              {showSecret ? "隐藏" : "显示"}
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => void run("connect", () => onConnect(appId.trim() || undefined, secret.trim() || undefined))}
              disabled={busy === "connect"}
              className="h-9 px-4 rounded-xl bg-brand text-white text-sm font-bold flex items-center gap-1.5 hover:bg-brand-deep disabled:opacity-50"
            >
              {busy === "connect" ? <Spinner size={13} /> : <IconBolt size={13} />}
              {status?.hasCredentials ? "重新连接" : "连接机器人"}
            </button>
            <button
              onClick={() => void runDiagnose()}
              disabled={diagBusy}
              className="h-9 px-4 rounded-xl bg-brand-soft text-brand text-sm font-bold flex items-center gap-1.5 hover:bg-brand/15 disabled:opacity-50"
            >
              {diagBusy ? <Spinner size={13} /> : <IconRefresh size={13} />}
              诊断
            </button>
            {status?.hasCredentials && (
              <>
                <button
                  onClick={() => void run("disconnect", () => onDisconnect(false))}
                  disabled={busy === "disconnect"}
                  className="h-9 px-4 rounded-xl bg-line-soft text-ink text-sm font-bold flex items-center gap-1.5 hover:bg-line disabled:opacity-50"
                >
                  <IconPower size={13} />
                  断开
                </button>
                <button
                  onClick={() => {
                    if (window.confirm("断开并清除已保存的凭证？")) void run("clear", () => onDisconnect(true));
                  }}
                  disabled={busy === "clear"}
                  className="h-9 px-4 rounded-xl bg-danger-soft text-danger text-sm font-bold hover:bg-danger hover:text-white disabled:opacity-50"
                >
                  清除凭证
                </button>
              </>
            )}
          </div>

          {diag && (
            <div className="mt-3 rounded-xl border border-line bg-panel p-3 text-xs space-y-2 fade-in">
              <div className="font-semibold text-ink">诊断结果</div>
              <div className="space-y-1">
                {diag.network.map((n) => (
                  <div key={n.host} className="flex items-center gap-2">
                    <span className={n.ok ? "text-brand" : "text-danger"}>
                      {n.ok ? <IconCheck size={13} /> : <IconAlert size={13} />}
                    </span>
                    <span className="text-ink-soft">网络 {n.host}</span>
                    <span className={n.ok ? "text-brand font-semibold" : "text-danger font-semibold"}>
                      {n.ok ? `${n.latencyMs}ms` : "无法连通"}
                    </span>
                  </div>
                ))}
                {diag.token.tested && (
                  <div className="flex items-start gap-2">
                    <span className={diag.token.ok ? "text-brand" : "text-danger"}>
                      {diag.token.ok ? <IconCheck size={13} /> : <IconAlert size={13} />}
                    </span>
                    <span className="text-ink-soft leading-relaxed">
                      凭证校验（{diag.token.appId}）：{diag.token.ok ? "通过" : diag.token.message || `错误码 ${diag.token.code}`}
                    </span>
                  </div>
                )}
              </div>
              {!diag.token.ok && (
                <div className="text-ink-faint leading-relaxed">
                  提示：凭证错误常见于 AppID/AppSecret 复制时带入了空格；若凭证正确但连接后无消息，请到开放平台完成机器人「发布/上线」并开通「群聊」能力、把测试群加入沙箱配置。
                </div>
              )}
            </div>
          )}
        </div>

        {/* 账号 */}
        <div className="bg-card border border-line-soft rounded-2xl p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="font-semibold text-[15px]">当前账号</div>
              <div className="text-xs text-ink-soft mt-0.5">
                {username} · 每个浏览器独立会话，多设备登录不同账号互不串号
              </div>
            </div>
            <button
              onClick={onLogout}
              className="h-9 px-3.5 rounded-xl bg-line-soft text-ink-soft text-sm font-bold flex items-center gap-1.5 hover:bg-danger-soft hover:text-danger"
            >
              <IconLogout size={14} />
              退出登录
            </button>
          </div>
        </div>

        <a href="/guide" className="block text-center text-xs text-brand font-semibold py-2 hover:underline">
          查看服务器部署教程 →
        </a>
      </div>
    </div>
  );
}
