"use client";

import { useMemo, useState } from "react";
import { convTitle, formatTime, type BotStatus, type Conversation } from "@/lib/api";
import { SafeAvatar, IconAlert, IconRefresh, Spinner } from "./ui";

interface Props {
  convs: Conversation[];
  activeId: string | null;
  status: BotStatus | null;
  onOpen: (conv: Conversation) => void;
  onGotoSettings: () => void;
  onSync: () => void;
}

export default function ConversationList({ convs, activeId, status, onOpen, onGotoSettings, onSync }: Props) {
  const [query, setQuery] = useState("");
  const [syncing, setSyncing] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return convs;
    return convs.filter((c) => convTitle(c).toLowerCase().includes(q) || c.lastPreview.toLowerCase().includes(q));
  }, [convs, query]);

  const groups = useMemo(() => filtered.filter((c) => c.scope === "group"), [filtered]);
  const friends = useMemo(() => filtered.filter((c) => c.scope === "c2c"), [filtered]);

  return (
    <div className="flex flex-col h-full min-h-0">
      <header className="px-4 pt-4 pb-2.5">
        <div className="flex items-center justify-between gap-2">
          <h1 className="font-display font-bold text-xl">消息</h1>
          <button
            onClick={async () => {
              setSyncing(true);
              try {
                onSync();
              } finally {
                setTimeout(() => setSyncing(false), 1200);
              }
            }}
            className="h-8 px-2.5 rounded-lg text-xs font-semibold text-brand bg-brand-soft hover:bg-brand/15 flex items-center gap-1.5 transition-colors"
            title="立即同步群列表与历史消息"
          >
            {syncing || status?.syncing ? <Spinner size={13} /> : <IconRefresh size={13} />}
            同步
          </button>
        </div>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="搜索会话…"
          className="mt-3 w-full rounded-xl border border-line bg-card px-3.5 py-2 text-sm placeholder:text-ink-faint focus:border-brand focus:ring-2 focus:ring-brand/15 transition-shadow"
        />
        {status && status.receive === false && (
          <button onClick={onGotoSettings} className="mt-2.5 w-full flex items-center gap-2 rounded-xl bg-accent-soft text-accent text-xs font-semibold px-3 py-2 text-left">
            <IconAlert size={14} className="shrink-0" />
            常驻接收已关闭，新消息不会入库 — 去开启
          </button>
        )}
        {status && status.status === "error" && (
          <button onClick={onGotoSettings} className="mt-2.5 w-full flex items-center gap-2 rounded-xl bg-danger-soft text-danger text-xs font-semibold px-3 py-2 text-left">
            <IconAlert size={14} className="shrink-0" />
            {status.lastError || "机器人连接异常"} — 查看设置
          </button>
        )}
      </header>

      <div className="flex-1 overflow-y-auto px-2 pb-4">
        {filtered.length === 0 && (
          <div className="text-center text-sm text-ink-soft mt-14 px-6 leading-relaxed">
            {convs.length === 0 ? (
              <>
                还没有会话。
                <br />
                请先在「设置」中连接机器人；
                <br />
                机器人收到消息或同步后会自动出现在这里。
              </>
            ) : (
              "没有匹配的会话"
            )}
          </div>
        )}

        {friends.length > 0 && <SectionLabel text="私聊" />}
        {friends.map((c) => (
          <ConvRow key={c.id} conv={c} active={c.id === activeId} onOpen={onOpen} />
        ))}

        {groups.length > 0 && <SectionLabel text="群聊" />}
        {groups.map((c) => (
          <ConvRow key={c.id} conv={c} active={c.id === activeId} onOpen={onOpen} />
        ))}
      </div>
    </div>
  );
}

function SectionLabel({ text }: { text: string }) {
  return <div className="px-3 pt-3 pb-1 text-[11px] font-bold text-ink-faint tracking-wider">{text}</div>;
}

function ConvRow({ conv, active, onOpen }: { conv: Conversation; active: boolean; onOpen: (c: Conversation) => void }) {
  const title = convTitle(conv);
  return (
    <button
      onClick={() => onOpen(conv)}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors ${
        active ? "bg-brand-soft" : "hover:bg-line-soft/60"
      }`}
    >
      <SafeAvatar name={title} url={conv.avatar} scope={conv.scope} size={44} />
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline justify-between gap-2">
          <span className={`truncate text-[15px] ${active ? "font-bold text-brand-deep" : "font-semibold"}`}>{title}</span>
          <span className="shrink-0 text-[11px] text-ink-faint">{conv.lastMessageAt ? formatTime(conv.lastMessageAt) : ""}</span>
        </div>
        <div className="flex items-center justify-between gap-2 mt-0.5">
          <span className="truncate text-[13px] text-ink-soft">{conv.lastPreview || (conv.scope === "group" ? "暂无消息，同步后可查看历史" : "开始和机器人对话吧")}</span>
          {!!conv.unread && conv.unread > 0 && (
            <span className="shrink-0 min-w-[18px] h-[18px] px-1 rounded-full bg-danger text-white text-[10px] font-bold grid place-items-center">
              {conv.unread > 99 ? "99+" : conv.unread}
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
