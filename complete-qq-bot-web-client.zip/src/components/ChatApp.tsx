"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  api,
  errText,
  eventsUrl,
  setAuthToken,
  uploadMedia,
  type BotStatus,
  type Conversation,
  type Message,
  type RequestsData,
} from "@/lib/api";
import ConversationList from "./ConversationList";
import ChatPane from "./ChatPane";
import RequestsPanel from "./RequestsPanel";
import SettingsPanel from "./SettingsPanel";
import MembersDrawer from "./MembersDrawer";
import Lightbox from "./Lightbox";
import { IconBell, IconBook, IconBolt, IconChat, IconGear } from "./ui";

export interface ChatAppProps {
  username: string;
  authToken?: string | null;
  initialStatus: BotStatus | null;
  initialConversations: Conversation[];
  initialRequests: RequestsData;
}

export type View = "chats" | "requests" | "settings";

interface ConvMessages {
  list: Message[];
  hasMore: boolean;
  loaded: boolean;
}

interface Toast {
  id: number;
  text: string;
  kind: "ok" | "err";
}

export default function ChatApp({ username, authToken, initialStatus, initialConversations, initialRequests }: ChatAppProps) {
  const [status, setStatus] = useState<BotStatus | null>(initialStatus);
  const [convs, setConvs] = useState<Conversation[]>(initialConversations);
  const [view, setView] = useState<View>("chats");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [msgStore, setMsgStore] = useState<Record<string, ConvMessages>>({});
  const [requests, setRequests] = useState<RequestsData>(initialRequests);
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [progress, setProgress] = useState<Record<string, number>>({});
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [showMembers, setShowMembers] = useState(false);
  const [esAlive, setEsAlive] = useState(false);

  const activeIdRef = useRef<string | null>(activeId);
  activeIdRef.current = activeId;
  const viewRef = useRef<View>(view);
  viewRef.current = view;
  const toastSeq = useRef(0);
  const readThrottle = useRef<Record<string, number>>({});

  const toast = useCallback((text: string, kind: "ok" | "err" = "err") => {
    const id = ++toastSeq.current;
    setToasts((t) => [...t.slice(-2), { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  }, []);

  // ── 会话列表维护 ──
  const upsertConv = useCallback((conv: Conversation) => {
    setConvs((list) => {
      const idx = list.findIndex((c) => c.id === conv.id);
      const next = idx === -1 ? [...list, conv] : list.map((c) => (c.id === conv.id ? conv : c));
      next.sort((a, b) => b.lastMessageAt - a.lastMessageAt);
      return next;
    });
  }, []);

  const upsertMessage = useCallback(
    (msg: Message, conv: Conversation | null) => {
      setMsgStore((store) => {
        const bucket = store[msg.conversationId];
        if (!bucket) {
          // 未打开过该会话：不缓存消息体，只更新列表。
          return store;
        }
        const exists = bucket.list.some((m) => m.id === msg.id);
        const list = exists ? bucket.list.map((m) => (m.id === msg.id ? msg : m)) : [...bucket.list, msg].sort((a, b) => a.seq - b.seq);
        return { ...store, [msg.conversationId]: { ...bucket, list } };
      });
      if (conv) upsertConv(conv);
      // 正在看这个会话 → 立即清未读。
      if (activeIdRef.current === msg.conversationId && msg.direction === "in") {
        const now = Date.now();
        if (now - (readThrottle.current[msg.conversationId] ?? 0) > 800) {
          readThrottle.current[msg.conversationId] = now;
          void api.markRead(msg.conversationId);
        }
        setConvs((list) => list.map((c) => (c.id === msg.conversationId ? { ...c, unread: 0 } : c)));
      }
    },
    [upsertConv],
  );

  // ── 认证 token 注入（内存优先，供 SSE / 上传 / 媒体等所有请求使用） ──
  useEffect(() => {
    let urlToken: string | null = null;
    if (typeof window !== "undefined") {
      urlToken = new URLSearchParams(window.location.search).get("token");
    }
    const effective = urlToken ?? authToken ?? null;
    if (effective) {
      const persisted = setAuthToken(effective);
      // localStorage 可用 → 安全清理地址栏 token（刷新会从 localStorage 恢复）；
      // 不可用（沙箱/隐私环境）→ 保留 token 在 URL，保证刷新也能登录。
      if (persisted && urlToken && typeof window !== "undefined") {
        const url = new URL(window.location.href);
        url.searchParams.delete("token");
        window.history.replaceState({}, "", `${url.pathname}${url.search}`);
      }
    }
  }, [authToken]);

  // ── SSE 实时通道 ──
  const sseOpenedOnce = useRef(false);
  useEffect(() => {
    const es = new EventSource(eventsUrl());
    es.onopen = () => {
      setEsAlive(true);
      if (sseOpenedOnce.current) {
        // 重连成功：补齐断线期间的会话与消息，保证 UI 层也不漏消息。
        void api.conversations().then(setConvs).catch(() => {});
        const aid = activeIdRef.current;
        if (aid) {
          void api
            .messages(aid, 80)
            .then(({ messages }) => {
              setMsgStore((store) => {
                const cur = store[aid];
                if (!cur) return store;
                const map = new Map(messages.map((m) => [m.id, m]));
                for (const m of cur.list) if (!map.has(m.id)) map.set(m.id, m);
                const list = [...map.values()].sort((a, b) => a.seq - b.seq);
                return { ...store, [aid]: { ...cur, list } };
              });
            })
            .catch(() => {});
        }
      }
      sseOpenedOnce.current = true;
    };
    es.onerror = () => setEsAlive(false);

    const parse = (ev: MessageEvent): unknown => {
      try {
        return JSON.parse(ev.data);
      } catch {
        return null;
      }
    };

    const onStatus = (ev: MessageEvent) => {
      const data = parse(ev) as BotStatus | null;
      if (data) setStatus(data);
    };
    const onMessage = (ev: MessageEvent) => {
      const data = parse(ev) as { message?: Message; conversation?: Conversation | null } | null;
      if (data?.message) upsertMessage(data.message, data.conversation ?? null);
    };
    const onConversation = (ev: MessageEvent) => {
      const data = parse(ev) as Conversation | null;
      if (data) upsertConv(data);
    };
    const onProgress = (ev: MessageEvent) => {
      const data = parse(ev) as { messageId?: string; uploaded?: number; total?: number } | null;
      if (data?.messageId && data.total) {
        setProgress((p) => ({ ...p, [data.messageId!]: Math.min(100, Math.round(((data.uploaded ?? 0) / data.total!) * 100)) }));
      }
    };
    const onRequestsChanged = () => {
      void api.requests().then(setRequests).catch(() => {});
    };
    const onSync = () => {
      void api.conversations().then(setConvs).catch(() => {});
    };

    es.addEventListener("status", onStatus);
    es.addEventListener("message", onMessage);
    es.addEventListener("conversation", onConversation);
    es.addEventListener("upload_progress", onProgress);
    es.addEventListener("friend_add", onRequestsChanged);
    es.addEventListener("group_robot_add", onRequestsChanged);
    es.addEventListener("group_robot_del", onRequestsChanged);
    es.addEventListener("join_request", onRequestsChanged);
    es.addEventListener("sync", onSync);

    return () => es.close();
  }, [upsertMessage, upsertConv]);

  // 启动时：补一次状态 + 静默同步（拉群列表、补离线消息）。
  useEffect(() => {
    if (!initialStatus) void api.status().then(setStatus).catch(() => {});
    void api.conversations().then(setConvs).catch(() => {});
    void api.syncNow(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── 打开会话 ──
  const openChat = useCallback(
    async (conv: Conversation) => {
      setActiveId(conv.id);
      setReplyTo(null);
      setView("chats");
      void api.markRead(conv.id);
      setConvs((list) => list.map((c) => (c.id === conv.id ? { ...c, unread: 0 } : c)));
      const cached = msgStoreRef.current[conv.id];
      if (!cached?.loaded) {
        try {
          const { messages, hasMore } = await api.messages(conv.id, 50);
          setMsgStore((store) => ({ ...store, [conv.id]: { list: messages, hasMore, loaded: true } }));
        } catch {
          setMsgStore((store) => ({ ...store, [conv.id]: { list: [], hasMore: false, loaded: true } }));
        }
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );
  const msgStoreRef = useRef(msgStore);
  msgStoreRef.current = msgStore;

  const loadOlder = useCallback(async (convId: string) => {
    const bucket = msgStoreRef.current[convId];
    if (!bucket || !bucket.hasMore || bucket.list.length === 0) return;
    const before = bucket.list[0].seq;
    try {
      const { messages, hasMore } = await api.messages(convId, 50, before);
      setMsgStore((store) => {
        const cur = store[convId];
        if (!cur) return store;
        const seen = new Set(cur.list.map((m) => m.id));
        return { ...store, [convId]: { ...cur, list: [...messages.filter((m) => !seen.has(m.id)), ...cur.list], hasMore } };
      });
    } catch {
      /* ignore */
    }
  }, []);

  // ── 发送 ──
  const activeConv = useMemo(() => convs.find((c) => c.id === activeId) ?? null, [convs, activeId]);

  const sendText = useCallback(
    async (text: string) => {
      if (!activeId) return;
      const rid = replyTo?.id ?? null;
      setReplyTo(null);
      try {
        const msg = await api.sendText(activeId, text, rid);
        upsertMessage(msg, null);
      } catch (e) {
        toast(errText(e));
      }
    },
    [activeId, replyTo, toast, upsertMessage],
  );

  const sendFile = useCallback(
    async (file: File, kind: "image" | "video" | "voice" | "file") => {
      if (!activeId) return;
      const rid = replyTo?.id ?? null;
      setReplyTo(null);
      try {
        const msg = await uploadMedia(activeId, file, kind, rid, (u, t) => {
          setProgress((p) => ({ ...p, [`local:${file.name}`]: Math.min(99, Math.round((u / t) * 100)) }));
        });
        upsertMessage(msg, null);
      } catch (e) {
        toast(errText(e));
      } finally {
        setProgress((p) => {
          const n = { ...p };
          delete n[`local:${file.name}`];
          return n;
        });
      }
    },
    [activeId, replyTo, toast, upsertMessage],
  );

  // ── 机器人操作 ──
  const doConnect = useCallback(
    async (appId?: string, appSecret?: string) => {
      try {
        const s = await api.connect(appId, appSecret);
        setStatus(s);
        toast("机器人已连接", "ok");
      } catch (e) {
        toast(errText(e));
        throw e;
      }
    },
    [toast],
  );

  const doDisconnect = useCallback(
    async (clearCreds: boolean) => {
      try {
        const s = await api.disconnect(clearCreds);
        setStatus(s);
        toast(clearCreds ? "已断开并清除凭证" : "已断开连接", "ok");
      } catch (e) {
        toast(errText(e));
      }
    },
    [toast],
  );

  const doToggleReceive = useCallback(
    async (on: boolean) => {
      try {
        const s = await api.setReceive(on);
        setStatus(s);
        toast(on ? "常驻接收已开启，服务器将持续接收消息" : "常驻接收已关闭，服务器暂停接收新消息", "ok");
      } catch (e) {
        toast(errText(e));
      }
    },
    [toast],
  );

  const doSync = useCallback(
    async (force: boolean) => {
      try {
        await api.syncNow(force);
        const list = await api.conversations();
        setConvs(list);
        toast("同步完成：群列表与历史消息已更新", "ok");
      } catch (e) {
        toast(errText(e));
      }
    },
    [toast],
  );

  const doLogout = useCallback(async () => {
    await api.logout();
    window.location.href = "/";
  }, []);

  // ── 请求面板操作 ──
  const approveJoin = useCallback(
    async (id: string) => {
      try {
        await api.approveJoin(id);
        setRequests(await api.requests());
        toast("已通过入群申请", "ok");
      } catch (e) {
        toast(errText(e));
      }
    },
    [toast],
  );
  const declineJoin = useCallback(
    async (id: string, reason?: string) => {
      try {
        await api.declineJoin(id, reason);
        setRequests(await api.requests());
        toast("已拒绝入群申请", "ok");
      } catch (e) {
        toast(errText(e));
      }
    },
    [toast],
  );

  const msgOp = useCallback(
    async (msg: Message, op: "recall" | "resend") => {
      try {
        await api.messageOp(msg.id, op);
        toast(op === "recall" ? "已撤回" : "重发成功", "ok");
      } catch (e) {
        toast(errText(e));
      }
    },
    [toast],
  );

  const renameConv = useCallback(
    async (convId: string, remark: string) => {
      try {
        const conv = await api.rename(convId, remark);
        upsertConv(conv);
        toast("备注已保存", "ok");
      } catch (e) {
        toast(errText(e));
      }
    },
    [toast, upsertConv],
  );

  const totalUnread = useMemo(() => convs.reduce((s, c) => s + (c.unread || 0), 0), [convs]);
  const pendingReqs = requests.pendingCount || 0;

  const navItems: Array<{ key: View; label: string; icon: (p: { size?: number }) => React.ReactNode; badge?: number }> = [
    { key: "chats", label: "消息", icon: (p) => <IconChat {...p} />, badge: totalUnread },
    { key: "requests", label: "通知", icon: (p) => <IconBell {...p} />, badge: pendingReqs },
    { key: "settings", label: "设置", icon: (p) => <IconGear {...p} /> },
  ];

  return (
    <div className="h-dvh flex overflow-hidden">
      {/* 侧导航 */}
      <nav className="w-[68px] shrink-0 bg-night flex flex-col items-center py-4 gap-1 z-20">
        <div className="mb-4 h-10 w-10 rounded-xl bg-brand grid place-items-center text-white" title="QQ 机器人工作台">
          <IconBolt size={20} />
        </div>
        {navItems.map((item) => (
          <button
            key={item.key}
            onClick={() => setView(item.key)}
            className={`relative w-12 py-2.5 rounded-xl grid place-items-center gap-0.5 text-[10px] transition-colors ${
              view === item.key ? "bg-night-3 text-white" : "text-night-text/60 hover:text-white hover:bg-night-2"
            }`}
          >
            {item.icon({ size: 20 })}
            <span>{item.label}</span>
            {!!item.badge && item.badge > 0 && (
              <span className="absolute top-1 right-1.5 min-w-[16px] h-4 px-1 rounded-full bg-accent text-white text-[9px] font-bold grid place-items-center">
                {item.badge > 99 ? "99+" : item.badge}
              </span>
            )}
          </button>
        ))}
        <div className="mt-auto flex flex-col items-center gap-2">
          <a href="/guide" className="w-12 py-2 rounded-xl grid place-items-center text-night-text/60 hover:text-white hover:bg-night-2" title="部署教程">
            <IconBook size={20} />
          </a>
          <span
            className={`h-2 w-2 rounded-full ${esAlive ? "bg-brand-bright" : "bg-accent"} ${esAlive ? "" : "pulse-dot"}`}
            title={esAlive ? "实时通道正常" : "实时通道连接中…"}
          />
        </div>
      </nav>

      {/* 中间列表面板 */}
      <aside className={`${activeId ? "hidden md:flex" : "flex"} w-full md:w-[340px] shrink-0 flex-col border-r border-line bg-panel z-10`}>
        {view === "chats" && (
          <ConversationList convs={convs} activeId={activeId} status={status} onOpen={openChat} onGotoSettings={() => setView("settings")} onSync={() => doSync(true)} />
        )}
        {view === "requests" && <RequestsPanel data={requests} onApprove={approveJoin} onDecline={declineJoin} />}
        {view === "settings" && (
          <SettingsPanel
            status={status}
            username={username}
            onConnect={doConnect}
            onDisconnect={doDisconnect}
            onToggleReceive={doToggleReceive}
            onSync={() => doSync(true)}
            onLogout={doLogout}
          />
        )}
      </aside>

      {/* 聊天主区 */}
      <main className={`${activeId ? "flex" : "hidden md:flex"} flex-1 min-w-0 flex-col chat-bg`}>
        {activeConv ? (
          <ChatPane
            conv={activeConv}
            bucket={msgStore[activeConv.id]}
            progress={progress}
            replyTo={replyTo}
            botName={status?.bot?.username ?? null}
            onBack={() => setActiveId(null)}
            onLoadOlder={() => loadOlder(activeConv.id)}
            onReply={(m) => setReplyTo(m)}
            onCancelReply={() => setReplyTo(null)}
            onSend={sendText}
            onUpload={sendFile}
            onOp={msgOp}
            onImage={setLightbox}
            onOpenMembers={activeConv.scope === "group" ? () => setShowMembers(true) : undefined}
            onRename={(remark) => renameConv(activeConv.id, remark)}
          />
        ) : (
          <div className="flex-1 grid place-items-center">
            <div className="text-center fade-in">
              <div className="mx-auto h-16 w-16 rounded-2xl bg-brand-soft grid place-items-center text-brand mb-4">
                <IconChat size={30} />
              </div>
              <p className="font-display font-semibold text-lg">选择一个会话开始聊天</p>
              <p className="text-sm text-ink-soft mt-1.5 max-w-xs">
                消息由服务器常驻接收，即使关掉浏览器也不会丢失；再次打开即可看到全部新消息。
              </p>
            </div>
          </div>
        )}
      </main>

      {/* 弹层 */}
      {showMembers && activeConv?.scope === "group" && <MembersDrawer conv={activeConv} onClose={() => setShowMembers(false)} />}
      {lightbox && <Lightbox src={lightbox} onClose={() => setLightbox(null)} />}

      {/* Toast */}
      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 space-y-2 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`pop-in px-4 py-2.5 rounded-xl text-sm font-medium shadow-lg border max-w-[86vw] ${
              t.kind === "ok" ? "bg-night text-white border-night-line" : "bg-danger text-white border-danger"
            }`}
          >
            {t.text}
          </div>
        ))}
      </div>
    </div>
  );
}
