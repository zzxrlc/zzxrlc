"use client";

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { convTitle, formatDay, formatTime, type Conversation, type Message } from "@/lib/api";
import MessageBubble from "./MessageBubble";
import Composer from "./Composer";
import { SafeAvatar, IconBack, IconClose, IconEdit, IconUsers, Spinner } from "./ui";

export interface MessageBucket {
  list: Message[];
  hasMore: boolean;
  loaded: boolean;
}

interface Props {
  conv: Conversation;
  bucket?: MessageBucket;
  progress: Record<string, number>;
  replyTo: Message | null;
  botName: string | null;
  onBack: () => void;
  onLoadOlder: () => Promise<void> | void;
  onReply: (m: Message) => void;
  onCancelReply: () => void;
  onSend: (text: string) => Promise<void>;
  onUpload: (file: File, kind: "image" | "video" | "voice" | "file") => Promise<void>;
  onOp: (msg: Message, op: "recall" | "resend") => void;
  onImage: (src: string) => void;
  onOpenMembers?: () => void;
  onRename: (remark: string) => void;
}

interface RenderItem {
  key: string;
  kind: "divider" | "msg";
  label?: string;
  msg?: Message;
}

export default function ChatPane({
  conv,
  bucket,
  progress,
  replyTo,
  botName,
  onBack,
  onLoadOlder,
  onReply,
  onCancelReply,
  onSend,
  onUpload,
  onOp,
  onImage,
  onOpenMembers,
  onRename,
}: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const stickBottom = useRef(true);
  const prevConvId = useRef<string>("");
  const prevCount = useRef(0);
  const prevHeight = useRef(0);
  const loadingOlder = useRef(false);
  const [editing, setEditing] = useState(false);
  const [draftTitle, setDraftTitle] = useState("");

  const messages = bucket?.list ?? [];
  const loaded = bucket?.loaded ?? false;
  const hasMore = bucket?.hasMore ?? false;

  const items = useMemo<RenderItem[]>(() => {
    const out: RenderItem[] = [];
    let lastTs = 0;
    for (const m of messages) {
      if (m.createdAt - lastTs > 10 * 60 * 1000) {
        out.push({ key: `d-${m.id}`, kind: "divider", label: `${formatDay(m.createdAt)} ${formatTime(m.createdAt)}` });
      }
      lastTs = m.createdAt;
      out.push({ key: m.id, kind: "msg", msg: m });
    }
    return out;
  }, [messages]);

  // 新消息自动滚动到底部（用户往上翻时不打扰）。
  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (prevConvId.current !== conv.id) {
      stickBottom.current = true;
      el.scrollTop = el.scrollHeight;
      prevConvId.current = conv.id;
      prevCount.current = messages.length;
      return;
    }
    if (messages.length > prevCount.current && stickBottom.current) {
      el.scrollTop = el.scrollHeight;
    }
    prevCount.current = messages.length;
  }, [messages.length, conv.id]);

  // 加载旧消息后保持视口位置。
  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (el && prevHeight.current > 0 && loadingOlder.current) {
      el.scrollTop += el.scrollHeight - prevHeight.current;
      loadingOlder.current = false;
    }
  }, [messages.length]);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    stickBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 90;
    if (el.scrollTop < 60 && hasMore && loaded && !loadingOlder.current) {
      loadingOlder.current = true;
      prevHeight.current = el.scrollHeight;
      void onLoadOlder();
    }
  }, [hasMore, loaded, onLoadOlder]);

  const saveRename = () => {
    setEditing(false);
    onRename(draftTitle);
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* 头部 */}
      <header className="h-14 shrink-0 flex items-center gap-2 px-3 bg-panel/90 backdrop-blur border-b border-line">
        <button onClick={onBack} className="md:hidden h-9 w-9 grid place-items-center rounded-lg text-ink-soft hover:bg-line-soft">
          <IconBack size={20} />
        </button>
        <SafeAvatar name={convTitle(conv)} url={conv.avatar} scope={conv.scope} size={34} />
        <div className="flex-1 min-w-0">
          {editing ? (
            <div className="flex items-center gap-1.5">
              <input
                autoFocus
                value={draftTitle}
                onChange={(e) => setDraftTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") saveRename();
                  if (e.key === "Escape") setEditing(false);
                }}
                maxLength={40}
                placeholder={conv.scope === "c2c" ? "为好友设置备注名" : "为群聊设置备注名"}
                className="w-full max-w-[260px] rounded-lg border border-brand bg-card px-2.5 py-1 text-[15px] font-semibold"
              />
              <button onClick={saveRename} className="text-xs font-bold text-brand whitespace-nowrap">
                保存
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 min-w-0">
              <h2 className="font-display font-bold text-[16px] truncate">{convTitle(conv)}</h2>
              <span className={`shrink-0 text-[10px] font-bold px-1.5 py-0.5 rounded ${conv.scope === "group" ? "bg-brand-soft text-brand" : "bg-accent-soft text-accent"}`}>
                {conv.scope === "group" ? "群聊" : "私聊"}
              </span>
              <button
                onClick={() => {
                  setDraftTitle(conv.remark || "");
                  setEditing(true);
                }}
                className="shrink-0 text-ink-faint hover:text-brand"
                title="设置备注名（修复名称显示）"
              >
                <IconEdit size={14} />
              </button>
            </div>
          )}
        </div>
        {onOpenMembers && (
          <button onClick={onOpenMembers} className="h-9 px-3 rounded-lg text-sm font-semibold text-ink-soft hover:bg-line-soft flex items-center gap-1.5">
            <IconUsers size={17} />
            <span className="hidden sm:inline">成员</span>
          </button>
        )}
      </header>

      {/* 消息区 */}
      <div ref={scrollRef} onScroll={handleScroll} className="flex-1 min-h-0 overflow-y-auto py-3">
        {!loaded ? (
          <div className="h-full grid place-items-center text-ink-faint">
            <Spinner size={22} />
          </div>
        ) : (
          <>
            {hasMore && (
              <div className="text-center py-2">
                <button
                  onClick={() => {
                    loadingOlder.current = true;
                    prevHeight.current = scrollRef.current?.scrollHeight ?? 0;
                    void onLoadOlder();
                  }}
                  className="text-xs font-semibold text-brand bg-brand-soft hover:bg-brand/15 rounded-full px-3.5 py-1.5"
                >
                  ↑ 加载更早的消息
                </button>
              </div>
            )}
            {items.length === 0 && (
              <div className="text-center text-sm text-ink-soft mt-16 px-8 leading-relaxed">
                这里还没有本地消息记录。
                <br />
                {conv.scope === "group"
                  ? "群里有人发言后会实时显示；也可以点击上方「同步」从 QQ 服务器拉取历史消息。"
                  : "让好友给机器人发一条消息试试，或直接输入文字主动发送。"}
              </div>
            )}
            {items.map((item) =>
              item.kind === "divider" ? (
                <div key={item.key} className="text-center my-3">
                  <span className="text-[11px] text-ink-faint bg-line-soft/70 rounded-full px-3 py-1">{item.label}</span>
                </div>
              ) : (
                <MessageBubble
                  key={item.key}
                  msg={item.msg!}
                  isGroup={conv.scope === "group"}
                  botName={botName}
                  uploadPct={progress[item.msg!.id]}
                  onReply={onReply}
                  onRecall={(m) => onOp(m, "recall")}
                  onResend={(m) => onOp(m, "resend")}
                  onImage={onImage}
                />
              ),
            )}
          </>
        )}
      </div>

      {/* 回复条 + 输入区 */}
      {replyTo && (
        <div className="flex items-center gap-2 px-4 py-2 bg-panel border-t border-line-soft text-[13px] fade-in">
          <span className="text-brand font-semibold shrink-0">回复 {replyTo.senderName || "消息"}：</span>
          <span className="truncate flex-1 text-ink-soft">{replyTo.text || replyTo.reply?.preview || "[消息]"}</span>
          <button onClick={onCancelReply} className="shrink-0 text-ink-faint hover:text-danger">
            <IconClose size={15} />
          </button>
        </div>
      )}
      <Composer
        onSend={onSend}
        onUpload={onUpload}
        disabled={false}
        placeholder={conv.scope === "group" ? "发消息到群聊…" : "发消息给好友…（主动消息受平台频控）"}
      />
    </div>
  );
}
