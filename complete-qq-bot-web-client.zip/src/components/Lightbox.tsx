"use client";

import { useEffect } from "react";
import { IconClose } from "./ui";

export default function Lightbox({ src, onClose }: { src: string; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 grid place-items-center fade-in" onClick={onClose}>
      <button className="absolute top-4 right-4 h-10 w-10 grid place-items-center rounded-xl bg-white/10 text-white hover:bg-white/20" onClick={onClose}>
        <IconClose size={20} />
      </button>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt="预览" className="max-h-[92vh] max-w-[94vw] rounded-lg object-contain pop-in" onClick={(e) => e.stopPropagation()} />
    </div>
  );
}
