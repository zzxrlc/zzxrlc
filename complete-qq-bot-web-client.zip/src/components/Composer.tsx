"use client";

import { useRef, useState } from "react";
import { IconClip, IconFile, IconImage, IconMic, IconSend, IconVideo, Spinner } from "./ui";

interface Props {
  onSend: (text: string) => Promise<void>;
  onUpload: (file: File, kind: "image" | "video" | "voice" | "file") => Promise<void>;
  disabled?: boolean;
  placeholder?: string;
}

const ACCEPTS: Record<string, string> = {
  image: "image/*",
  video: "video/mp4,video/*",
  voice: "audio/*",
  file: "*/*",
};

export default function Composer({ onSend, onUpload, placeholder }: Props) {
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState<string | null>(null);
  const [showAttach, setShowAttach] = useState(false);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const kindRef = useRef<"image" | "video" | "voice" | "file">("file");

  const autoGrow = () => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 140)}px`;
  };

  const submit = async () => {
    const value = text.trim();
    if (!value || sending) return;
    setText("");
    requestAnimationFrame(autoGrow);
    setSending(true);
    try {
      await onSend(value);
    } finally {
      setSending(false);
    }
  };

  const pickFile = (kind: "image" | "video" | "voice" | "file") => {
    kindRef.current = kind;
    setShowAttach(false);
    if (fileRef.current) {
      fileRef.current.accept = ACCEPTS[kind];
      fileRef.current.value = "";
      fileRef.current.click();
    }
  };

  const onFileChosen = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(file.name);
    try {
      await onUpload(file, kindRef.current);
    } finally {
      setUploading(null);
    }
  };

  const attachOptions = [
    { kind: "image" as const, label: "图片", icon: <IconImage size={16} /> },
    { kind: "video" as const, label: "视频", icon: <IconVideo size={16} /> },
    { kind: "voice" as const, label: "语音", icon: <IconMic size={16} /> },
    { kind: "file" as const, label: "文件", icon: <IconFile size={16} /> },
  ];

  return (
    <div className="shrink-0 border-t border-line bg-panel px-3 py-2.5 relative">
      {showAttach && (
        <div className="absolute bottom-full left-3 mb-2 pop-in bg-card border border-line rounded-xl shadow-lg p-1.5 flex gap-1 z-30">
          {attachOptions.map((o) => (
            <button
              key={o.kind}
              onClick={() => pickFile(o.kind)}
              className="flex flex-col items-center gap-1 px-3 py-2 rounded-lg text-ink-soft hover:bg-brand-soft hover:text-brand transition-colors"
            >
              {o.icon}
              <span className="text-[11px] font-semibold">{o.label}</span>
            </button>
          ))}
        </div>
      )}

      <div className="flex items-end gap-2">
        <button
          onClick={() => setShowAttach((v) => !v)}
          className={`h-10 w-10 shrink-0 grid place-items-center rounded-xl transition-colors ${showAttach ? "bg-brand text-white" : "text-ink-soft hover:bg-line-soft"}`}
          title="发送图片 / 视频 / 语音 / 文件"
        >
          <IconClip size={19} />
        </button>

        <textarea
          ref={taRef}
          rows={1}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            autoGrow();
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault();
              void submit();
            }
          }}
          placeholder={uploading ? `正在上传 ${uploading}…` : placeholder}
          className="flex-1 resize-none rounded-xl border border-line bg-card px-3.5 py-2.5 text-[14.5px] leading-snug placeholder:text-ink-faint focus:border-brand focus:ring-2 focus:ring-brand/15 transition-shadow max-h-[140px]"
        />

        <button
          onClick={() => void submit()}
          disabled={!text.trim() || sending}
          className="h-10 w-10 shrink-0 grid place-items-center rounded-xl bg-brand text-white hover:bg-brand-deep disabled:opacity-40 disabled:bg-line disabled:text-ink-faint transition-colors"
          title="发送（Enter）"
        >
          {sending ? <Spinner size={16} /> : <IconSend size={17} />}
        </button>
      </div>

      {uploading && (
        <div className="mt-2 flex items-center gap-2 text-xs text-ink-soft">
          <Spinner size={12} className="text-brand" />
          正在上传并发送「{uploading}」…
        </div>
      )}

      <input ref={fileRef} type="file" className="hidden" onChange={(e) => void onFileChosen(e)} />
    </div>
  );
}
