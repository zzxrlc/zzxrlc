"use client";

import { api, formatBytes, type Message } from "@/lib/api";
import { SafeAvatar, IconCopy, IconDownload, IconReply, IconRefresh, IconClose, Spinner } from "./ui";

interface Props {
  msg: Message;
  isGroup: boolean;
  botName: string | null;
  uploadPct?: number;
  onReply: (m: Message) => void;
  onRecall: (m: Message) => void;
  onResend: (m: Message) => void;
  onImage: (src: string) => void;
}

function senderDisplay(msg: Message, botName: string | null): string {
  if (msg.direction === "out") return botName || "机器人";
  return msg.senderName || "QQ 用户";
}

export default function MessageBubble({ msg, isGroup, botName, uploadPct, onReply, onRecall, onResend, onImage }: Props) {
  const out = msg.direction === "out";
  const recalled = msg.status === "recalled";
  const failed = msg.status === "failed";
  const sending = msg.status === "sending";

  if (recalled) {
    return (
      <div className="text-center my-2">
        <span className="text-[11px] text-ink-faint bg-line-soft/70 rounded-full px-3 py-1">{out ? "你撤回了一条消息" : "对方撤回了一条消息"}</span>
      </div>
    );
  }

  return (
    <div className={`msg-in group flex gap-2.5 ${out ? "flex-row-reverse" : ""} px-4 py-1.5`}>
      {!out && isGroup && (
        <div className="pt-0.5 shrink-0">
          <SafeAvatar name={senderDisplay(msg, botName)} size={34} />
        </div>
      )}
      <div className={`max-w-[78%] md:max-w-[62%] min-w-0 ${out ? "items-end" : "items-start"} flex flex-col`}>
        {isGroup && !out && <div className="text-[11px] text-ink-faint mb-1 px-1 truncate max-w-full">{senderDisplay(msg, botName)}</div>}

        {/* 被引用的消息 */}
        {msg.reply && (
          <div className={`mb-1 w-full rounded-lg border-l-[3px] border-brand/50 bg-black/[0.045] px-2.5 py-1.5 text-xs text-ink-soft ${out ? "text-right" : ""}`}>
            {msg.reply.senderName && <span className="font-semibold text-brand-deep">{msg.reply.senderName}：</span>}
            <span className="break-all">{msg.reply.preview || "[消息]"}</span>
          </div>
        )}

        <div className={`relative rounded-2xl px-3.5 py-2.5 text-[14.5px] leading-relaxed break-words shadow-sm ${
          out ? "bg-brand text-white rounded-br-md" : "bg-card border border-line-soft rounded-bl-md"
        } ${failed ? "ring-2 ring-danger/40" : ""}`}>
          {msg.msgType === "text" && <p className="whitespace-pre-wrap">{msg.text}</p>}
          {msg.msgType === "image" && <ImageAttachment msg={msg} onImage={onImage} />}
          {msg.msgType === "video" && <VideoAttachment msg={msg} />}
          {msg.msgType === "voice" && <VoiceAttachment msg={msg} />}
          {msg.msgType === "file" && <FileAttachment msg={msg} />}
          {msg.msgType !== "text" && msg.text && <p className="mt-1.5 whitespace-pre-wrap">{msg.text}</p>}

          {uploadPct !== undefined && uploadPct < 100 && (
            <div className="mt-2 h-1 w-full rounded-full bg-black/15 overflow-hidden">
              <div className="h-full bg-white/80 transition-all" style={{ width: `${uploadPct}%` }} />
            </div>
          )}
        </div>

        {/* 状态行 */}
        <div className={`flex items-center gap-1.5 mt-1 px-1 text-[11px] ${out ? "flex-row-reverse" : ""}`}>
          {sending && (
            <span className={`flex items-center gap-1 ${out ? "text-brand" : "text-ink-faint"}`}>
              <Spinner size={11} /> 发送中…
            </span>
          )}
          {failed && (
            <button onClick={() => onResend(msg)} className="flex items-center gap-1 text-danger font-semibold hover:underline">
              <IconRefresh size={11} /> 发送失败，点击重发
            </button>
          )}
          {msg.error && !failed && <span className="text-danger">{msg.error}</span>}
        </div>
      </div>

      {/* 悬停操作 */}
      <div className={`self-center opacity-0 group-hover:opacity-100 transition-opacity flex gap-0.5 ${out ? "mr-1" : "ml-1"}`}>
        <button onClick={() => onReply(msg)} className="h-7 w-7 grid place-items-center rounded-lg text-ink-faint hover:bg-line-soft hover:text-brand" title="回复">
          <IconReply size={14} />
        </button>
        {msg.msgType === "text" && msg.text && (
          <button
            onClick={() => navigator.clipboard?.writeText(msg.text || "")}
            className="h-7 w-7 grid place-items-center rounded-lg text-ink-faint hover:bg-line-soft hover:text-brand"
            title="复制"
          >
            <IconCopy size={14} />
          </button>
        )}
        {msg.qqMessageId && msg.status === "sent" && (
          <button onClick={() => onRecall(msg)} className="h-7 w-7 grid place-items-center rounded-lg text-ink-faint hover:bg-danger-soft hover:text-danger" title="撤回">
            <IconClose size={14} />
          </button>
        )}
      </div>
    </div>
  );
}

function srcOf(msg: Message, index: number): string | null {
  const att = msg.attachments[index];
  if (!att) return null;
  if (msg.direction === "out" && att.localId) return api.mediaOut(att.localId);
  // 接收的附件统一走服务端代理缓存：QQ CDN 链接可能过期/需要鉴权。
  return api.mediaIn(msg.id, index);
}

function ImageAttachment({ msg, onImage }: { msg: Message; onImage: (src: string) => void }) {
  const att = msg.attachments[0];
  const src = srcOf(msg, 0);
  if (!src) return <span className="text-xs opacity-70">[图片不可用]</span>;
  return (
    <button onClick={() => onImage(src)} className="block cursor-zoom-in">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt={att?.filename || "图片"}
        loading="lazy"
        className="max-h-72 max-w-full min-w-[120px] rounded-xl object-cover bg-black/10"
        style={att?.width && att?.height ? { aspectRatio: `${att.width}/${att.height}` } : undefined}
      />
    </button>
  );
}

function VideoAttachment({ msg }: { msg: Message }) {
  const src = srcOf(msg, 0);
  if (!src) return <span className="text-xs opacity-70">[视频不可用]</span>;
  return <video src={src} controls preload="metadata" className="max-h-72 max-w-full rounded-xl bg-black/20" />;
}

function VoiceAttachment({ msg }: { msg: Message }) {
  const att = msg.attachments[0];
  const src = att?.voiceWavUrl || srcOf(msg, 0);
  return (
    <div className="min-w-[200px]">
      {src ? <audio src={src} controls className="w-full h-9" /> : <span className="text-xs opacity-70">[语音不可播放]</span>}
      {att?.asrText && <p className="mt-1 text-xs opacity-80">语音识别：{att.asrText}</p>}
    </div>
  );
}

function FileAttachment({ msg }: { msg: Message }) {
  const att = msg.attachments[0];
  const src = srcOf(msg, 0);
  return (
    <a
      href={src ?? undefined}
      download={att?.filename || "file"}
      target={src?.startsWith("http") ? "_blank" : undefined}
      rel="noreferrer"
      className="flex items-center gap-3 min-w-[210px] max-w-full"
    >
      <span className={`h-10 w-10 shrink-0 rounded-xl grid place-items-center ${msg.direction === "out" ? "bg-white/20 text-white" : "bg-brand-soft text-brand"}`}>
        <IconDownload size={18} />
      </span>
      <span className="min-w-0">
        <span className="block truncate text-[13.5px] font-semibold">{att?.filename || "文件"}</span>
        <span className="block text-xs opacity-70">{formatBytes(att?.size)}</span>
      </span>
    </a>
  );
}
