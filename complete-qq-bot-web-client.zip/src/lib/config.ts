import fs from "node:fs";
import path from "node:path";

/**
 * 运行时配置：所有可调项都来自环境变量，方便服务器部署。
 */
const dataDir = path.resolve(process.env.DATA_DIR || path.join(process.cwd(), "data"));

export const config = {
  dataDir,
  logLevel: (process.env.LOG_LEVEL || "info").toLowerCase(),
  mediaDir: path.join(dataDir, "media"),
  outDir: path.join(dataDir, "media", "out"),
  inDir: path.join(dataDir, "media", "in"),
  gatewayDir: path.join(dataDir, "gateway"),
  secretKeyPath: path.join(dataDir, "secret.key"),
  /** 浏览器上传单文件上限（字节），默认 200MB。 */
  maxUploadBytes: (Number(process.env.MAX_UPLOAD_MB) || 200) * 1024 * 1024,
  /** 两次自动同步之间的最小间隔（毫秒），避免频繁调用开放平台接口。 */
  syncMinIntervalMs: 20_000,
  /** 被动回复（带引用）允许的最大消息年龄（毫秒），超过则改为主动消息。 */
  passiveReplyWindowMs: 4.5 * 60 * 1000,
} as const;

export function ensureDirs(): void {
  for (const dir of [config.dataDir, config.mediaDir, config.outDir, config.inDir, config.gatewayDir]) {
    fs.mkdirSync(dir, { recursive: true });
  }
}
