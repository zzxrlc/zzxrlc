/**
 * 浏览器端 API 客户端。
 *
 * 认证双通道：优先使用 httpOnly Cookie；在 Cookie 被屏蔽的环境（如 iframe
 * 预览、某些隐私模式）自动改用 localStorage 中的 Bearer Token，保证注册后
 * 一定能登录。
 */

export type Scope = "c2c" | "group";

export interface Attachment {
  url?: string;
  localId?: string;
  contentType: string;
  filename?: string;
  size?: number;
  width?: number;
  height?: number;
  voiceWavUrl?: string;
  asrText?: string;
}

export interface ReplyRef {
  qqMsgId?: string | null;
  localId?: string;
  preview: string;
  senderName?: string | null;
}

export interface Conversation {
  userId: string;
  id: string;
  scope: Scope;
  peerId: string;
  title: string;
  avatar: string | null;
  remark: string | null;
  lastMessageAt: number;
  lastPreview: string;
  unread: number;
}

export interface Message {
  seq: number;
  id: string;
  userId: string;
  qqMessageId: string | null;
  conversationId: string;
  scope: Scope;
  peerId: string;
  direction: "in" | "out";
  senderId: string | null;
  senderName: string | null;
  msgType: string;
  text: string | null;
  attachments: Attachment[];
  status: string;
  error: string | null;
  reply: ReplyRef | null;
  createdAt: number;
}

export interface BotInfo {
  id: string;
  username: string;
  avatar?: string;
}

export interface BotStatus {
  status: "disconnected" | "connecting" | "connected" | "error";
  connected: boolean;
  hasCredentials: boolean;
  receive: boolean;
  appId: string | null;
  bot: BotInfo | null;
  lastError: string | null;
  syncing: boolean;
  lastSyncAt: number | null;
}

export interface FriendEvent {
  id: string;
  openid: string;
  scene: string | null;
  shortCode: string | null;
  eventTime: number;
  createdAt: number;
}

export interface GroupRobotEvent {
  id: string;
  eventType: "add" | "del";
  groupOpenid: string;
  opMemberOpenid: string | null;
  eventTime: number;
  createdAt: number;
}

export interface JoinRequest {
  id: string;
  joinRequestId: string | null;
  groupOpenid: string;
  memberOpenid: string;
  username: string | null;
  applyAt: string | null;
  applySource: string | null;
  invitedBy: string | null;
  verifyInfo: Record<string, unknown> | null;
  riskTips: string | null;
  status: "pending" | "approved" | "declined";
  createdAt: number;
  processedAt: number | null;
}

export interface RequestsData {
  friends: FriendEvent[];
  groupEvents: GroupRobotEvent[];
  joinRequests: JoinRequest[];
  pendingCount: number;
}

export interface ErrorDetail {
  source: string;
  code: number | string;
  type: string;
  message: string;
  retryable: boolean;
  suggestion: string;
}

export class ApiError extends Error {
  detail: ErrorDetail;
  constructor(detail: ErrorDetail) {
    super(detail.message || "请求失败");
    this.name = "ApiError";
    this.detail = detail;
  }
}

// ── token 兜底通道 ────────────────────────────────────────────────────────

const TOKEN_KEY = "qqc_token";

/** 内存中的 token：即使 Cookie 与 localStorage 都被环境屏蔽，也能在本次会话内使用。 */
let memoryToken: string | null = null;

export function getStoredToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

/** 尝试写入 localStorage，返回是否成功（被屏蔽的环境会返回 false）。 */
export function setStoredToken(token: string | null): boolean {
  if (typeof window === "undefined") return false;
  try {
    if (token) window.localStorage.setItem(TOKEN_KEY, token);
    else window.localStorage.removeItem(TOKEN_KEY);
    return true;
  } catch {
    return false;
  }
}

/** 当前有效 token：内存优先，localStorage 兜底。 */
export function getAuthToken(): string | null {
  return memoryToken ?? getStoredToken();
}

/** 同时写入内存与 localStorage，返回 localStorage 是否可用。 */
export function setAuthToken(token: string | null): boolean {
  memoryToken = token;
  return setStoredToken(token);
}

function authHeaders(): Record<string, string> {
  const token = getAuthToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function q(url: string, init?: RequestInit): Promise<Response> {
  const headers = { ...(init?.headers as Record<string, string> | undefined), ...authHeaders() };
  return fetch(url, { ...init, headers });
}

/** SSE 地址：EventSource 无法自定义请求头，只能附带 ?token= 兜底。 */
export function eventsUrl(): string {
  const token = getAuthToken();
  return token ? `/api/events?token=${encodeURIComponent(token)}` : "/api/events";
}

function normalizeError(body: unknown): ApiError {
  const b = body as { error?: ErrorDetail };
  if (b?.error) return new ApiError(b.error);
  return new ApiError({
    source: "client",
    code: "HTTP",
    type: "NETWORK_ERROR",
    message: "请求失败",
    retryable: true,
    suggestion: "请稍后重试",
  });
}

async function json<T>(res: Response): Promise<T> {
  const body = (await res.json().catch(() => ({}))) as { success?: boolean; error?: ErrorDetail };
  if (!res.ok || body.success === false) throw normalizeError(body);
  return body as T;
}

export function errText(e: unknown): string {
  if (e instanceof ApiError) {
    return e.detail.suggestion ? `${e.detail.message}（${e.detail.suggestion}）` : e.detail.message;
  }
  return e instanceof Error ? e.message : "操作失败，请稍后重试";
}

export interface AuthResult {
  user: { id: string; username: string };
  token?: string;
}

export const api = {
  // ── 账号 ──
  async login(username: string, password: string): Promise<AuthResult> {
    const res = await q("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const body = await json<AuthResult>(res);
    if (body.token) setAuthToken(body.token);
    return body;
  },
  async register(username: string, password: string): Promise<AuthResult> {
    const res = await q("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const body = await json<AuthResult>(res);
    if (body.token) setAuthToken(body.token);
    return body;
  },
  async logout(): Promise<void> {
    await q("/api/auth/logout", { method: "POST" }).catch(() => {});
    setAuthToken(null);
  },

  // ── 机器人 ──
  async status(): Promise<BotStatus> {
    const body = await json<{ status: BotStatus }>(await q("/api/bot/status", { cache: "no-store" }));
    return body.status;
  },
  async connect(appId?: string, appSecret?: string): Promise<BotStatus> {
    const res = await q("/api/bot/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ appId, appSecret }),
    });
    return (await json<{ status: BotStatus }>(res)).status;
  },
  async disconnect(clearCreds = false): Promise<BotStatus> {
    const res = await q("/api/bot/disconnect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clearCreds }),
    });
    return (await json<{ status: BotStatus }>(res)).status;
  },
  async setReceive(on: boolean): Promise<BotStatus> {
    const res = await q("/api/bot/receive", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ on }),
    });
    return (await json<{ status: BotStatus }>(res)).status;
  },
  async syncNow(force = false): Promise<void> {
    await q("/api/bot/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ force }),
    }).catch(() => {});
  },
  async diagnose(appId?: string, appSecret?: string): Promise<{
    network: Array<{ host: string; ok: boolean; latencyMs: number | null; error?: string }>;
    token: { tested: boolean; ok: boolean; appId?: string; code?: number | string; message?: string };
  }> {
    const res = await q("/api/bot/diagnose", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ appId, appSecret }),
    });
    return (await json<{ result: { network: unknown[]; token: unknown } }>(res)).result as {
      network: Array<{ host: string; ok: boolean; latencyMs: number | null; error?: string }>;
      token: { tested: boolean; ok: boolean; appId?: string; code?: number | string; message?: string };
    };
  },

  // ── 会话 / 消息 ──
  async conversations(): Promise<Conversation[]> {
    const body = await json<{ conversations: Conversation[] }>(await q("/api/conversations", { cache: "no-store" }));
    return body.conversations;
  },
  async messages(conversationId: string, limit = 50, beforeSeq?: number): Promise<{ messages: Message[]; hasMore: boolean }> {
    const qs = new URLSearchParams({ limit: String(limit) });
    if (beforeSeq) qs.set("before", String(beforeSeq));
    return json(await q(`/api/conversations/${encodeURIComponent(conversationId)}/messages?${qs}`, { cache: "no-store" }));
  },
  async sendText(conversationId: string, text: string, replyTo?: string | null): Promise<Message> {
    const res = await q(`/api/conversations/${encodeURIComponent(conversationId)}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, replyTo: replyTo ?? null }),
    });
    return (await json<{ message: Message }>(res)).message;
  },
  async markRead(conversationId: string): Promise<void> {
    await q(`/api/conversations/${encodeURIComponent(conversationId)}/meta`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "read" }),
    }).catch(() => {});
  },
  async rename(conversationId: string, remark: string): Promise<Conversation> {
    const res = await q(`/api/conversations/${encodeURIComponent(conversationId)}/meta`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "rename", remark }),
    });
    return (await json<{ conversation: Conversation }>(res)).conversation;
  },
  async messageOp(messageId: string, op: "recall" | "resend"): Promise<void> {
    const res = await q(`/api/messages/${encodeURIComponent(messageId)}/ops`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ op }),
    });
    await json(res);
  },

  // ── 请求通知 ──
  async requests(): Promise<RequestsData> {
    return json(await q("/api/requests", { cache: "no-store" }));
  },
  async approveJoin(id: string): Promise<JoinRequest> {
    const res = await q(`/api/requests/join/${encodeURIComponent(id)}/approve`, { method: "POST" });
    return (await json<{ request: JoinRequest }>(res)).request;
  },
  async declineJoin(id: string, reason?: string): Promise<JoinRequest> {
    const res = await q(`/api/requests/join/${encodeURIComponent(id)}/decline`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason }),
    });
    return (await json<{ request: JoinRequest }>(res)).request;
  },

  async groupMembers(conversationId: string): Promise<Array<{ openid: string; name: string | null; avatar: string | null; joinTime: string | null }>> {
    const body = await json<{ members: Array<{ openid: string; name: string | null; avatar: string | null; joinTime: string | null }> }>(
      await q(`/api/conversations/${encodeURIComponent(conversationId)}/members`, { cache: "no-store" }),
    );
    return body.members;
  },

  mediaIn(messageId: string, index: number): string {
    // <img>/<a> 标签无法自定义请求头，同样附带 ?token= 兜底。
    const token = getAuthToken();
    const base = `/api/media/in/${encodeURIComponent(messageId)}/${index}`;
    return token ? `${base}?token=${encodeURIComponent(token)}` : base;
  },
  mediaOut(localId: string): string {
    const token = getAuthToken();
    const base = `/api/media/out/${encodeURIComponent(localId)}`;
    return token ? `${base}?token=${encodeURIComponent(token)}` : base;
  },
};

/** 带进度上传（XHR 才能拿到上传进度）。 */
export function uploadMedia(
  conversationId: string,
  file: File,
  kind: "image" | "video" | "voice" | "file",
  replyTo: string | null,
  onProgress: (uploaded: number, total: number) => void,
): Promise<Message> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `/api/conversations/${encodeURIComponent(conversationId)}/media`);
    xhr.responseType = "text";
    const token = getAuthToken();
    if (token) xhr.setRequestHeader("Authorization", `Bearer ${token}`);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(e.loaded, e.total);
    };
    xhr.onload = () => {
      let data: { success?: boolean; message?: Message; error?: ErrorDetail };
      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        reject(new ApiError({ source: "client", code: "HTTP", type: "PARSE_ERROR", message: "响应解析失败", retryable: false, suggestion: "请重试" }));
        return;
      }
      if (xhr.status >= 200 && xhr.status < 300 && data.success && data.message) resolve(data.message);
      else reject(normalizeError(data));
    };
    xhr.onerror = () =>
      reject(new ApiError({ source: "client", code: 0, type: "NETWORK_ERROR", message: "网络连接失败", retryable: true, suggestion: "请检查网络后重试" }));
    const fd = new FormData();
    fd.append("kind", kind);
    if (replyTo) fd.append("replyTo", replyTo);
    fd.append("file", file, file.name || "file.bin");
    xhr.send(fd);
  });
}

// ── 格式化工具 ──

export function convTitle(c: Conversation): string {
  return (c.remark || c.title || (c.scope === "group" ? "QQ 群聊" : "QQ 好友")).trim() || (c.scope === "group" ? "QQ 群聊" : "QQ 好友");
}

export function formatTime(ts: number): string {
  if (!ts) return "";
  const d = new Date(ts);
  const now = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  const hm = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  if (d.toDateString() === now.toDateString()) return hm;
  if (d.getFullYear() === now.getFullYear()) return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${hm}`;
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function formatDay(ts: number): string {
  const d = new Date(ts);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return "今天";
  const yesterday = new Date(now.getTime() - 86400000);
  if (d.toDateString() === yesterday.toDateString()) return "昨天";
  if (d.getFullYear() === now.getFullYear()) return `${d.getMonth() + 1}月${d.getDate()}日`;
  return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
}

export function formatBytes(n?: number | null): string {
  if (!n || n <= 0) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}
