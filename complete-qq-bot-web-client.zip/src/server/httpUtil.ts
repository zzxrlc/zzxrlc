import { getSessionUserFromRequest } from "@/lib/auth";
import { AppError, appError, errorBody } from "@/lib/errors";
import type { User } from "@/db/schema";

export const nodeRuntime = { runtime: "nodejs" as const, dynamic: "force-dynamic" as const };

export async function requireUser(req: Request): Promise<User> {
  const user = await getSessionUserFromRequest(req);
  if (!user) throw appError("AUTH_ERROR", "未登录或登录已过期", "请重新登录");
  return user;
}

export function ok<T extends object>(data: T, init?: ResponseInit): Response {
  return Response.json({ success: true, ...data }, init);
}

export function fail(err: unknown, fallbackStatus = 400): Response {
  // 业务校验类错误（如"用户名已被注册"）直接展示原文，不加"请稍后重试"。
  const body =
    err instanceof AppError
      ? { success: false as const, error: err.detail }
      : err instanceof Error && err.name === "Error"
        ? {
            success: false as const,
            error: { source: "app" as const, code: "APP", type: "INVALID_REQUEST", message: err.message, retryable: false, suggestion: "" },
          }
        : errorBody(err);
  const status = body.error.type === "AUTH_ERROR" ? 401 : body.error.type === "RATE_LIMIT" ? 429 : fallbackStatus;
  return Response.json(body, { status });
}

export async function readJson<T = Record<string, unknown>>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    throw appError("INVALID_REQUEST", "请求体不是有效的 JSON", "请检查请求格式");
  }
}
