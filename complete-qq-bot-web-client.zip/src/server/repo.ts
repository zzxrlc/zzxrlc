import { and, asc, desc, eq, gt, isNull, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  contacts,
  conversations,
  friendEvents,
  groupRobotEvents,
  joinRequests,
  messages,
  settings,
  type AttachmentMeta,
  type ContactRow,
  type ConversationRow,
  type JoinRequestRow,
  type MessageRow,
  type ReplyRef,
} from "@/db/schema";
import { newId } from "@/lib/auth";
import { log } from "@/lib/logger";

export type Scope = "c2c" | "group";

export function convId(scope: Scope, peerId: string): string {
  return `${scope}:${peerId}`;
}

export function parseConversationId(id: string): { scope: Scope; peerId: string } | null {
  const idx = id.indexOf(":");
  if (idx <= 0) return null;
  const scope = id.slice(0, idx);
  if (scope !== "c2c" && scope !== "group") return null;
  return { scope: scope as Scope, peerId: id.slice(idx + 1) };
}

// ── settings ───────────────────────────────────────────────────────────────

export async function getSetting(userId: string, key: string): Promise<string | null> {
  const rows = await db.select().from(settings).where(and(eq(settings.userId, userId), eq(settings.key, key))).limit(1);
  return rows[0]?.value ?? null;
}

export async function setSetting(userId: string, key: string, value: string): Promise<void> {
  await db
    .insert(settings)
    .values({ userId, key, value })
    .onConflictDoUpdate({ target: [settings.userId, settings.key], set: { value } });
}

export async function delSetting(userId: string, key: string): Promise<void> {
  await db.delete(settings).where(and(eq(settings.userId, userId), eq(settings.key, key)));
}

export async function listUsersWithSetting(key: string): Promise<string[]> {
  const rows = await db.select({ userId: settings.userId }).from(settings).where(eq(settings.key, key));
  return [...new Set(rows.map((r) => r.userId))];
}

// ── conversations ──────────────────────────────────────────────────────────

export async function getConversation(userId: string, id: string): Promise<ConversationRow | null> {
  const rows = await db.select().from(conversations).where(and(eq(conversations.userId, userId), eq(conversations.id, id))).limit(1);
  return rows[0] ?? null;
}

export async function listConversations(userId: string): Promise<ConversationRow[]> {
  return db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(desc(conversations.lastMessageAt), desc(conversations.unread));
}

export interface UpsertConversationInput {
  id: string;
  scope: Scope;
  peerId: string;
  title?: string;
  avatar?: string | null;
  lastMessageAt?: number;
  lastPreview?: string;
}

/** 会话不存在则创建；已存在只补齐标题/头像（不覆盖更新时间与预览）。 */
export async function ensureConversation(userId: string, input: UpsertConversationInput): Promise<ConversationRow> {
  await db
    .insert(conversations)
    .values({
      userId,
      id: input.id,
      scope: input.scope,
      peerId: input.peerId,
      title: input.title ?? input.peerId,
      avatar: input.avatar ?? null,
      lastMessageAt: input.lastMessageAt ?? 0,
      lastPreview: input.lastPreview ?? "",
      unread: 0,
    })
    .onConflictDoUpdate({
      target: [conversations.userId, conversations.id],
      set: {
        title: sql`CASE WHEN ${conversations.title} = ${conversations.peerId} AND EXCLUDED.title <> EXCLUDED.peer_id THEN EXCLUDED.title ELSE ${conversations.title} END`,
        avatar: sql`COALESCE(EXCLUDED.avatar, ${conversations.avatar})`,
      },
    });
  const conv = await getConversation(userId, input.id);
  return conv!;
}

/** 收到/发送消息时更新会话（时间、预览、未读）。 */
export async function touchConversation(
  userId: string,
  id: string,
  opts: { lastMessageAt: number; lastPreview: string; incrUnread?: boolean },
): Promise<ConversationRow | null> {
  await db
    .update(conversations)
    .set({
      lastMessageAt: opts.lastMessageAt,
      lastPreview: opts.lastPreview,
      unread: opts.incrUnread ? sql`${conversations.unread} + 1` : conversations.unread,
    })
    .where(and(eq(conversations.userId, userId), eq(conversations.id, id)));
  return getConversation(userId, id);
}

export async function updateConversationIdentity(
  userId: string,
  id: string,
  patch: { title?: string; avatar?: string | null },
): Promise<ConversationRow | null> {
  const set: { title?: string; avatar?: string | null } = {};
  if (patch.title !== undefined) set.title = patch.title;
  if (patch.avatar !== undefined) set.avatar = patch.avatar;
  if (Object.keys(set).length === 0) return getConversation(userId, id);
  await db.update(conversations).set(set).where(and(eq(conversations.userId, userId), eq(conversations.id, id)));
  return getConversation(userId, id);
}

export async function setConversationRemark(userId: string, id: string, remark: string | null): Promise<ConversationRow | null> {
  await db.update(conversations).set({ remark }).where(and(eq(conversations.userId, userId), eq(conversations.id, id)));
  return getConversation(userId, id);
}

export async function markRead(userId: string, id: string): Promise<void> {
  await db.update(conversations).set({ unread: 0 }).where(and(eq(conversations.userId, userId), eq(conversations.id, id)));
}

// ── messages ───────────────────────────────────────────────────────────────

export interface InsertMessageInput {
  id?: string;
  userId: string;
  qqMessageId?: string | null;
  conversationId: string;
  scope: Scope;
  peerId: string;
  direction: "in" | "out";
  senderId?: string | null;
  senderName?: string | null;
  msgType: string;
  text?: string | null;
  attachments?: AttachmentMeta[];
  status?: string;
  error?: string | null;
  reply?: ReplyRef | null;
  createdAt: number;
}

/** 插入消息；若 qq_message_id 重复返回已有记录（幂等，绝不重复入库）。 */
export async function insertMessage(input: InsertMessageInput): Promise<{ row: MessageRow; duplicate: boolean }> {
  const id = input.id ?? newId();
  try {
    const rows = await db
      .insert(messages)
      .values({
        id,
        userId: input.userId,
        qqMessageId: input.qqMessageId ?? null,
        conversationId: input.conversationId,
        scope: input.scope,
        peerId: input.peerId,
        direction: input.direction,
        senderId: input.senderId ?? null,
        senderName: input.senderName ?? null,
        msgType: input.msgType,
        text: input.text ?? null,
        attachments: input.attachments ?? [],
        status: input.status ?? "sent",
        error: input.error ?? null,
        reply: input.reply ?? null,
        createdAt: input.createdAt,
      })
      .returning();
    return { row: rows[0], duplicate: false };
  } catch (err) {
    if (isUniqueViolation(err) && input.qqMessageId) {
      const existing = await findMessageByQQId(input.userId, input.qqMessageId);
      if (existing) return { row: existing, duplicate: true };
    }
    throw err;
  }
}

export function isUniqueViolation(err: unknown): boolean {
  return !!err && typeof err === "object" && "code" in err && (err as { code: string }).code === "23505";
}

export async function findMessageByQQId(userId: string, qqMessageId: string): Promise<MessageRow | null> {
  const rows = await db
    .select()
    .from(messages)
    .where(and(eq(messages.userId, userId), eq(messages.qqMessageId, qqMessageId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function getMessage(userId: string, id: string): Promise<MessageRow | null> {
  const rows = await db.select().from(messages).where(and(eq(messages.userId, userId), eq(messages.id, id))).limit(1);
  return rows[0] ?? null;
}

export async function listMessages(
  userId: string,
  conversationId: string,
  limit: number,
  beforeSeq?: number,
): Promise<{ rows: MessageRow[]; hasMore: boolean }> {
  const conds = [eq(messages.userId, userId), eq(messages.conversationId, conversationId)];
  if (beforeSeq) conds.push(lt(messages.seq, beforeSeq));
  const rows = await db
    .select()
    .from(messages)
    .where(and(...conds))
    .orderBy(desc(messages.seq))
    .limit(limit + 1);
  const hasMore = rows.length > limit;
  return { rows: rows.slice(0, limit).reverse(), hasMore };
}

export async function updateMessageStatus(userId: string, id: string, status: string, error?: string | null): Promise<MessageRow | null> {
  await db
    .update(messages)
    .set({ status, error: error === undefined ? messages.error : error })
    .where(and(eq(messages.userId, userId), eq(messages.id, id)));
  return getMessage(userId, id);
}

export async function setMessageQQId(userId: string, id: string, qqMessageId: string): Promise<void> {
  await db.update(messages).set({ qqMessageId }).where(and(eq(messages.userId, userId), eq(messages.id, id), isNull(messages.qqMessageId)));
}

// ── contacts (名称/头像缓存) ─────────────────────────────────────────────

export async function getContact(userId: string, kind: string, openid: string): Promise<ContactRow | null> {
  const rows = await db
    .select()
    .from(contacts)
    .where(and(eq(contacts.userId, userId), eq(contacts.kind, kind), eq(contacts.openid, openid)))
    .limit(1);
  return rows[0] ?? null;
}

export async function upsertContact(
  userId: string,
  kind: string,
  openid: string,
  patch: { name?: string | null; avatar?: string | null; extra?: Record<string, unknown> },
): Promise<ContactRow> {
  await db
    .insert(contacts)
    .values({
      userId,
      kind,
      openid,
      name: patch.name ?? null,
      avatar: patch.avatar ?? null,
      extra: patch.extra ?? {},
      updatedAt: Date.now(),
    })
    .onConflictDoUpdate({
      target: [contacts.userId, contacts.kind, contacts.openid],
      set: {
        name: sql`COALESCE(EXCLUDED.name, ${contacts.name})`,
        avatar: sql`COALESCE(EXCLUDED.avatar, ${contacts.avatar})`,
        extra: sql`COALESCE(EXCLUDED.extra, ${contacts.extra})`,
        updatedAt: Date.now(),
      },
    });
  return (await getContact(userId, kind, openid))!;
}

export async function listGroupContacts(userId: string): Promise<ContactRow[]> {
  return db.select().from(contacts).where(and(eq(contacts.userId, userId), eq(contacts.kind, "group"))).orderBy(asc(contacts.name));
}

// ── friend / group robot events / join requests ───────────────────────────

export async function insertFriendEvent(userId: string, openid: string, scene: string | null, shortCode: string | null, eventTime: number) {
  try {
    const rows = await db
      .insert(friendEvents)
      .values({ id: newId(), userId, openid, scene, shortCode, eventTime, createdAt: Date.now() })
      .returning();
    return rows[0];
  } catch (err) {
    if (isUniqueViolation(err)) return null; // 幂等
    throw err;
  }
}

export async function listFriendEvents(userId: string) {
  return db.select().from(friendEvents).where(eq(friendEvents.userId, userId)).orderBy(desc(friendEvents.createdAt)).limit(100);
}

export async function insertGroupRobotEvent(
  userId: string,
  eventType: string,
  groupOpenid: string,
  opMemberOpenid: string | null,
  eventTime: number,
) {
  const rows = await db
    .insert(groupRobotEvents)
    .values({ id: newId(), userId, eventType, groupOpenid, opMemberOpenid, eventTime, createdAt: Date.now() })
    .returning();
  return rows[0];
}

export async function listGroupRobotEvents(userId: string) {
  return db.select().from(groupRobotEvents).where(eq(groupRobotEvents.userId, userId)).orderBy(desc(groupRobotEvents.createdAt)).limit(100);
}

export async function insertJoinRequest(
  userId: string,
  input: {
    joinRequestId: string | null;
    groupOpenid: string;
    memberOpenid: string;
    username: string | null;
    applyAt: string | null;
    applySource: string | null;
    invitedBy: string | null;
    verifyInfo: Record<string, unknown> | null;
    riskTips: string | null;
  },
): Promise<JoinRequestRow | null> {
  if (input.joinRequestId) {
    const dup = await db
      .select()
      .from(joinRequests)
      .where(and(eq(joinRequests.userId, userId), eq(joinRequests.joinRequestId, input.joinRequestId)))
      .limit(1);
    if (dup.length > 0) return null;
  }
  const rows = await db
    .insert(joinRequests)
    .values({ id: newId(), userId, status: "pending", createdAt: Date.now(), ...input })
    .returning();
  return rows[0];
}

export async function getJoinRequest(userId: string, id: string): Promise<JoinRequestRow | null> {
  const rows = await db.select().from(joinRequests).where(and(eq(joinRequests.userId, userId), eq(joinRequests.id, id))).limit(1);
  return rows[0] ?? null;
}

export async function updateJoinRequestStatus(userId: string, id: string, status: string): Promise<JoinRequestRow | null> {
  await db
    .update(joinRequests)
    .set({ status, processedAt: Date.now() })
    .where(and(eq(joinRequests.userId, userId), eq(joinRequests.id, id)));
  return getJoinRequest(userId, id);
}

export async function listJoinRequests(userId: string) {
  return db.select().from(joinRequests).where(eq(joinRequests.userId, userId)).orderBy(desc(joinRequests.createdAt)).limit(100);
}

/** 清理 60 天前的会话外消息，避免无限膨胀（可按需调整）。 */
export async function pruneOldMessages(userId: string): Promise<void> {
  const cutoff = Date.now() - 60 * 24 * 3600 * 1000;
  try {
    await db.delete(messages).where(and(eq(messages.userId, userId), lt(messages.createdAt, cutoff)));
  } catch (e) {
    log.warn("pruneOldMessages failed", e);
  }
}
