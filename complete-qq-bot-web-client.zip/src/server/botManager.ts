import { randomUUID } from "node:crypto";
import {
  FileKVStore,
  MediaFileType,
  QQBot,
  kvSessionPersistence,
  type QQBotInboundMessage,
  type ReplyTarget,
} from "@tencent-connect/qqbot-nodejs";
import { bus } from "@/lib/bus";
import { config, ensureDirs } from "@/lib/config";
import { AppError, appError, classifyError, type QQErrorDetail } from "@/lib/errors";
import { log } from "@/lib/logger";
import { decryptSecret, encryptSecret, maskSecret } from "@/lib/secret";
import {
  convId,
  delSetting,
  ensureConversation,
  findMessageByQQId,
  getContact,
  getConversation,
  getSetting,
  insertFriendEvent,
  insertGroupRobotEvent,
  insertJoinRequest,
  insertMessage,
  listConversations,
  listJoinRequests,
  markRead,
  setConversationRemark,
  setMessageQQId,
  setSetting,
  touchConversation,
  updateConversationIdentity,
  updateJoinRequestStatus,
  updateMessageStatus,
  upsertContact,
  type Scope,
} from "./repo";
import type { AttachmentMeta, ReplyRef } from "@/db/schema";

/**
 * 机器人运行时管理器（每个网页用户一个独立的 QQBot 实例）。
 *
 * - 浏览器连接机器人后，网关长连接常驻服务器进程：即使关闭浏览器，消息也
 *   持续入库；重新打开浏览器即可看到期间的所有消息。
 * - “常驻接收”开关：关闭后断开网关停止接收，开启后重新连接并自动补齐
 *   期间错过的消息（通过消息记录接口同步）。
 * - 所有入站消息先落库再推送浏览器，配合 qq_message_id 唯一索引去重，
 *   保证不漏消息、不重复。
 */

export type BotStatus = "disconnected" | "connecting" | "connected" | "error";

export interface BotInfo {
  id: string;
  username: string;
  avatar?: string;
}

export interface StatusPayload {
  status: BotStatus;
  connected: boolean;
  hasCredentials: boolean;
  receive: boolean;
  appId: string | null;
  bot: BotInfo | null;
  lastError: string | null;
  syncing: boolean;
  lastSyncAt: number | null;
}

interface UserBotState {
  status: BotStatus;
  bot: QQBot | null;
  botInfo: BotInfo | null;
  lastError: string | null;
  lastErrorDetail: QQErrorDetail | null;
  abort: AbortController | null;
  stopped: boolean;
  syncing: boolean;
  retryTimer: NodeJS.Timeout | null;
  retryCount: number;
  /** SDK 日志中捕获的最后一条诊断信息（网关被拒绝等 SDK 只记日志不抛事件的场景）。 */
  sdkDiag: string | null;
  /** 连接过程中捕获到致命诊断时的回调（由 connect 注册）。 */
  onFatal: ((detail: QQErrorDetail) => void) | null;
}

interface ManagerGlobal {
  states: Map<string, UserBotState>;
  booted: boolean;
  inflightNames: Set<string>;
  lastSync: Map<string, number>;
}

const g = globalThis as unknown as { __qqbotManager?: ManagerGlobal };

function mgr(): ManagerGlobal {
  if (!g.__qqbotManager) {
    g.__qqbotManager = { states: new Map(), booted: false, inflightNames: new Set(), lastSync: new Map() };
  }
  return g.__qqbotManager;
}

function getState(userId: string): UserBotState {
  const m = mgr();
  let st = m.states.get(userId);
  if (!st) {
    st = {
      status: "disconnected",
      bot: null,
      botInfo: null,
      lastError: null,
      lastErrorDetail: null,
      abort: null,
      stopped: true,
      syncing: false,
      retryTimer: null,
      retryCount: 0,
      sdkDiag: null,
      onFatal: null,
    };
    m.states.set(userId, st);
  }
  return st;
}

// ── 凭证与状态 ─────────────────────────────────────────────────────────────

async function storedCreds(userId: string): Promise<{ appId: string; secret: string } | null> {
  const raw = await getSetting(userId, "credentials");
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as { appId: string; secretEnc: string };
    return { appId: parsed.appId, secret: decryptSecret(parsed.secretEnc) };
  } catch {
    return null;
  }
}

export async function statusPayload(userId: string): Promise<StatusPayload> {
  const st = getState(userId);
  const raw = await getSetting(userId, "credentials");
  let appId: string | null = null;
  if (raw) {
    try {
      appId = (JSON.parse(raw) as { appId: string }).appId;
    } catch {
      /* ignore */
    }
  }
  const receiveRaw = await getSetting(userId, "receive");
  const lastSyncRaw = await getSetting(userId, "lastSyncAt");
  return {
    status: st.status,
    connected: st.status === "connected",
    hasCredentials: !!raw,
    receive: receiveRaw !== "off",
    appId: appId ? maskSecret(appId, 4) : null,
    bot: st.botInfo,
    lastError: st.lastError,
    syncing: st.syncing,
    lastSyncAt: lastSyncRaw ? Number(lastSyncRaw) : null,
  };
}

async function emitStatus(userId: string): Promise<void> {
  bus.emit(userId, "status", await statusPayload(userId));
}

export function requireBot(userId: string): QQBot {
  const st = getState(userId);
  if (!st.bot || st.status !== "connected") {
    throw appError("GATEWAY_ERROR", "机器人尚未连接", "请先在设置中连接机器人");
  }
  return st.bot;
}

// ── 连接 / 断开 / 常驻开关 ────────────────────────────────────────────────

/**
 * 只订阅「群聊 + 私聊」事件（1<<25）。
 *
 * 官方 SDK 默认 FULL_INTENTS 会额外请求频道（GUILDS/GUILD_MEMBERS 等）权限，
 * 对于只开通了群聊/私聊能力的机器人，网关会以 4914/4915 直接断开连接。
 * 这里改用最小必要 intent，避免因权限不匹配导致「静默连不上」。
 */
const GROUP_C2C_INTENTS = 1 << 25;

/**
 * SDK 在很多致命场景（机器人未上线/沙箱模式、被平台限制、intent 权限不足）
 * 只向 logger 写日志、不触发 error 事件，导致上层永远停在“连接中”。
 * 这里给 SDK 注入带捕获能力的 logger：捕获 warn/error 日志，识别致命信息并
 * 立即转成可见错误。
 */
function makeBotLogger(userId: string) {
  const tag = `[qq-sdk:${userId.slice(0, 8)}]`;
  return {
    debug: (...a: unknown[]) => log.debug(`${tag} ${a.map(String).join(" ")}`),
    info: (...a: unknown[]) => log.info(`${tag} ${a.map(String).join(" ")}`),
    warn: (...a: unknown[]) => {
      const msg = a.map(String).join(" ");
      log.warn(`${tag} ${msg}`);
      captureSdkDiag(userId, msg);
    },
    error: (...a: unknown[]) => {
      const msg = a.map(String).join(" ");
      log.error(`${tag} ${msg}`);
      captureSdkDiag(userId, msg);
    },
  };
}

/** 把 SDK 的英文诊断映射成中文可读错误（返回 null 表示非致命，仅记录）。 */
function mapSdkFatal(msg: string): QQErrorDetail | null {
  const m = msg.toLowerCase();
  if (m.includes("offline") || m.includes("sandbox")) {
    return {
      source: "app",
      code: 4914,
      type: "PERMISSION_DENIED",
      message: "机器人未上线或处于沙箱模式",
      suggestion: "请到 QQ 开放平台（q.qq.com）完成机器人「发布/上线」，或在沙箱配置中加入测试群与测试成员",
      retryable: false,
      raw: msg,
    };
  }
  if (m.includes("banned")) {
    return {
      source: "app",
      code: 4915,
      type: "PERMISSION_DENIED",
      message: "机器人已被平台限制",
      suggestion: "请联系 QQ 开放平台解除限制",
      retryable: false,
      raw: msg,
    };
  }
  if (m.includes("too many requests")) {
    return {
      source: "app",
      code: "RATE_LIMIT",
      type: "RATE_LIMIT",
      message: "连接请求过于频繁",
      suggestion: "请稍等片刻后再尝试连接",
      retryable: true,
      raw: msg,
    };
  }
  return null;
}

function captureSdkDiag(userId: string, message: string): void {
  const st = getState(userId);
  st.sdkDiag = message;
  const fatal = mapSdkFatal(message);
  if (fatal && st.onFatal) {
    st.onFatal(fatal);
  }
}

export async function connect(userId: string, appIdInput?: string, appSecretInput?: string): Promise<StatusPayload> {
  ensureDirs();
  let appId = appIdInput?.trim();
  let secret = appSecretInput;

  if (appId || secret) {
    if (!appId) throw appError("INVALID_REQUEST", "请填写 AppID", "AppID 为必填项");
    if (!secret) throw appError("INVALID_REQUEST", "请填写 AppSecret", "AppSecret 为必填项");
  } else {
    const creds = await storedCreds(userId);
    if (!creds) throw appError("INVALID_REQUEST", "尚未配置机器人凭证", "请先填写 AppID 与 AppSecret");
    appId = creds.appId;
    secret = creds.secret;
  }

  await stopBot(userId, false);
  const st = getState(userId);
  st.status = "connecting";
  st.lastError = null;
  st.lastErrorDetail = null;
  st.stopped = false;
  await emitStatus(userId);

  const bot = new QQBot({
    appId: appId!,
    appSecret: secret!,
    accountId: `${userId}:${appId}`,
    markdownSupport: false,
    intents: GROUP_C2C_INTENTS,
    logger: makeBotLogger(userId),
    sessionPersistence: kvSessionPersistence({
      store: new FileKVStore({ dir: config.gatewayDir, fileName: `gw-${userId.slice(0, 8)}-${appId!.slice(-6)}.json` }),
      accountId: `${userId}:${appId}`,
    }),
  });
  st.bot = bot;
  st.sdkDiag = null;
  const ac = new AbortController();
  st.abort = ac;

  let resolveReady!: () => void;
  let resolveError!: (d: QQErrorDetail) => void;
  const readyPromise = new Promise<void>((res) => (resolveReady = res));
  // 注意：这里必须用 resolve（而非 reject）——错误走 result === "error" 分支，
  // 保证把分类好的 detail 原样抛成 AppError，避免二次分类丢失原始错误信息。
  const errorPromise = new Promise<QQErrorDetail>((res) => (resolveError = res));

  // SDK 日志中捕获到致命诊断（未上线/沙箱/封禁）时，立即转成可见错误。
  st.onFatal = (detail: QQErrorDetail) => {
    if (st.bot !== bot) return;
    st.status = "error";
    st.lastError = detail.message;
    st.lastErrorDetail = detail;
    void emitStatus(userId);
    resolveError(detail);
  };

  bot.on("ready", () => {
    if (st.bot !== bot) return;
    st.status = "connected";
    st.lastError = null;
    st.retryCount = 0;
    st.onFatal = null;
    resolveReady();
    void (async () => {
      await setSetting(userId, "credentials", JSON.stringify({ appId: appId!, secretEnc: encryptSecret(secret!) }));
      await setSetting(userId, "receive", "on");
      const info = await fetchBotInfo(userId, bot);
      if (st.bot === bot && info) st.botInfo = info;
      await emitStatus(userId);
      // 连接成功后立即同步一次，补齐离线期间的消息与群列表。
      void sync(userId, false).catch((e) => log.warn("auto sync failed", e));
    })();
  });

  bot.on("resumed", () => {
    if (st.bot !== bot) return;
    st.status = "connected";
    void emitStatus(userId);
  });

  bot.on("error", (err: Error) => {
    if (st.bot !== bot) return;
    const detail = classifyError(err);
    st.status = "error";
    st.lastError = detail.message;
    st.lastErrorDetail = detail;
    void emitStatus(userId);
    resolveError(detail);
    scheduleRetry(userId, detail);
  });

  bot.on("message", (_ctx, msg) => {
    if (st.bot !== bot) return;
    void handleInbound(userId, msg).catch((e) => log.error("inbound handler failed", e));
  });

  bot.on("rawEvent", (ctx) => {
    if (st.bot !== bot) return;
    void handleRawEvent(userId, ctx.eventType, ctx.data).catch((e) => log.error("raw event handler failed", e));
  });

  const startPromise = bot.start(ac.signal).catch((err) => {
    if (st.bot !== bot || st.stopped) return;
    const detail = classifyError(err);
    st.status = "error";
    st.lastError = detail.message;
    st.lastErrorDetail = detail;
    void emitStatus(userId);
    resolveError(detail);
    scheduleRetry(userId, detail);
  });
  void startPromise;

  const timeout = new Promise<"timeout">((res) => setTimeout(() => res("timeout"), 15000));
  const result = await Promise.race([
    readyPromise.then(() => "ready" as const),
    errorPromise.then(() => "error" as const),
    timeout,
  ]);

  if (result === "ready") {
    log.info(`bot connected (user=${userId.slice(0, 8)}, app=${maskSecret(appId!, 4)})`);
    return statusPayload(userId);
  }
  if (result === "error") {
    const detail = st.lastErrorDetail ?? classifyError(new Error("连接 QQ 机器人失败"));
    throw new AppError(detail);
  }

  // 超时：网关仍在握手（慢网络）或已被拒绝但 SDK 未报错。检查 SDK 诊断信息，
  // 若存在则给出更明确的提示；否则继续以“连接中”返回并让后台重连。
  if (st.sdkDiag) {
    const detail =
      mapSdkFatal(st.sdkDiag) ??
      ({
        source: "app",
        code: "TIMEOUT",
        type: "TIMEOUT",
        message: "连接 QQ 机器人超时",
        suggestion: "请检查服务器网络，或在 QQ 开放平台确认机器人已上线、权限已开通",
        retryable: true,
        raw: st.sdkDiag,
      } satisfies QQErrorDetail);
    st.status = "error";
    st.lastError = detail.message;
    st.lastErrorDetail = detail;
    await emitStatus(userId);
    throw new AppError(detail);
  }

  log.warn("bot connect is taking longer than expected (no diagnostic yet)");
  return statusPayload(userId);
}

/** 网关异常后自动重连（认证错误不重试）。 */
function scheduleRetry(userId: string, detail: QQErrorDetail): void {
  const st = getState(userId);
  if (st.stopped || st.retryTimer) return;
  if (detail.type === "AUTH_ERROR" || detail.type === "PERMISSION_DENIED") return;
  if (st.retryCount >= 20) return;
  st.retryCount += 1;
  const delay = Math.min(60000, 5000 * Math.pow(1.6, st.retryCount - 1));
  st.retryTimer = setTimeout(() => {
    st.retryTimer = null;
    const cur = getState(userId);
    if (cur.stopped || cur.status === "connected" || cur.status === "connecting") return;
    log.info(`auto reconnect attempt ${cur.retryCount} (user=${userId.slice(0, 8)})`);
    void connect(userId).catch((e) => log.warn("auto reconnect failed", e));
  }, delay);
  st.retryTimer.unref?.();
}

export async function disconnect(userId: string, opts?: { clearCreds?: boolean; setReceiveOff?: boolean }): Promise<StatusPayload> {
  await stopBot(userId, true);
  if (opts?.clearCreds) {
    await delSetting(userId, "credentials");
  }
  if (opts?.setReceiveOff) {
    await setSetting(userId, "receive", "off");
  }
  return statusPayload(userId);
}

async function stopBot(userId: string, announce: boolean): Promise<void> {
  const st = getState(userId);
  st.stopped = true;
  st.onFatal = null;
  if (st.retryTimer) {
    clearTimeout(st.retryTimer);
    st.retryTimer = null;
  }
  const bot = st.bot;
  const ac = st.abort;
  st.bot = null;
  st.abort = null;
  st.status = "disconnected";
  try {
    ac?.abort();
  } catch {
    /* ignore */
  }
  try {
    bot?.stop();
  } catch {
    /* ignore */
  }
  if (announce) await emitStatus(userId);
}

/** 常驻接收开关：开 = 保持网关连接；关 = 断开网关（不再接收新消息）。 */
export async function setReceive(userId: string, on: boolean): Promise<StatusPayload> {
  await setSetting(userId, "receive", on ? "on" : "off");
  if (on) {
    const creds = await storedCreds(userId);
    if (!creds) throw appError("INVALID_REQUEST", "尚未配置机器人凭证", "请先填写 AppID 与 AppSecret");
    const st = getState(userId);
    if (st.status !== "connected" && st.status !== "connecting") {
      return connect(userId);
    }
  } else {
    await stopBot(userId, true);
  }
  return statusPayload(userId);
}

// ── 服务器启动自举 ────────────────────────────────────────────────────────

export async function bootAll(): Promise<void> {
  const m = mgr();
  if (m.booted) return;
  m.booted = true;
  try {
    const { listUsersWithSetting } = await import("./repo");
    const userIds = await listUsersWithSetting("credentials");
    for (const userId of userIds) {
      const receive = await getSetting(userId, "receive");
      if (receive === "off") continue;
      void connect(userId).catch((e) => log.warn(`boot connect failed (user=${userId.slice(0, 8)})`, e));
    }
    if (userIds.length > 0) log.info(`boot: auto-connecting ${userIds.length} bot(s)`);
  } catch (e) {
    m.booted = false; // 数据库未就绪时允许下次重试
    log.warn("bootAll failed", e);
  }
}

export function ensureBoot(): void {
  void bootAll();
}

// ── 机器人资料 ────────────────────────────────────────────────────────────

async function fetchBotInfo(userId: string, bot: QQBot): Promise<BotInfo | null> {
  try {
    const me = (await bot.api.get("/users/@me")) as { id?: string; username?: string; avatar?: string };
    if (me?.id) {
      const info = { id: me.id, username: me.username ?? me.id, avatar: me.avatar };
      await setSetting(userId, "botInfo", JSON.stringify(info));
      return info;
    }
    return null;
  } catch (e) {
    log.warn("fetchBotInfo failed", e);
    return null;
  }
}

// ── 名称解析（修复乱码 / 不显示名称的核心） ──────────────────────────────

const NAME_TTL = 24 * 3600 * 1000;
const NEG_TTL = 10 * 60 * 1000;

async function resolveGroup(userId: string, bot: QQBot, groupOpenid: string): Promise<{ name: string; avatar: string | null } | null> {
  const key = `g:${userId}:${groupOpenid}`;
  const m = mgr();
  const cached = await getContact(userId, "group", groupOpenid);
  if (cached && cached.name && cached.extra?.negative !== true && Date.now() - cached.updatedAt < NAME_TTL) {
    return { name: cached.name, avatar: cached.avatar };
  }
  if (cached && cached.extra?.negative === true && Date.now() - cached.updatedAt < NEG_TTL) return null;
  if (m.inflightNames.has(key)) return null;
  m.inflightNames.add(key);
  try {
    const info = (await bot.api.get(`/v2/groups/${encodeURIComponent(groupOpenid)}`)) as {
      group_name?: string;
      group_avatar?: string;
    };
    if (info?.group_name) {
      await upsertContact(userId, "group", groupOpenid, { name: info.group_name, avatar: info.group_avatar ?? null });
      return { name: info.group_name, avatar: info.group_avatar ?? null };
    }
    throw new Error("empty group_name");
  } catch {
    await upsertContact(userId, "group", groupOpenid, { name: cached?.name ?? null, extra: { negative: true } }).catch(() => {});
    return null;
  } finally {
    m.inflightNames.delete(key);
  }
}

async function resolveMember(
  userId: string,
  bot: QQBot,
  groupOpenid: string,
  memberOpenid: string,
): Promise<{ name: string; avatar: string | null } | null> {
  const key = `m:${userId}:${groupOpenid}:${memberOpenid}`;
  const m = mgr();
  const cached = await getContact(userId, "member", memberOpenid);
  if (cached && cached.name && cached.extra?.negative !== true && Date.now() - cached.updatedAt < NAME_TTL) {
    return { name: cached.name, avatar: cached.avatar };
  }
  if (cached && cached.extra?.negative === true && Date.now() - cached.updatedAt < NEG_TTL) return null;
  if (m.inflightNames.has(key)) return null;
  m.inflightNames.add(key);
  try {
    const info = (await bot.api.get(`/v2/groups/${encodeURIComponent(groupOpenid)}/members/${encodeURIComponent(memberOpenid)}`)) as {
      nick?: string;
      username?: string;
      avatar?: string;
    };
    const name = info?.nick || info?.username;
    if (name) {
      await upsertContact(userId, "member", memberOpenid, { name, avatar: info?.avatar ?? null });
      return { name, avatar: info?.avatar ?? null };
    }
    throw new Error("empty member nick");
  } catch {
    await upsertContact(userId, "member", memberOpenid, { name: cached?.name ?? null, extra: { negative: true } }).catch(() => {});
    return null;
  } finally {
    m.inflightNames.delete(key);
  }
}

/** 群聊显示名：优先用户备注 → 群名缓存 → 平台接口。 */
export async function displayTitleForGroup(userId: string, bot: QQBot | null, groupOpenid: string): Promise<string> {
  const cached = await getContact(userId, "group", groupOpenid);
  if (cached?.name) return cached.name;
  if (bot) {
    const resolved = await resolveGroup(userId, bot, groupOpenid);
    if (resolved) return resolved.name;
  }
  return "QQ 群聊";
}

// ── 入站消息 ──────────────────────────────────────────────────────────────

function detectMsgType(attachments?: AttachmentMeta[]): string {
  if (attachments && attachments.length > 0) {
    const ct = (attachments[0].contentType || "").toLowerCase();
    if (ct.startsWith("image/")) return "image";
    if (ct.startsWith("video/")) return "video";
    if (ct === "voice" || ct.includes("audio") || ct.includes("silk")) return "voice";
    return "file";
  }
  return "text";
}

export function previewOf(msgType: string, text: string | null): string {
  switch (msgType) {
    case "image":
      return "[图片]";
    case "video":
      return "[视频]";
    case "voice":
      return "[语音]";
    case "file":
      return "[文件]";
    default:
      return text || "";
  }
}

function parseTs(ts: unknown): number {
  const n = Number(ts);
  if (!Number.isFinite(n) || n <= 0) return Date.now();
  return n < 1e12 ? Math.floor(n * 1000) : Math.floor(n);
}

async function handleInbound(userId: string, msg: QQBotInboundMessage): Promise<void> {
  const st = getState(userId);
  const bot = st.bot;
  if (!bot) return;
  if (msg.kind !== "c2c" && msg.kind !== "group") return;

  const scope: Scope = msg.kind === "c2c" ? "c2c" : "group";
  const peerId = scope === "c2c" ? msg.senderId : msg.groupOpenid || msg.replyTarget?.targetId;
  if (!peerId) return;

  if (msg.messageId) {
    const dup = await findMessageByQQId(userId, msg.messageId);
    if (dup) return; // 网关重推/断线重连后不重复入库
  }

  const attachments: AttachmentMeta[] =
    msg.attachments?.map((a) => ({
      url: a.url,
      contentType: a.content_type,
      filename: a.filename,
      size: a.size,
      width: a.width,
      height: a.height,
      voiceWavUrl: a.voice_wav_url,
      asrText: a.asr_refer_text,
    })) ?? [];

  const msgType = detectMsgType(attachments);
  const createdAt = parseTs(msg.timestamp);
  const conversationId = convId(scope, peerId);

  // 发送者名称：群成员走缓存/接口解析，避免显示乱码或 openid。
  let senderName = msg.senderName || null;
  if (scope === "group" && msg.senderId) {
    const member = await getContact(userId, "member", msg.senderId);
    if (member?.name) senderName = member.name;
    else {
      void resolveMember(userId, bot, peerId, msg.senderId).catch(() => {});
    }
  }

  // 被引用（回复）的消息内容。
  let reply: ReplyRef | null = null;
  if (msg.refMsgIdx && msg.msgElements && msg.msgElements.length > 0) {
    const quoted = msg.msgElements[0];
    const qAtt = quoted.attachments?.[0];
    const qType = qAtt ? detectMsgType([{ contentType: qAtt.content_type } as AttachmentMeta]) : "text";
    reply = { preview: quoted.content?.trim() ? quoted.content.trim() : previewOf(qType, null), senderName: null };
  }

  const text = (msg.content || "").trim() || null;
  const { row: message, duplicate } = await insertMessage({
    userId,
    qqMessageId: msg.messageId ?? null,
    conversationId,
    scope,
    peerId,
    direction: "in",
    senderId: msg.senderId,
    senderName,
    msgType,
    text,
    attachments,
    status: "sent",
    reply,
    createdAt,
  });
  if (duplicate) return;

  // 会话一定随消息出现（修复“有人发消息但列表不显示”）。
  await ensureConversation(userId, { id: conversationId, scope, peerId, title: peerId });
  const conv = await touchConversation(userId, conversationId, {
    lastMessageAt: Math.max(createdAt, Date.now()),
    lastPreview: previewOf(msgType, text),
    incrUnread: true,
  });

  // 群名 / 私聊名异步解析，拿到后回写会话并通知浏览器。
  void (async () => {
    try {
      if (scope === "group") {
        const resolved = await resolveGroup(userId, bot, peerId);
        if (resolved) {
          const current = await getConversation(userId, conversationId);
          if (current && (current.title === peerId || current.title === "QQ 群聊" || !current.title)) {
            const updated = await updateConversationIdentity(userId, conversationId, {
              title: resolved.name,
              avatar: resolved.avatar ?? undefined,
            });
            if (updated) bus.emit(userId, "conversation", updated);
          }
        }
      } else if (senderName) {
        await upsertContact(userId, "user", peerId, { name: senderName });
        const current = await getConversation(userId, conversationId);
        if (current && !current.remark && (current.title === peerId || current.title === "QQ 好友")) {
          const updated = await updateConversationIdentity(userId, conversationId, { title: senderName });
          if (updated) bus.emit(userId, "conversation", updated);
        }
      }
    } catch (e) {
      log.warn("name resolution failed", e);
    }
  })();

  bus.emit(userId, "message", { message, conversation: conv });
  log.debug(`inbound ${scope} msg from ${peerId} (${msgType})`);
}

// ── 原始事件（好友、群生命周期、入群申请） ───────────────────────────────

function toEpochSeconds(t: unknown): number {
  if (typeof t === "number") return t;
  if (typeof t === "string") {
    const ms = Date.parse(t);
    if (!Number.isNaN(ms)) return Math.floor(ms / 1000);
    const n = Number(t);
    if (Number.isFinite(n)) return n;
  }
  return Math.floor(Date.now() / 1000);
}

async function handleRawEvent(userId: string, eventType: string, data: unknown): Promise<void> {
  const st = getState(userId);
  const bot = st.bot;
  if (!bot) return;

  try {
    if (eventType === "FRIEND_ADD") {
      const ev = data as { openid?: string; timestamp?: unknown; scene?: string; short_code?: string };
      if (!ev.openid) return;
      const event = await insertFriendEvent(userId, ev.openid, ev.scene ?? null, ev.short_code ?? null, toEpochSeconds(ev.timestamp));
      if (!event) return; // 幂等
      const id = convId("c2c", ev.openid);
      await ensureConversation(userId, { id, scope: "c2c", peerId: ev.openid, title: "QQ 好友", lastMessageAt: Date.now() });
      const conv = await getConversation(userId, id);
      if (conv) bus.emit(userId, "conversation", conv);
      bus.emit(userId, "friend_add", event);
      log.info(`FRIEND_ADD ${ev.openid}`);
      return;
    }

    if (eventType === "GROUP_ADD_ROBOT") {
      const ev = data as { group_openid?: string; op_member_openid?: string; timestamp?: unknown };
      if (!ev.group_openid) return;
      const event = await insertGroupRobotEvent(userId, "add", ev.group_openid, ev.op_member_openid ?? null, toEpochSeconds(ev.timestamp));
      const id = convId("group", ev.group_openid);
      const resolved = await resolveGroup(userId, bot, ev.group_openid);
      await ensureConversation(userId, {
        id,
        scope: "group",
        peerId: ev.group_openid,
        title: resolved?.name ?? "QQ 群聊",
        avatar: resolved?.avatar ?? null,
        lastMessageAt: Date.now(),
      });
      const conv = await getConversation(userId, id);
      if (conv) bus.emit(userId, "conversation", conv);
      bus.emit(userId, "group_robot_add", event);
      log.info(`GROUP_ADD_ROBOT ${ev.group_openid}`);
      return;
    }

    if (eventType === "GROUP_DEL_ROBOT") {
      const ev = data as { group_openid?: string; op_member_openid?: string; timestamp?: unknown };
      if (!ev.group_openid) return;
      const event = await insertGroupRobotEvent(userId, "del", ev.group_openid, ev.op_member_openid ?? null, toEpochSeconds(ev.timestamp));
      bus.emit(userId, "group_robot_del", event);
      log.info(`GROUP_DEL_ROBOT ${ev.group_openid}`);
      return;
    }

    if (eventType === "GROUP_JOIN_REQUEST") {
      const ev = data as {
        group_openid?: string;
        join_request_id?: string;
        member_openid?: string;
        username?: string;
        apply_at?: string;
        apply_source?: string;
        invited_by?: string;
        verify_info?: Record<string, unknown>;
        risk_tips?: string;
      };
      if (!ev.group_openid || !ev.member_openid) return;
      const req = await insertJoinRequest(userId, {
        joinRequestId: ev.join_request_id ?? null,
        groupOpenid: ev.group_openid,
        memberOpenid: ev.member_openid,
        username: ev.username ?? null,
        applyAt: ev.apply_at ?? null,
        applySource: ev.apply_source ?? null,
        invitedBy: ev.invited_by ?? null,
        verifyInfo: ev.verify_info ?? null,
        riskTips: ev.risk_tips ?? null,
      });
      if (req) bus.emit(userId, "join_request", req);
      log.info(`GROUP_JOIN_REQUEST ${ev.member_openid} -> ${ev.group_openid}`);
      return;
    }
  } catch (e) {
    log.warn(`raw event ${eventType} handling failed`, e);
  }
}

// ── 入群申请审批 ──────────────────────────────────────────────────────────

export async function decideJoinRequest(userId: string, requestId: string, op: "approve" | "decline", reason?: string) {
  const reqs = await listJoinRequests(userId);
  const req = reqs.find((r) => r.id === requestId);
  if (!req) throw appError("INVALID_REQUEST", "入群申请不存在", "可能已被处理");
  if (req.status !== "pending") throw appError("INVALID_REQUEST", "该申请已被处理", "请刷新列表");
  const bot = requireBot(userId);
  await bot.api.post(
    `/v2/groups/${encodeURIComponent(req.groupOpenid)}/approval_join_request/${encodeURIComponent(req.memberOpenid)}`,
    {
      op,
      join_request_id: req.joinRequestId,
      reject_reason: op === "decline" ? reason || undefined : undefined,
      add_to_member_blacklist: false,
    },
  );
  const updated = await updateJoinRequestStatus(userId, req.id, op === "approve" ? "approved" : "declined");
  if (updated) bus.emit(userId, "join_request", updated);
  return updated;
}

// ── 同步：群列表 + 历史消息（补齐离线期间的消息） ───────────────────────

interface HistoryMessage {
  id?: string;
  content?: string;
  timestamp?: string;
  msg_seq?: number | string;
  author?: { id?: string; member_openid?: string; user_openid?: string };
  attachments?: Array<{ content_type?: string; url?: string; filename?: string; size?: number; width?: number; height?: number }>;
}

async function ingestHistory(userId: string, bot: QQBot, conv: { id: string; scope: string; peerId: string }): Promise<number> {
  try {
    const path = conv.scope === "group" ? `/v2/groups/${encodeURIComponent(conv.peerId)}/messages` : `/v2/users/${encodeURIComponent(conv.peerId)}/messages`;
    const res = (await bot.api.get(path, { limit: 20 })) as { messages?: HistoryMessage[] } | null;
    const list = Array.isArray(res?.messages) ? res!.messages! : [];
    let added = 0;
    const botId = getState(userId).botInfo?.id ?? null;
    for (const hm of list) {
      if (!hm || !hm.id) continue;
      const dup = await findMessageByQQId(userId, hm.id);
      if (dup) continue;
      const attachments: AttachmentMeta[] = (hm.attachments ?? []).map((a) => ({
        url: a.url,
        contentType: a.content_type || "application/octet-stream",
        filename: a.filename,
        size: a.size,
        width: a.width,
        height: a.height,
      }));
      const msgType = detectMsgType(attachments);
      const text = (hm.content || "").trim() || null;
      const direction: "in" | "out" = hm.author?.id && botId && hm.author.id === botId ? "out" : "in";
      let senderId = conv.scope === "group" ? (hm.author?.member_openid ?? null) : (hm.author?.user_openid ?? null);
      if (direction === "out") senderId = botId;
      let senderName: string | null = null;
      if (conv.scope === "group" && senderId && direction === "in") {
        const member = await getContact(userId, "member", senderId);
        senderName = member?.name ?? null;
        if (!senderName) void resolveMember(userId, bot, conv.peerId, senderId).catch(() => {});
      }
      const { duplicate } = await insertMessage({
        userId,
        qqMessageId: hm.id,
        conversationId: conv.id,
        scope: conv.scope as Scope,
        peerId: conv.peerId,
        direction,
        senderId,
        senderName,
        msgType,
        text,
        attachments,
        status: "sent",
        createdAt: parseTs(hm.timestamp),
      });
      if (!duplicate) added += 1;
    }
    return added;
  } catch {
    return 0; // 消息记录接口可能未开通权限，静默降级
  }
}

export async function sync(userId: string, force: boolean): Promise<{ groups: number; messages: number; skipped?: boolean }> {
  const st = getState(userId);
  const bot = st.bot;
  if (!bot || st.status !== "connected") {
    return { groups: 0, messages: 0 };
  }
  const m = mgr();
  const last = m.lastSync.get(userId) ?? 0;
  if (!force && Date.now() - last < config.syncMinIntervalMs) {
    return { groups: 0, messages: 0, skipped: true };
  }
  if (st.syncing) return { groups: 0, messages: 0, skipped: true };
  st.syncing = true;
  m.lastSync.set(userId, Date.now());
  await emitStatus(userId);

  let groupCount = 0;
  let msgCount = 0;
  try {
    // 1. 拉取机器人所在的全部群，保证群聊一定出现在列表里。
    try {
      const res = (await bot.api.get("/v2/groups")) as {
        groups?: Array<{ group_openid?: string; group_name?: string; group_avatar?: string; member_count?: number }>;
      };
      const groups = Array.isArray(res?.groups) ? res.groups : [];
      for (const grp of groups) {
        if (!grp.group_openid) continue;
        groupCount += 1;
        const id = convId("group", grp.group_openid);
        if (grp.group_name) {
          await upsertContact(userId, "group", grp.group_openid, { name: grp.group_name, avatar: grp.group_avatar ?? null });
        }
        await ensureConversation(userId, {
          id,
          scope: "group",
          peerId: grp.group_openid,
          title: grp.group_name || undefined,
          avatar: grp.group_avatar ?? null,
        });
        const current = await getConversation(userId, id);
        if (current && grp.group_name && current.title !== grp.group_name && (current.title === current.peerId || current.title === "QQ 群聊")) {
          const updated = await updateConversationIdentity(userId, id, { title: grp.group_name, avatar: grp.group_avatar ?? null });
          if (updated) bus.emit(userId, "conversation", updated);
        }
      }
    } catch (e) {
      log.warn("sync group list failed", e);
    }

    // 2. 为最近活跃的会话补齐历史消息（覆盖停机/断网期间）。
    const convs = await listConversations(userId);
    const targets = convs.filter((c) => c.lastMessageAt > 0).slice(0, 12);
    for (const conv of targets) {
      msgCount += await ingestHistory(userId, bot, { id: conv.id, scope: conv.scope, peerId: conv.peerId });
    }

    await setSetting(userId, "lastSyncAt", String(Date.now()));
  } finally {
    st.syncing = false;
    await emitStatus(userId);
    bus.emit(userId, "sync", { groups: groupCount, messages: msgCount });
  }
  if (msgCount > 0) log.info(`sync done: +${msgCount} messages, ${groupCount} groups`);
  return { groups: groupCount, messages: msgCount };
}

// ── 出站消息 ──────────────────────────────────────────────────────────────

async function upsertOutConversation(userId: string, scope: Scope, peerId: string): Promise<string> {
  const id = convId(scope, peerId);
  const existing = await getConversation(userId, id);
  if (!existing) {
    let title = "QQ 好友";
    if (scope === "group") {
      const cached = await getContact(userId, "group", peerId);
      title = cached?.name || "QQ 群聊";
    } else {
      const cached = await getContact(userId, "user", peerId);
      title = cached?.name || "QQ 好友";
    }
    await ensureConversation(userId, { id, scope, peerId, title });
  }
  return id;
}

function emitMessage(userId: string, row: import("@/db/schema").MessageRow): void {
  void getConversation(userId, row.conversationId).then((conv) => {
    bus.emit(userId, "message", { message: row, conversation: conv });
  });
}

export interface SendTextOptions {
  text: string;
  replyTo?: string | null; // 被引用消息的本地 id
}

export async function sendText(userId: string, scope: Scope, peerId: string, opts: SendTextOptions) {
  const trimmed = (opts.text || "").trim();
  if (!trimmed) throw appError("INVALID_REQUEST", "消息内容不能为空", "请输入文字");
  const bot = requireBot(userId);
  const st = getState(userId);
  const conversationId = await upsertOutConversation(userId, scope, peerId);

  // 解析引用：5 分钟内走被动回复（QQ 内显示引用），否则本地引用 + 主动消息。
  let reply: ReplyRef | null = null;
  let passiveMsgId: string | undefined;
  if (opts.replyTo) {
    const { getMessage } = await import("./repo");
    const original = await getMessage(userId, opts.replyTo);
    if (original) {
      reply = {
        qqMsgId: original.qqMessageId,
        localId: original.id,
        preview: original.msgType === "text" ? (original.text ?? "") : previewOf(original.msgType, null),
        senderName: original.senderName,
      };
      if (original.qqMessageId && Date.now() - original.createdAt < config.passiveReplyWindowMs) {
        passiveMsgId = original.qqMessageId;
      }
    }
  }

  const target: ReplyTarget = { scope, targetId: peerId, msgId: passiveMsgId };
  const message = (
    await insertMessage({
      userId,
      conversationId,
      scope,
      peerId,
      direction: "out",
      senderId: st.botInfo?.id ?? null,
      senderName: st.botInfo?.username ?? null,
      msgType: "text",
      text: trimmed,
      status: "sending",
      reply,
      createdAt: Date.now(),
    })
  ).row;
  emitMessage(userId, message);

  try {
    const sent = await bot.sendText(target, trimmed);
    if (sent?.id) await setMessageQQId(userId, message.id, sent.id);
    const ok = await updateMessageStatus(userId, message.id, "sent", null);
    await touchConversation(userId, conversationId, { lastMessageAt: Date.now(), lastPreview: trimmed });
    if (ok) emitMessage(userId, ok);
    return ok ?? message;
  } catch (err) {
    // 被动回复失败（超时/次数限制）时自动降级为主动消息，避免发送失败。
    if (passiveMsgId) {
      try {
        const sent = await bot.sendText({ scope, targetId: peerId }, trimmed);
        if (sent?.id) await setMessageQQId(userId, message.id, sent.id);
        const ok = await updateMessageStatus(userId, message.id, "sent", null);
        await touchConversation(userId, conversationId, { lastMessageAt: Date.now(), lastPreview: trimmed });
        if (ok) emitMessage(userId, ok);
        return ok ?? message;
      } catch (err2) {
        err = err2;
      }
    }
    const detail = classifyError(err);
    const failed = await updateMessageStatus(userId, message.id, "failed", detail.message);
    if (failed) emitMessage(userId, failed);
    throw new AppError(detail);
  }
}

export interface SendMediaOptions {
  localPath: string;
  fileName: string;
  contentType: string;
  size?: number;
  kind: "image" | "video" | "voice" | "file";
  replyTo?: string | null;
}

function fileTypeFor(kind: string): MediaFileType {
  switch (kind) {
    case "image":
      return MediaFileType.IMAGE;
    case "video":
      return MediaFileType.VIDEO;
    case "voice":
      return MediaFileType.VOICE;
    default:
      return MediaFileType.FILE;
  }
}

export async function sendMedia(userId: string, scope: Scope, peerId: string, opts: SendMediaOptions) {
  const bot = requireBot(userId);
  const st = getState(userId);
  const conversationId = await upsertOutConversation(userId, scope, peerId);

  let reply: ReplyRef | null = null;
  let passiveMsgId: string | undefined;
  if (opts.replyTo) {
    const { getMessage } = await import("./repo");
    const original = await getMessage(userId, opts.replyTo);
    if (original) {
      reply = {
        qqMsgId: original.qqMessageId,
        localId: original.id,
        preview: original.msgType === "text" ? (original.text ?? "") : previewOf(original.msgType, null),
        senderName: original.senderName,
      };
      if (original.qqMessageId && Date.now() - original.createdAt < config.passiveReplyWindowMs) {
        passiveMsgId = original.qqMessageId;
      }
    }
  }

  const localId = randomUUID();
  const message = (
    await insertMessage({
      userId,
      conversationId,
      scope,
      peerId,
      direction: "out",
      senderId: st.botInfo?.id ?? null,
      senderName: st.botInfo?.username ?? null,
      msgType: opts.kind,
      attachments: [{ localId, contentType: opts.contentType, filename: opts.fileName, size: opts.size }],
      status: "sending",
      reply,
      createdAt: Date.now(),
    })
  ).row;
  emitMessage(userId, message);

  const target: ReplyTarget = { scope, targetId: peerId, msgId: passiveMsgId };
  const preview = previewOf(opts.kind, null);

  const attempt = async (tgt: ReplyTarget, ft: MediaFileType) => {
    await bot.sendMedia({
      target: tgt,
      fileType: ft,
      localPath: opts.localPath,
      fileName: opts.fileName,
      onProgress: (uploaded, total) => {
        bus.emit(userId, "upload_progress", { messageId: message.id, uploaded, total });
      },
    });
  };

  try {
    try {
      await attempt(target, fileTypeFor(opts.kind));
    } catch (err) {
      // 语音格式不受支持等情况：降级为普通文件重发；被动失败降级为主动。
      if (passiveMsgId) {
        await attempt({ scope, targetId: peerId }, fileTypeFor(opts.kind));
      } else if (opts.kind === "voice") {
        await attempt(target, MediaFileType.FILE);
      } else {
        throw err;
      }
    }
    const ok = await updateMessageStatus(userId, message.id, "sent", null);
    await touchConversation(userId, conversationId, { lastMessageAt: Date.now(), lastPreview: preview });
    if (ok) emitMessage(userId, ok);
    return ok ?? message;
  } catch (err) {
    const detail = classifyError(err);
    const failed = await updateMessageStatus(userId, message.id, "failed", detail.message);
    if (failed) emitMessage(userId, failed);
    throw new AppError(detail);
  }
}

/** 撤回消息（平台接口支持时生效）。 */
export async function recallMessage(userId: string, messageId: string): Promise<void> {
  const { getMessage } = await import("./repo");
  const row = await getMessage(userId, messageId);
  if (!row) throw appError("INVALID_REQUEST", "消息不存在", "请刷新后重试");
  if (!row.qqMessageId) throw appError("INVALID_REQUEST", "该消息无法撤回", "仅已成功送达的消息可撤回");
  const bot = requireBot(userId);
  await bot.recallMessage({ scope: row.scope as Scope, targetId: row.peerId }, row.qqMessageId);
  const updated = await updateMessageStatus(userId, row.id, "recalled", null);
  const conv = await getConversation(userId, row.conversationId);
  if (updated) bus.emit(userId, "message", { message: updated, conversation: conv });
}

/** 重发失败的文本消息。 */
export async function resendFailed(userId: string, messageId: string) {
  const { getMessage } = await import("./repo");
  const row = await getMessage(userId, messageId);
  if (!row) throw appError("INVALID_REQUEST", "消息不存在", "请刷新后重试");
  if (row.status !== "failed") throw appError("INVALID_REQUEST", "仅失败的消息可重发", "");
  if (row.msgType !== "text" || !row.text) throw appError("INVALID_REQUEST", "该类型消息暂不支持重发", "请手动重新发送");
  const bot = requireBot(userId);
  const ok = await updateMessageStatus(userId, row.id, "sending", null);
  if (ok) emitMessage(userId, ok);
  try {
    const sent = await bot.sendText({ scope: row.scope as Scope, targetId: row.peerId }, row.text);
    if (sent?.id) await setMessageQQId(userId, row.id, sent.id);
    const done = await updateMessageStatus(userId, row.id, "sent", null);
    await touchConversation(userId, row.conversationId, { lastMessageAt: Date.now(), lastPreview: row.text });
    if (done) emitMessage(userId, done);
    return done;
  } catch (err) {
    const detail = classifyError(err);
    const failed = await updateMessageStatus(userId, row.id, "failed", detail.message);
    if (failed) emitMessage(userId, failed);
    throw new AppError(detail);
  }
}

export async function renameConversation(userId: string, id: string, remark: string) {
  const trimmed = remark.trim();
  const updated = await setConversationRemark(userId, id, trimmed ? trimmed : null);
  if (!updated) throw appError("INVALID_REQUEST", "会话不存在", "请刷新后重试");
  bus.emit(userId, "conversation", updated);
  return updated;
}

export async function markConversationRead(userId: string, id: string): Promise<void> {
  await markRead(userId, id);
  const conv = await getConversation(userId, id);
  if (conv) bus.emit(userId, "conversation", conv);
}

// ── 群成员列表 ───────────────────────────────────────────────────────────

export interface MemberEntry {
  openid: string;
  name: string | null;
  avatar: string | null;
  joinTime: string | null;
}

export async function listGroupMembers(userId: string, groupOpenid: string): Promise<MemberEntry[]> {
  const bot = requireBot(userId);
  const res = (await bot.api.get(`/v2/groups/${encodeURIComponent(groupOpenid)}/members`, { limit: 200 })) as {
    members?: Array<{ member_openid?: string; join_time?: string; nick?: string; avatar?: string }>;
  };
  const members = Array.isArray(res?.members) ? res!.members! : [];
  const result: MemberEntry[] = [];
  for (const m of members) {
    if (!m.member_openid) continue;
    let name = m.nick || null;
    let avatar = m.avatar || null;
    if (!name) {
      const cached = await getContact(userId, "member", m.member_openid);
      if (cached?.name) {
        name = cached.name;
        avatar = avatar || cached.avatar;
      }
    } else {
      await upsertContact(userId, "member", m.member_openid, { name, avatar });
    }
    result.push({ openid: m.member_openid, name, avatar, joinTime: m.join_time ?? null });
  }
  return result;
}

// ── 连接诊断 ───────────────────────────────────────────────────────────────

export interface DiagnoseResult {
  network: Array<{ host: string; ok: boolean; latencyMs: number | null; error?: string }>;
  token: {
    tested: boolean;
    ok: boolean;
    appId?: string;
    code?: number | string;
    message?: string;
  };
}

/** 自检：网络连通性 + 凭证校验，帮助定位“连不上机器人”的原因。 */
export async function diagnose(userId: string, appIdInput?: string, appSecretInput?: string): Promise<DiagnoseResult> {
  let appId = appIdInput?.trim();
  let secret = appSecretInput?.trim();
  if (!appId || !secret) {
    const creds = await storedCreds(userId);
    if (creds) {
      appId = appId || creds.appId;
      secret = secret || creds.secret;
    }
  }

  const network: DiagnoseResult["network"] = [];
  for (const host of ["bots.qq.com", "api.sgroup.qq.com"]) {
    const started = Date.now();
    try {
      await fetch(`https://${host}/`, { method: "GET", signal: AbortSignal.timeout(6000) });
      network.push({ host, ok: true, latencyMs: Date.now() - started });
    } catch (e) {
      network.push({ host, ok: false, latencyMs: null, error: e instanceof Error ? e.message : String(e) });
    }
  }

  let token: DiagnoseResult["token"] = { tested: false, ok: false };
  if (appId && secret) {
    try {
      const res = await fetch("https://bots.qq.com/app/getAppAccessToken", {
        method: "POST",
        headers: { "Content-Type": "application/json", "User-Agent": "qqbot-web-client/1.0" },
        body: JSON.stringify({ appId, clientSecret: secret }),
        signal: AbortSignal.timeout(10000),
      });
      const body = (await res.json().catch(() => ({}))) as { access_token?: string; code?: number; message?: string };
      if (res.ok && body.access_token) {
        token = { tested: true, ok: true, appId: maskSecret(appId, 4) };
      } else {
        token = { tested: true, ok: false, appId: maskSecret(appId, 4), code: body.code ?? res.status, message: body.message || `HTTP ${res.status}` };
      }
    } catch (e) {
      token = {
        tested: true,
        ok: false,
        appId: maskSecret(appId, 4),
        code: "NETWORK",
        message: e instanceof Error ? e.message : String(e),
      };
    }
  }

  return { network, token };
}

export { listJoinRequests };
