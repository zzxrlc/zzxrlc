# QQ 机器人工作台（qq-bot-web-chat-client）

基于 QQ 开放平台官方接口（`@tencent-connect/qqbot-nodejs`）的网页版 QQ 机器人客户端。
Next.js (App Router) + PostgreSQL (Drizzle ORM)，功能对标原版 QQ 的消息能力。

## 功能

- 私聊（C2C）与群聊消息收发，文本 / 图片 / 视频 / 语音 / 文件
- **引用回复**：5 分钟内的消息走官方被动回复通道（QQ 内显示引用），超时自动降级为主动消息
- **撤回**、失败重发、发送状态（发送中/已送达/失败）
- **常驻服务器接收** + 手动开关：关掉浏览器消息也持续入库，再次打开自动补齐
- **实时推送（SSE）**：新消息即收即显，无需刷新
- **不漏消息**：入库先于推送，`qq_message_id` 唯一索引去重，网关断线自动续传 + 重连
- **自动同步**：每次进入自动拉取群列表与历史消息，修复"群聊不在列表"的问题
- **名称修复**：群名 / 群成员昵称走官方接口解析并缓存，私聊支持自定义备注
- **多账号隔离**：每个网页账号独立数据与独立机器人连接，多设备互不串号
- 入群申请审批（同意/拒绝）、新好友通知、机器人入群动态
- 群成员列表、消息搜索、未读计数、图片灯箱
- 内置服务器部署教程（访问 `/guide`）

## 快速开始（本地）

```bash
npm install
cp .env.example .env   # 修改 DATABASE_URL
npx drizzle-kit push   # 建表
npm run dev            # http://localhost:3000
```

打开后注册账号 → 设置 → 填入 QQ 开放平台的 AppID / AppSecret → 连接。

## 生产部署

详细步骤（systemd / nginx / HTTPS / 常见问题）见应用内 `/guide` 页面，或 `docs` 部分。

```bash
npm ci
npm run build
npm run start          # 建议用 systemd / pm2 常驻
```

## 环境变量

| 变量 | 说明 | 默认 |
| --- | --- | --- |
| `DATABASE_URL` | PostgreSQL 连接串 | 必填 |
| `DATA_DIR` | 数据目录（媒体/会话/密钥） | `./data` |
| `LOG_LEVEL` | debug/info/warn/error | `info` |
| `MAX_UPLOAD_MB` | 上传单文件上限 | `200` |
| `PORT` | 监听端口 | `3000` |

## 常用脚本

- `npm run build` — 生产构建
- `npm run start` — 启动生产服务
- `npx drizzle-kit push` — 同步数据库表结构
